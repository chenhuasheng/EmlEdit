
// emleditDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "EmlEditCtrl.h"
#include "afxfontcombobox.h"
#include "afxcolorbutton.h"
#include "afxpropertygridctrl.h"
#include "afxeditbrowsectrl.h"


// CemleditDlg �Ի���
class CemleditDlg : public CDialogEx
{
// ����
public:
	CemleditDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_EMLEDIT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEmlEditCtrl m_edit;
	afx_msg void OnBnClickedOk();
	//CMFCFontComboBox m_cbFont;
	//CMFCColorButton m_btnFgColor;
	//CMFCColorButton m_btnBkColor;
	CMFCPropertyGridCtrl m_propCtrl;
	//CMFCToolBarFontSizeComboBox m_cbFontsize;
	afx_msg void OnBnClickedButtonAddText();
	//afx_msg void OnCbnSelendokMfcfontcomboFont();
	afx_msg void OnStnClickedMfcpropertygridProps();
	afx_msg void OnBnClickedButtonLoad();
	afx_msg LRESULT OnPropertyChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnXEditCtrlNotify(NMHDR * pNotifyStruct, LRESULT * result);

	afx_msg void OnBnClickedButtonUpdate();
	CMFCEditBrowseCtrl m_wndImage;
	afx_msg void OnBnClickedButtonInsert();
	afx_msg void OnBnClickedButtonSpellcheck();
	afx_msg void OnBnClickedButtonEndSpellcheck();
};
