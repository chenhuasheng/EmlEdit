#pragma once

//===========================================================================
// Remarks:
//     This internal class is used for semi-automatic incrementing
//          and decrementing reference to any object derived from CCmdTarget
//          or other class, which has InternalAddRef(), InternalRelease()
//          methods.
// See Also: macro XTP_DEFINE_SMART_PTR_INTERNAL(_TClassName)
//===========================================================================
template<class _TObject>
class CXTPSmartPtrInternalT
{
protected:
	//------------------------------------------------------------------------
	// Remarks:
	//     This class type definition
	//------------------------------------------------------------------------
	typedef CXTPSmartPtrInternalT<_TObject> Tthis;

	_TObject* m_pObject; // A pointer to a handled object
public:

	//-----------------------------------------------------------------------
	// Parameters:
	//     pObject             - Pointer to the handled object.
	//     bCallInternalAddRef - If this parameter is TRUE
	//                                pObject->InternalAddRef() will be
	//                                called in constructor.
	//                                By default this parameter is FALSE.
	// Summary:
	//     Default class constructor.
	// See Also: ~CXTPSmartPtrInternalT()
	//-----------------------------------------------------------------------
	CXTPSmartPtrInternalT(_TObject* pObject = NULL, BOOL bCallInternalAddRef = FALSE)
	{
		m_pObject = pObject;

		if (bCallInternalAddRef && m_pObject) {
			((CCmdTarget*)m_pObject)->InternalAddRef();
		}
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Copy class constructor.
	// See Also:
	//      CXTPSmartPtrInternalT(_TObject* pObject, BOOL bCallInternalAddRef)
	// Parameters:
	//     rSrc :  the source object reference.
	//-----------------------------------------------------------------------
	CXTPSmartPtrInternalT(const Tthis& rSrc)
	{
		m_pObject = (_TObject*)rSrc;
		if (m_pObject) {
			((CCmdTarget*)m_pObject)->InternalAddRef();
		}
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Default class destructor.
	// Remarks:
	//     Call InternalRelease() for the not NULL handled object.
	// See Also: CXTPSmartPtrInternalT constructors
	//-----------------------------------------------------------------------
	virtual ~CXTPSmartPtrInternalT() {
		if (m_pObject) {
			((CCmdTarget*)m_pObject)->InternalRelease();
		}
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Set new handled object.
	// Parameters:
	//     rSrc                 - Pointer to the new handled object.
	//     bCallInternalAddRef - If this parameter is TRUE
	//                           pObject->InternalAddRef() will be
	//                           called in constructor.
	//                           By default this parameter is FALSE.
	// Remarks:
	//     InternalRelease() for the previous not NULL handled object
	//     will be called. InternalAddRef() for the new not NULL handled
	//     object will be called.
	// See Also:
	//     operator=
	//-----------------------------------------------------------------------
	void SetPtr(_TObject* pObject, BOOL bCallInternalAddRef = FALSE)
	{
		_TObject* pObjOld = m_pObject;

		if (bCallInternalAddRef && pObject) {
			((CCmdTarget*)pObject)->InternalAddRef();
		}
		m_pObject = pObject;

		if (pObjOld) {
			((CCmdTarget*)pObjOld)->InternalRelease();
		}
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Get a handled object and set internal object member to NULL
	//          without call InternalRelease().
	// Returns:
	//     Pointer to the handled object.
	//-----------------------------------------------------------------------
	_TObject* Detach() {
		_TObject* pObj = m_pObject;
		m_pObject = NULL;
		return pObj;
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Get a handled object and set internal object member to NULL
	//          without call InternalRelease().
	// Returns:
	//     Pointer to the handled object.
	//-----------------------------------------------------------------------
	_TObject* GetInterface(BOOL bWithAddRef = TRUE) {
		if (bWithAddRef && m_pObject) {
			((CCmdTarget*)m_pObject)->InternalAddRef();
		}
		return m_pObject;
	};

	//-----------------------------------------------------------------------
	// Parameters:
	//     pNewObj  - Pointer to the new handled object.
	// Summary:
	//     Set new handled object.
	// Remarks:
	//     InternalRelease() for the previous not NULL handled object
	//          will be called.
	// Returns:
	//     Pointer to the new handled object.
	//-----------------------------------------------------------------------
	_TObject* operator=(_TObject* pNewObj)
	{
		_TObject* pObjOld = m_pObject;
		m_pObject = pNewObj;

		if (pObjOld) {
			((CCmdTarget*)pObjOld)->InternalRelease();
		}

		return pNewObj;
	};

	//-----------------------------------------------------------------------
	// Parameters:
	//     rSrc - Reference to the new handled object.
	// Summary:
	//     Set new handled object.
	// Remarks:
	//     InternalRelease() for the previous not NULL handled object
	//          will be called. InternalAddRef() for the new not NULL handled
	//          object will be called.
	// Returns:
	//     Reference to this class instance.
	//-----------------------------------------------------------------------
	const Tthis& operator=(const Tthis& rSrc) {
		_TObject* pObjOld = m_pObject;

		m_pObject = rSrc;

		if (m_pObject) {
			((CCmdTarget*)m_pObject)->InternalAddRef();
		}

		if (pObjOld) {
			((CCmdTarget*)pObjOld)->InternalRelease();
		}

		return rSrc;
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Get a handled object.
	// Returns:
	//     Pointer to the handled object.
	//-----------------------------------------------------------------------
	_TObject* operator->() const{
		ASSERT(m_pObject);
		return m_pObject;
	};

	//-----------------------------------------------------------------------
	// Summary:
	//     Get a handled object.
	// Returns:
	//     Pointer to the handled object.
	//-----------------------------------------------------------------------
	operator _TObject*() const {
		return m_pObject;
	}

	//-----------------------------------------------------------------------
	// Summary:
	//     Check is handled object equal NULL.
	// Returns:
	//     TRUE if handled object equal NULL, else FALSE.
	//-----------------------------------------------------------------------
	BOOL operator!() const {
		return !m_pObject;
	}

	//-----------------------------------------------------------------------
	// Summary:
	//     Equal-to operator.
	// Parameters:
	//      pObj :  [in] Pointer to the other object.
	//      ptr2 :  [in] Smart pointer to the other object.
	// Remarks:
	//     This operator compare internal stored pointer and specified
	//          pointer.
	// Returns:
	//     TRUE if pointer are equal, else FALSE.
	//-----------------------------------------------------------------------
	BOOL operator==(const Tthis& ptr2) const {
		return m_pObject == (_TObject*)ptr2;
	}
	// ----------------------------------------------------
	// <combine CXTPSmartPtrInternalT::==@Tthis&amp;@const>
	// ----------------------------------------------------
	BOOL operator==(const _TObject* pObj) const {
		return pObj == m_pObject;
	}
};

