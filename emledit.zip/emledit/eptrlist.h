#pragma once

#pragma pack(push)
#pragma pack(1)

template<class T>
struct CEPtrNode
{
	CEPtrNode<T> * pNext;
	CEPtrNode<T> * pPrev;
	T pdata;
};
#pragma pack(pop)

#define XNODE(T) CEPtrNode<T>
#define PXNODE(T) CEPtrNode<T> *


//ָ��ʽ������ע�Ȿ��������ʹ�� CEPlexMem��
//����Ϊ����������������CEPtrNode�ƶ������������
//�����CEPlexMem���ͳ��ִӱ�������ƶ�������node��������������𲻿�Ԥ��Ļ���
template<class T>
class CEPtrList
{
protected:
	CEPtrNode<T> *m_pHead;
	CEPtrNode<T> *m_pTail;
	INT_PTR m_nCount;
	BOOL m_bAutoDeleteData;
public:
	CEPtrList(BOOL bAutoDeleteData)
		:m_bAutoDeleteData(bAutoDeleteData)
		, m_pHead(NULL), m_pTail(NULL), m_nCount(0)
	{
	}
	virtual ~CEPtrList()
	{
		RemoveAll();
	}
	INT_PTR GetCount() const 
	{ 
		return m_nCount; 
	}
	INT_PTR GetSize() const 
	{ 
		return m_nCount; 
	}
	BOOL IsEmpty() const 
	{ 
		return (m_nCount == 0 ? TRUE : FALSE); 
	}
	T GetHead()
	{
		if (m_pHead == NULL)
			return (T)NULL;
		return m_pHead->pdata;
	}
	CEPtrNode<T> * GetHeadNode()
	{
		return m_pHead;
	}
	T GetTail()
	{
		if (m_pTail == NULL)
			return (T)NULL;
		return m_pTail->pdata;
	}
	CEPtrNode<T> * GetTailNode()
	{
		return m_pTail;
	}
	CEPtrNode<T> * GetNode(T pEle)
	{
		return Find(pEle);
	}
	T RemoveHead()
	{
		if (m_nCount == 0)
			return (T)NULL;
		ASSERT(m_pHead);
		CEPtrNode<T> *pTmp = m_pHead;
		T pRet = pTmp->pdata;
		m_pHead = pTmp->pNext;
		if (m_pHead != NULL)
			m_pHead->pPrev = NULL;
		else
			m_pTail = NULL;
		delete pTmp;
		m_nCount--;
		return pRet;
	}
	T RemoveTail()
	{
		if (m_nCount == 0)
			return (T)NULL;
		ASSERT(m_pTail);
		CEPtrNode<T> *pTmp = m_pTail;
		T pRet = pTmp->pdata;
		m_pTail = pTmp->pPrev;
		if (m_pTail != NULL)
			m_pTail->pNext = NULL;
		else
			m_pHead = NULL;
		delete pTmp;
		m_nCount--;
		return pRet;
	}
	CEPtrNode<T> * AddHead(T pNew)
	{
		CEPtrNode<T>* pNewNode = new CEPtrNode<T>;
		if (pNewNode == NULL)
			return pNewNode;
		pNewNode->pNext = m_pHead;
		pNewNode->pPrev = NULL;
		pNewNode->pdata = pNew;
		if (m_pHead != NULL)
			m_pHead->pPrev = pNewNode;
		else
			m_pTail = pNewNode;
		m_pHead = pNewNode;
		m_nCount++;
		return pNewNode;
	}
	CEPtrNode<T> * AddTail(T pNew)
	{
		CEPtrNode<T>* pNewNode = new CEPtrNode<T>;
		if (pNewNode == NULL)
			return pNewNode;
		pNewNode->pNext = NULL;
		pNewNode->pPrev = m_pTail;
		pNewNode->pdata = pNew;
		if (m_pTail != NULL)
			m_pTail->pNext = pNewNode;
		else
			m_pHead = pNewNode;
		m_pTail = pNewNode;
		m_nCount++;
		return pNewNode;
	}
	// add another list of elements before head or after tail
	INT_PTR AddHead(CEPtrList<T>* pNewList)
	{
		INT_PTR count = 0;
		if (pNewList->GetCount())
		{
			CEPtrNode<T> *pPrev;
			CEPtrNode<T> *pTailNode = pNewList->GetTailNode();
			while (pTailNode)
			{
				pPrev = pTailNode->pPrev;
				AddHead(pTailNode);
				count++;
				pTailNode = pPrev;
			}
			pNewList->RemoveAll(FALSE);
		}
		return count;
	}
	CEPtrNode<T> * AddTail(CEPtrNode<T> *pNewNode)
	{
		pNewNode->pNext = NULL;
		pNewNode->pPrev = m_pTail;
		//pNewNode->pdata = pNew;
		if (m_pTail != NULL)
			m_pTail->pNext = pNewNode;
		else
			m_pHead = pNewNode;
		m_pTail = pNewNode;
		m_nCount++;
		return pNewNode;
	}
	CEPtrNode<T> * AddHead(CEPtrNode<T> *pNewNode)
	{
		pNewNode->pNext = m_pHead;
		pNewNode->pPrev = NULL;
		//pNewNode->pdata = pNew;
		if (m_pHead != NULL)
			m_pHead->pPrev = pNewNode;
		else
			m_pTail = pNewNode;
		m_pHead = pNewNode;
		m_nCount++;
		return pNewNode;
	}
	//��pNode�ƶ�������һ���б�pList��ĩβ
	void MoveToTail(CEPtrNode<T> *pNode, CEPtrList<T> *pList)
	{
		_remove_no_del(pNode);
		m_nCount--;
		pList->AddTail(pNode);
	}
	//��pNode�ƶ�������һ���б�pList����ǰ��
	void MoveToHead(CEPtrNode<T> *pNode, CEPtrList<T> *pList)
	{
		_remove_no_del(pNode);
		m_nCount--;
		pList->AddHead(pNode);
	}
	//���������� pNodeFrom ��ʼ����pNodeFrom����nCount��nodeֱ��
	//�ƶ���pList�е�pNodeAfter֮�����pNodeAfter=NULL�����Ƶ�pList��ĩβ
	//���nCount<=0�����ʾ��֮��Ķ��ƶ��������ƶ��ĸ���
	INT_PTR MoveTo(
		CEPtrNode<T> *pNodeFrom, 
		INT_PTR nCount,
		CEPtrList<T> *pList, 
		CEPtrNode<T> *pNodeAfter = NULL)
	{
		CEPtrNode<T> *pPrev = pNodeFrom->pPrev;
		CEPtrNode<T> *pNext = pNodeFrom;
		if (nCount > 0)
		{
			INT_PTR x = nCount;
			while (x-- && pNext)
			{
				pNext = pNext->pNext;
			}
			if (pNodeFrom == m_pHead)
			{
				m_pHead = pNext;
			}
			else
			{
				ASSERT(pPrev != NULL);
				if (pPrev)
					pPrev->pNext = pNext;
			}
			if (pNext == NULL)
			{
				m_pTail = pPrev;
			}
			else
			{
				pNext->pPrev = pPrev;
			}
		}
		else
		{
			if (pNodeFrom == m_pHead)
			{
				m_pHead = m_pTail = NULL;
			}
			else
			{
				m_pTail = pPrev;
				if (m_pTail)
					m_pTail->pNext = NULL;
			}
		}
		INT_PTR count = pList->InsertAfter(pNodeAfter, pNodeFrom, nCount);
		m_nCount -= count;
		return count;
	}

	INT_PTR AddTail(CEPtrList<T>* pNewList)
	{
		INT_PTR count = 0;
		if (pNewList->GetCount())
		{
			CEPtrNode<T> *pNext;
			CEPtrNode<T> *pHeadNode = pNewList->GetHeadNode();
			while (pHeadNode)
			{
				pNext = pHeadNode->pNext;
				AddTail(pHeadNode);
				count++;
				pHeadNode = pNext;
			}
			pNewList->RemoveAll(FALSE);
		}
		return count;
	}

	// remove all elements
	void RemoveAll(BOOL bAutoFreeNodes = TRUE)
	{
		if (bAutoFreeNodes)
		{
			// destroy elements
			CEPtrNode<T>* pNode;
			while (m_pHead)
			{
				pNode = m_pHead->pNext;
				if (m_bAutoDeleteData)
				{
					if (m_pHead->pdata)
					{
						delete m_pHead->pdata;
						m_pHead->pdata = NULL;
					}
				}
				delete m_pHead;
				m_nCount--;
				m_pHead = pNode;
			}
			ASSERT(m_nCount == 0);
		}
		m_nCount = 0;
		m_pHead = m_pTail = NULL;
	}

	void RemoveAllExcept(CEPtrNode<T>* pNodeExcept)
	{
		BOOL bExceptFound = FALSE;
		// destroy elements
		CEPtrNode<T>* pNode;
		while (m_pHead)
		{
			pNode = m_pHead->pNext;
			if (pNodeExcept != m_pHead)
			{
				if (m_bAutoDeleteData)
				{
					if (m_pHead->pdata)
					{
						delete m_pHead->pdata;
						m_pHead->pdata = NULL;
					}
				}
				delete m_pHead;
				m_nCount--;
			}
			else
			{
				if (!bExceptFound)
					bExceptFound = TRUE;
			}
			m_pHead = pNode;
		}//end while
		if(!bExceptFound)
		{
			ASSERT(m_nCount == 0);
			m_nCount = 0;
			m_pHead = m_pTail = NULL;
		}
		else
		{
			ASSERT(m_nCount == 1);
			//m_nCount = 0;
			m_pHead = m_pTail = pNodeExcept;
		}
	}

	T GetNext(CEPtrNode<T> *pNode)
	{
		if (pNode->pNext == NULL)
			return NULL;
		return pNode->pNext->pdata;
	}
	//��� node �е� pdata ���б�����Ψһ�Ļ��������ñ�����
	T GetNext(T pCur)
	{
		CEPtrNode<T> *pNode = Find(pCur);
		if (pNode == NULL)
			return NULL;
		if (pNode->pNext == NULL)
			return NULL;
		return pNode->pNext->pdata;
	}
	T GetPrev(CEPtrNode<T> *pNode)
	{
		if (pNode->pPrev == NULL)
			return NULL;
		return pNode->pPrev->pdata;
	}
	//��� node �е� pdata ���б�����Ψһ�Ļ��������ñ�����
	T GetPrev(T pCur)
	{
		CEPtrNode<T> *pNode = Find(pCur);
		if (pNode == NULL)
			return NULL;
		if (pNode->pPrev == NULL)
			return NULL;
		return pNode->pPrev->pdata;
	}

	T GetAt(CEPtrNode<T> *pNode)
	{
		return pNode->pdata;
	}
	void SetAt(CEPtrNode<T> *pNode, T pnew)
	{
		if (pNode->pdata)
		{
			if (m_bAutoDeleteData)
				delete pNode->pdata;
		}
		pNode->pdata = pnew;
	}
	void RemoveAt(CEPtrNode<T> *pNode)
	{
		_remove_no_del(pNode);
		if (m_bAutoDeleteData && pNode->pdata)
			delete pNode->pdata;
		delete pNode;
		m_nCount--;
	}

	//��pInsert��ʼnCount��node���뵽��ǰ�档���nCountС��0����ʾҪ�������е�
	INT_PTR AddHead(CEPtrNode<T> *pInsert, INT_PTR nCount)
	{
		CEPtrNode<T> *pNext = pInsert->pNext;

		pInsert->pNext = m_pHead;
		pInsert->pPrev = NULL;
		//pInsert->pdata = pNew;
		if (m_pHead != NULL)
			m_pHead->pPrev = pInsert;
		else
			m_pTail = pInsert;
		m_pHead = pInsert;
		m_nCount++;
		if (nCount > 0)
		{
			nCount--;
			if (nCount == 0)
				return 1;
		}
		if (pNext == NULL)
			return 1;
		return InsertAfter(m_pHead, pNext, nCount) + 1;
	}
	//��pInsert��ʼnCount��nodeֱ�Ӳ��뵽pCur֮ǰ. ���nCount<0�����ʾpInsert�����ȫ��������
	INT_PTR InsertBefore(CEPtrNode<T> *pCur, CEPtrNode<T> * pInsert, INT_PTR nCount)
	{
		if (pCur == NULL || m_pHead == NULL)
			return AddHead(pInsert, nCount);
		if (pCur->pPrev == NULL)
			return AddHead(pInsert, nCount);
		return InsertAfter(pCur->pPrev, pInsert, nCount);
	}

	CEPtrNode<T> * InsertBefore(CEPtrNode<T> *pCur, CEPtrNode<T> * pInsert)
	{
		if (pCur == NULL || m_pHead == NULL)
			return AddHead(pInsert);
		if (pCur->pPrev == NULL)
			return AddHead(pInsert);
		pInsert->pPrev = pCur->pPrev;
		pInsert->pNext = pCur;
		//pInsert->pdata = xxx;

		if (pCur->pPrev != NULL)
		{
			pCur->pPrev->pNext = pInsert;
		}
		else
		{
			ASSERT(pCur == m_pHead);
			m_pHead = pInsert;
		}
		pCur->pPrev = pInsert;
		m_nCount++;
		return pInsert;
	}
	CEPtrNode<T> * InsertBefore(CEPtrNode<T> *pCur, T pInsert)
	{
		if (pCur == NULL || m_pHead == NULL)
			return AddHead(pInsert);
		CEPtrNode<T> * pNewNode = new CEPtrNode<T>;
		if (pNewNode == NULL)
			return NULL;
		pNewNode->pdata = pInsert;
		return InsertBefore(pCur, pNewNode);
	}
	//��pInsert��ʼnCount��nodeֱ�Ӳ��뵽m_pTail֮��. ���nCount<0�����ʾpInsert�����ȫ��������
	INT_PTR AddTail(CEPtrNode<T> *pInsert, INT_PTR nCount)
	{
		INT_PTR nTotal = 0;
		CEPtrNode<T> *pNext;
		while (pInsert)
		{
			pNext = pInsert->pNext;
			
			pInsert->pPrev = m_pTail;
			pInsert->pNext = NULL;
			//pInsert->pdata = pNew;
			if (m_pTail != NULL)
				m_pTail->pNext = pInsert;
			else
				m_pHead = pInsert;
			m_pTail = pInsert;
			m_nCount++;
			nTotal++;
			if (nCount > 0)
			{
				nCount--;
				if (nCount == 0)
					break;
			}

			pInsert = pNext;
		}//end while
		return nTotal;
	}
	//��pInsert��ʼnCount��nodeֱ�Ӳ��뵽pCur֮��. ���nCount<0�����ʾpInsert�����ȫ��������
	INT_PTR InsertAfter(CEPtrNode<T> *pCur, CEPtrNode<T> * pInsert, INT_PTR nCount)
	{
		if (pCur == NULL || m_pTail == NULL)
			return AddTail(pInsert, nCount); // insert after nothing -> tail of the list
		if (pCur->pNext == NULL)
		{
			ASSERT(pCur == m_pTail);
			return AddTail(pInsert, nCount); // insert after nothing -> tail of the list
		}
		INT_PTR nTotal = 0;
		CEPtrNode<T> *pNext;
		while (pInsert)
		{
			pNext = pInsert->pNext;

			pInsert->pPrev = pCur;
			pInsert->pNext = pCur->pNext;
			//pNewNode->pdata = xxxx;

			if (pCur->pNext != NULL)
			{
				ASSERT(AfxIsValidAddress(pCur->pNext, sizeof(CEPtrNode<T>)));
				pCur->pNext->pPrev = pInsert;
			}
			else
			{
				ASSERT(pCur == m_pTail);
				m_pTail = pInsert;
			}
			pCur->pNext = pInsert;
			m_nCount++;
			nTotal++;
			if (nCount > 0)
			{
				nCount--;
				if (nCount == 0)
					break;
			}

			pCur = pInsert;
			pInsert = pNext;
		}//end while
		return nTotal;
	}

	CEPtrNode<T> * InsertAfter(CEPtrNode<T> *pCur, CEPtrNode<T> * pInsert)
	{
		if (pCur == NULL || m_pTail == NULL)
			return AddTail(pInsert); // insert after nothing -> tail of the list
		pInsert->pPrev = pCur;
		pInsert->pNext = pCur->pNext;
		//pNewNode->pdata = xxxx;

		if (pCur->pNext != NULL)
		{
			ASSERT(AfxIsValidAddress(pCur->pNext, sizeof(CEPtrNode<T>)));
			pCur->pNext->pPrev = pInsert;
		}
		else
		{
			ASSERT(pCur == m_pTail);
			m_pTail = pInsert;
		}
		pCur->pNext = pInsert;
		m_nCount++;
		return pInsert;

	}
	CEPtrNode<T> * InsertAfter(CEPtrNode<T> *pCur, T pInsert)
	{
		if (pCur == NULL || m_pTail == NULL)
			return AddTail(pInsert); // insert after nothing -> tail of the list
		CEPtrNode<T> * pNewNode = new CEPtrNode<T>;
		if (pNewNode == NULL)
			return NULL;
		pNewNode->pdata = pInsert;
		return InsertAfter(pCur, pNewNode);
	}

	// helper functions (note: O(n) speed)
	CEPtrNode<T> * Find(T pTarget, CEPtrNode<T>* startAfter = NULL)
	{
		CEPtrNode<T>* pNode = startAfter;
		if (pNode == NULL)
		{
			pNode = m_pHead;  // start at head
		}
		else
		{
			ASSERT(AfxIsValidAddress(pNode, sizeof(CEPtrNode<T>)));
			pNode = pNode->pNext;  // start after the one specified
		}

		//for (; pNode != NULL; pNode = pNode->pNext)
		//	if (pNode->pdata == pTarget)
		//		return pNode;
		while (pNode!=NULL)
		{
			if (pNode->pdata == pTarget)
				return pNode;
			pNode = pNode->pNext;
		}
		return NULL;
	}
	// defaults to starting at the HEAD, return NULL if not found
	CEPtrNode<T> * FindIndex(INT_PTR nIndex)
	{
		ASSERT(nIndex < m_nCount && nIndex >= 0);
		if (nIndex >= m_nCount || nIndex < 0)
			return NULL;  // went too far
		CEPtrNode<T>* pNode = m_pHead;
		while (nIndex-- && pNode)
		{
			ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
			pNode = pNode->pNext;
		}
		return pNode;
	}
	virtual BOOL Sort(BOOL bAscending)
	{
		if (m_nCount < 2)
			return TRUE;
		INT_PTR size = sizeof(CEPtrNode<T> *) * m_nCount;
		CEPtrNode<T> ** pa = (CEPtrNode<T> **)new BYTE[size];
		if (pa == NULL)
			return FALSE;
		memset((void*)pa, 0, (size_t)size);
		INT_PTR i = 0;
		CEPtrNode<T> * pN = m_pHead;
		while (pN)
		{
			pa[i++] = pN;
			pN = pN->pNext;
		}
		CompareContext ctx;
		ctx.pThis = this;
		ctx.bAscending = bAscending;
		qsort_s(
			&pa[0],
			m_nCount,
			sizeof(CEPtrNode<T> *),
			&CEPtrList<T>::_compare_proc,
			&ctx
			);
		m_pHead = m_pTail = NULL;
		for (i = 0; i < m_nCount; i++)
		{
			if (m_pHead == NULL)
			{
				m_pHead = pa[i];
				m_pHead->pPrev = NULL;
				if (i < m_nCount - 1)
					m_pHead->pNext = pa[i + 1];
				else
					m_pHead->pNext = NULL;
			}
			else
			{
				pa[i]->pPrev = pa[i - 1];
				if (i < m_nCount - 1)
					pa[i]->pNext = pa[i + 1];
				else
					pa[i]->pNext = NULL;
			}
			m_pTail = pa[i];
		}//end for
		delete [](BYTE*)pa;
		return TRUE;
	}
protected:
	struct CompareContext
	{
		CEPtrList<T> *pThis;
		BOOL bAscending;
	};
	static int _compare_proc(void *pContext, const void *ppX1, const void *ppX2)
	{
		CompareContext *pctx = (CompareContext *)pContext;
		CEPtrNode<T> *pNode1 = *(CEPtrNode<T> **)ppX1;
		CEPtrNode<T> *pNode2 = *(CEPtrNode<T> **)ppX2;
		return pctx->pThis->OnCompare(pctx->bAscending, pNode1, pNode2);
	}
	virtual int OnCompare(BOOL bAscending, CEPtrNode<T> *pNode1, CEPtrNode<T> *pNode2)
	{
		//if (bAscending)
		//	return 1;
		//else
		//	return -1;
		return 0;	//return 1 pNode1 first, 0 not change, -1 pNode2 first
	}
	void _remove_no_del(CEPtrNode<T> *pNode)
	{
		CEPtrNode<T> *pPrev = pNode->pPrev;
		CEPtrNode<T> *pNext = pNode->pNext;
		if (pNode == m_pHead)
		{
			m_pHead = pNext;
		}
		else
		{
			ASSERT(pPrev != NULL);
			if (pPrev)
				pPrev->pNext = pNext;
		}
		if (pNode == m_pTail)
		{
			m_pTail = pPrev;
		}
		else
		{
			ASSERT(pNext != NULL);
			if (pNext)
				pNext->pPrev = pPrev;
		}
		//#ifdef _DEBUG
		if (m_pHead)
			ENSURE(m_pHead->pPrev == NULL);
		if (m_pTail)
			ENSURE(m_pTail->pNext == NULL);
		//#endif
	}
};


template<class T>
struct CENodePlex
{
	CENodePlex<T> *pPrev;
	CENodePlex<T> *pNext;
	UINT uFreeCount;		//���ڴ�����ж��ٸ����е�Ԫ��
	CEPtrNode<T> *pStart;	//���е�Ԫ��ַ��ʼλ��
	CEPtrNode<T> *pEnd;		//���е�Ԫ��ַ����λ��
};

template<class T>
inline CENodePlex<T>* PlexCreate(
	/*_Inout_ CENodePlex<T>*& pHead,*/
	_In_ size_t nMax,
	_In_ size_t nElementSize)
{
	//CENodePlex<T>* pPlex;

	ATLASSERT(nMax > 0);
	ATLASSERT(nElementSize > 0);

	size_t nBytes = 0;
	if (FAILED(::ATL::AtlMultiply(&nBytes, nMax, nElementSize)) ||
		FAILED(::ATL::AtlAdd(&nBytes, nBytes, sizeof(CENodePlex<T>))))
	{
		return NULL;
	}
	/*pPlex = */ return static_cast< CENodePlex<T>* >(malloc(nBytes));
	//if (pPlex == NULL)
	//{
	//	return(NULL);
	//}
	//pPlex->pPrev = NULL;
	//pPlex->pNext = pHead;
	//if (pHead)
	//	pHead->pPrev = pPlex;
	//pHead = pPlex;

	//return pPlex;
}

template<class T>
inline void PlexFreeDataChains(CENodePlex<T> *pStart, INT_PTR count = -1)
{
	CENodePlex<T>* pPlex;
	CENodePlex<T>* pNext;
	ATLASSERT(pStart);
	pPlex = pStart;
	while (pPlex != NULL)
	{
		pNext = pPlex->pNext;
		if (pPlex->pPrev)
			pPlex->pPrev->pNext = pPlex->pNext;
		if (pPlex->pNext)
			pPlex->pNext->pPrev = pPlex->pPrev;
		free(pPlex);
		if (count > 0)
		{
			count--;
			if (count == 0)
				break;
		}
		pPlex = pNext;
	}
}

//�ñ���Ԥ��ռ�ķ�ʽ������ٶȡ���΢���ı����ռ䲻ͬ�����ռ�������̬�ͷţ�����һֱ���͡�
template<class T>
class CEPlexMem
{
public:
	CEPlexMem(UINT nBlockSize)
		:m_nBlockSize(nBlockSize)
		, m_pBlocks(NULL)
		, m_pFreeNode(NULL)
		, m_nBlocksCount(0)
	{

	}
	virtual ~CEPlexMem()
	{
		if (m_pBlocks)
		{
			ASSERT(m_nBlocksCount);
			PlexFreeDataChains(m_pBlocks, -1);
			m_pBlocks = NULL;
			m_nBlocksCount = 0;
		}
		m_pFreeNode = NULL;
	}
public:
	//�ڴ�鴴��
	bool CreateFreeNodesIfNeeded()
	{
		if (m_pFreeNode == NULL)
		{
			CENodePlex<T>* pPlex;
			CEPtrNode<T>* pNode;

			pPlex = PlexCreate(
				/*m_pBlocks,*/
				m_nBlockSize,
				sizeof(CEPtrNode<T>));
			if (pPlex == NULL)
			{
				AtlThrow(E_OUTOFMEMORY);
				return false;
			}
			pPlex->pPrev = NULL;
			pPlex->pNext = m_pBlocks;
			i(m_pBlocks)
				m_pBlocks->pPrev = pPlex;
			m_pBlocks = pPlex;
			m_nBlocksCount++;
			pNode = (CEPtrNode<T>*)(&pPlex[1]);
			pPlex->uFreeCount = m_nBlockSize;
			pPlex->pStart = pNode;
			pNode += m_nBlockSize - 1;
			pPlex->pEnd = pNode;
			//�����������
			for (int iBlock = m_nBlockSize - 1; iBlock >= 0; iBlock--)
			{
				pNode->pPrev = NULL;
				pNode->pNext = m_pFreeNode;
				if (m_pFreeNode)
					m_pFreeNode->pPrev = pNode;
				m_pFreeNode = pNode;
				pNode--;
			}
		}
		ATLASSUME(m_pFreeNode != NULL);
		return true;
	}
	//�½�
	CEPtrNode<T>* NewNode(
		CEPtrNode<T>* pPrev,
		CEPtrNode<T>* pNext)
	{
		if (!CreateFreeNodesIfNeeded())
			return NULL;
		CEPtrNode<T>* pNewNode = CreateNode();
		pNewNode->pPrev = pPrev;
		pNewNode->pNext = pNext;
		return pNewNode;
	}
	//�½�
	CEPtrNode<T>* NewNode(
		T pdata,
		CEPtrNode<T>* pPrev,
		CEPtrNode<T>* pNext)
	{
		if (!CreateFreeNodesIfNeeded())
			return NULL;
		CEPtrNode<T>* pNewNode = CreateNode();
		pNewNode->m_pPrev = pPrev;
		pNewNode->m_pNext = pNext;
		pNewNode->pdata = pdata;
		return pNewNode;
	}
	//����
	void FreeNode(IN OUT CEPtrNode<T>* pNode) throw()
	{
		pNode->~CEPtrNode<T>();
		pNode->pPrev = NULL;
		pNode->pNext = m_pFreeNode;
		if (m_pFreeNode)
			m_pFreeNode->pPrev = pNode;
		m_pFreeNode = pNode;
		//��Ԫ���պ󣬿��ܻ�����������ڴ���ͷ�
		CENodePlex<T>* pPlex = m_pBlocks;
		CENodePlex<T>* pPlexNext;
		while (pPlex)
		{
			pPlexNext = pPlex->pNext;
			//�����ڴ��ַ���ҹ���
			if (pNode >= pPlex->pStart && pNode <= pPlex->pEnd)
			{
				pPlex->uFreeCount++;	//���е�Ԫ����
				//����ﵽm_nBlockSize�����ǿ����Ƿ����ͷŸ��ڴ��
				if (pPlex->uFreeCount >= m_nBlockSize)
				{
					//�ٶ����ȣ����ٱ���1���ڴ�鲻�ͷ�
					if (m_nBlocksCount > 1)
					{
						//���ͷŸ��ڴ��֮ǰ����Ҫ�ȴӿ��е�Ԫ�б�����ȥ�������ڱ������
						CEPtrNode<T>* pFreeNode = m_pFreeNode;
						CEPtrNode<T>* pFreeNodeNext;
						while (pFreeNode)
						{
							pFreeNodeNext = pFreeNode->pNext;
							if (pFreeNode >= pPlex->pStart && pFreeNode <= pPlex->pEnd)
							{
								if (pFreeNode->pPrev)
									pFreeNode->pPrev->pNext = pFreeNode->pNext;
								if (pFreeNode->pNext)
									pFreeNode->pNext->pPrev = pFreeNode->pPrev;
								//ע�⣺������ȥ������ free ���� delete����Ϊ���Ŀռ����ڱ��ڴ��
							}
							pFreeNode = pFreeNodeNext;
						}//end while
						PlexFreeDataChains(pPlex, 1);
						m_nBlocksCount--;
					}//end if agree
				}//end if FreeCount
				break;
			}//end if scope
			pPlex = pPlexNext;
		}//end while
	}
public:
	INT_PTR m_nBlocksCount;
	CENodePlex<T>* m_pBlocks;
	CEPtrNode<T> * m_pFreeNode;
	UINT m_nBlockSize;
protected:
	CEPtrNode<T> * CreateNode()
	{
		ATLASSERT(m_pFreeNode);
		CEPtrNode<T>* pNewNode = m_pFreeNode;
		CEPtrNode<T>* pNextFree = m_pFreeNode->pNext;
#pragma push_macro("new")
#undef new
		::new(pNewNode)CEPtrNode<T>;
#pragma pop_macro("new")
		m_pFreeNode = pNextFree;
		if (m_pFreeNode)
			m_pFreeNode->pPrev = NULL;
		ATLASSERT(m_pBlocks);
		CENodePlex<T>* pPlex = m_pBlocks;
		while (pPlex)
		{
			//�����ڴ��ַ���ҹ���
			if (pNewNode >= pPlex->pStart && pNewNode <= pPlex->pEnd)
			{
				ASSERT(pPlex->uFreeCount > 0);
				pPlex->uFreeCount--;	//���е�Ԫ����
				break;
			}
			pPlex = pPlex->pNext;
		}
		return pNewNode;
	}
};
