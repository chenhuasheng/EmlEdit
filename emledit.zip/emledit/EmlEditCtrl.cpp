// EmlEditCtrl.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "EmlEditCtrl.h"
//#include <locale.h>
#include "internalLock.h"

/////////////////////////////////////////////////////////////////////////////////
CXEditCtrlTextManager::CXEditCtrlTextManager(CXEditCtrl *pCtrl)
	:m_pCtrl(pCtrl)
{

}
void CXEditCtrlTextManager::OnCaretMove(PEObjLink pCaret)
{
	CETextManager::OnCaretMove(pCaret);
	m_pCtrl->OnCaretMove(pCaret);
}

/////////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CXEditCtrl, CWnd)
CXEditCtrl::CXEditCtrl()
:m_tm(this), m_nWheelScroll(4)
{
	//m_bIsOverwriteMode = FALSE;
	m_pParentWnd = NULL;
	m_bIMEsupported = FALSE;
	//memset(&m_defFont, 0, sizeof(m_defFont));
	m_bWndCreateInProgress = FALSE;
	//m_sizeCaret.cx = m_sizeCaret.cy = 0;
	m_rcBorders.SetRect(2, 2, 2, 2);
	//_wsetlocale(LC_ALL, L"zh-CN");
	m_bInitOK = FALSE;
	m_lastCaretSize.cx = m_lastCaretSize.cy = 0;
	m_bSelecting = FALSE;
	m_bMouseTracking = false;
	m_bCaptured = false;
}

CXEditCtrl::~CXEditCtrl()
{
	Uninit();
}


BEGIN_MESSAGE_MAP(CXEditCtrl, CWnd)
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_WM_CHAR()
	ON_WM_SYSCHAR()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_GETDLGCODE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SYSKEYDOWN()
	ON_MESSAGE(WM_SETTEXT, OnSetText)
//	ON_WM_MOUSEHWHEEL()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSELEAVE()
END_MESSAGE_MAP()

UINT CXEditCtrl::OnGetDlgCode()
{
	return DLGC_WANTTAB | DLGC_WANTARROWS | 
		DLGC_WANTCHARS | DLGC_WANTALLKEYS | DLGC_WANTMESSAGE;
	//return CWnd::OnGetDlgCode();
}

BOOL CXEditCtrl::Create(DWORD dwStyle, CWnd *pParent, const RECT& rect, UINT id)
{
	LPCWSTR wszclass = AfxRegisterWndClass(
		CS_DBLCLKS | CS_VREDRAW | CS_HREDRAW,
		LoadCursor(NULL, IDC_IBEAM /*IDC_ARROW*/),
		(HBRUSH)GetStockObject(WHITE_BRUSH),
		::LoadIcon(NULL, IDI_APPLICATION));
	m_pParentWnd = pParent;
	return CWnd::Create(
		wszclass,
		L"",
		dwStyle,
		rect, pParent, id, NULL);
}
void CXEditCtrl::SetBorders(LONG left, LONG top, LONG right, LONG bottom)
{
	m_rcBorders.SetRect(left, top, right, bottom);
	if (m_bInitOK)
	{
		CRect rcc;
		GetClientRect(&rcc);
		rcc.DeflateRect(m_rcBorders.left, m_rcBorders.top, m_rcBorders.right, m_rcBorders.bottom);
		m_tm.SetTextRect(rcc);
		InvalidateRect(NULL);
	}
}
void CXEditCtrl::OnCaretMove(PEObjLink pCaret)
{
	NotifyCaretMove(pCaret);
}
void CXEditCtrl::NotifyCaretMove(PEObjLink pCaret)
{
	NMHDR_XEDCTRL_CARETMOVE src;

	// NMHDR codes
	src.nmhdr.code = XEDCTRL_CARETMOVE;
	src.nmhdr.hwndFrom = m_hWnd;
	src.nmhdr.idFrom = GetDlgCtrlID();

	src.pCaret = pCaret;
	src.pLine = m_tm.GetLine(pCaret, NULL, NULL, NULL);

	// Notify the parent window
	if (::IsWindow(m_pParentWnd->GetSafeHwnd()))
	{
		m_pParentWnd->SendMessage(
			WM_NOTIFY, (WPARAM)src.nmhdr.idFrom, (LPARAM)&src);
	}
}

BOOL CXEditCtrl::InsertBitmap(HBITMAP hBmp)
{
	CRect rcChanged(0, 0, 0, 0);
	if (m_tm.InsertBitmap(hBmp, &rcChanged))
	{
		CSize sizeNew = m_tm.GetCaretSize();
		if (sizeNew != m_lastCaretSize)
			CreateCaret();
		else
			SetCaretPos(m_tm.GetCaretPos());
		//ֻ��Ҫˢ�±䶯�������򼴿�
		if (!rcChanged.IsRectEmpty())
		{
			InvalidateRect(&rcChanged);
		}
		else
			InvalidateRect(NULL);
		return TRUE;
	}
	return FALSE;
}
BOOL CXEditCtrl::InsertImage(LPCWSTR wszImageFile)
{
	CImage img;
	if (img.Load(wszImageFile) != S_OK)
		return FALSE;
	HBITMAP hBmp = img.Detach();
	if (!InsertBitmap(hBmp))
	{
		::DeleteObject(hBmp);
		return FALSE;
	}
	return TRUE;
}

BOOL CXEditCtrl::SpeelCheck(BOOL bEnDict,BOOL bCnDict)
{
	CWaitCursor cur;
	CClientDC dc(this);
	DWORD dwFlags=0;
	if (bEnDict)
		dwFlags |= SPELLCHECK_EN_DICT;
	if (bCnDict)
		dwFlags |= SPELLCHECK_CN_DICT;
	if (m_tm.SpellCheck(&dc, dwFlags))
	{
		InvalidateRect(NULL);
		return TRUE;
	}
	return FALSE;
}
void CXEditCtrl::EndSpeelCheck()
{
	m_tm.EndSpellCheck();
	InvalidateRect(NULL);
}
void CXEditCtrl::SetDefaultFont(
	PLOGFONTW pFont,
	COLORREF crTextColor,
	COLORREF crBgColor)
{
	CETextRange *pRange=m_tm.GetTextRange(NULL);
	pRange->m_font = *pFont;
	pRange->m_crText = crTextColor;
	pRange->m_crBk = crBgColor;
	if (m_bInitOK)
	{
		m_tm.CalcParagraphs();
		CRect rcc;
		GetClientRect(&rcc);
		rcc.DeflateRect(m_rcBorders.left, m_rcBorders.top, m_rcBorders.right, m_rcBorders.bottom);
		m_tm.SetTextRect(rcc);
		InvalidateRect(NULL);
	}
}

BOOL CXEditCtrl::OnEraseBkgnd(CDC* pDC)
{
	UNREFERENCED_PARAMETER(pDC);
	//if(m_tm.DrawBk(pDC))
		return TRUE;
	//return CWnd::OnEraseBkgnd(pDC);
}

void CXEditCtrl::CancelSelecting()
{
	if (!m_tm.IsSelectingEmpty())
	{
		CRect rcSelect(0, 0, 0, 0);
		m_tm.GetSelectionUpdateArea(&rcSelect);
		m_tm.CancelSelecting();
		if (!rcSelect.IsRectEmpty())
			InvalidateRect(&rcSelect);
	}
}

void CXEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CXTPSmartPtrInternalT<CCmdTarget> ptrThisLock(this, TRUE);
	if (nChar == 0)
	{
		return;
	}
	BOOL bCtrlKey = (::GetKeyState(VK_CONTROL) & KF_UP) != 0;
	BOOL bShiftKey = (::GetKeyState(VK_SHIFT) & KF_UP) != 0;
	//TRACE(L"bCtrlKey=%d bShiftKey=%d\n", bCtrlKey, bShiftKey);
	CRect rcChanged(0, 0, 0, 0);
	CRect rcSelect(0, 0, 0, 0);
	CRect rcSelectOld(0, 0, 0, 0);
	BOOL bRet;
	switch (nChar)
	{
	case VK_UP:
		if (bShiftKey)
		{
			if (!m_bSelecting)
			{
				if (!m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_tm.SetStartSelecting())
					m_bSelecting = TRUE;
			}
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
		}
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (m_tm.CaretGoUpLine(&rcChanged))
		{
			//CRect rcSelect(0, 0, 0, 0);
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
		}
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		if (!rcSelectOld.IsRectEmpty())
			InvalidateRect(&rcSelectOld);
		break;
	case VK_DOWN:
		if (bShiftKey)
		{
			if (!m_bSelecting)
			{
				if (!m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_tm.SetStartSelecting())
					m_bSelecting = TRUE;
			}
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
		}
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (m_tm.CaretGoDownLine(&rcChanged))
		{
			//CRect rcSelect(0, 0, 0, 0);
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
		}
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		if (!rcSelectOld.IsRectEmpty())
			InvalidateRect(&rcSelectOld);
		break;
	case VK_LEFT:
		if (bShiftKey)
		{
			if (!m_bSelecting)
			{
				if (!m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_tm.SetStartSelecting())
					m_bSelecting = TRUE;
			}
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
		}
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (m_tm.CaretGoLeft(&rcChanged))
		{
			//CRect rcSelect(0, 0, 0, 0);
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
		}
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		if (!rcSelectOld.IsRectEmpty())
			InvalidateRect(&rcSelectOld);
		break;
	case VK_RIGHT:
		if (bShiftKey)
		{
			if (!m_bSelecting)
			{
				if (!m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_tm.SetStartSelecting())
					m_bSelecting = TRUE;
			}
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
		}
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (m_tm.CaretGoRight(&rcChanged))
		{
			//CRect rcSelect(0, 0, 0, 0);
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
		}
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		if (!rcSelectOld.IsRectEmpty())
			InvalidateRect(&rcSelectOld);
		break;
	case VK_HOME:
		if (bShiftKey)
		{
			if (!m_bSelecting)
			{
				if (!m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_tm.SetStartSelecting())
					m_bSelecting = TRUE;
			}
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
		}
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (bCtrlKey)
			bRet = m_tm.CaretGoHead(&rcChanged);	//����ƶ������µ���ǰ��
		else
			bRet = m_tm.CaretGoTopLeft(&rcChanged);
		if (bRet)
		{
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
		}
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		if (!rcSelectOld.IsRectEmpty())
			InvalidateRect(&rcSelectOld);
		break;
	case VK_END:
		if (bShiftKey)
		{
			if (!m_bSelecting)
			{
				if (!m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_tm.SetStartSelecting())
					m_bSelecting = TRUE;
			}
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
		}
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (bCtrlKey)
			bRet = m_tm.CaretGoTail(&rcChanged);	//����ƶ������µ������
		else
			bRet = m_tm.CaretGoTopRight(&rcChanged);
		if (bRet)
		{
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
		}
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		if (!rcSelectOld.IsRectEmpty())
			InvalidateRect(&rcSelectOld);
		break;
	case VK_PRIOR:	//VK_PRIOR Page_Up�� 0x21
	{
		int nScroll = m_tm.GetPageHeight(TRUE);
		if (nScroll)
		{
			HideCaret();
			DestroyCaret();
			m_lastCaretSize.cx = m_lastCaretSize.cy = 0;
			CPoint ptOldCaretPos = m_tm.GetCaretPos();
			CRect rcChanged(0, 0, 0, 0);
			if (bShiftKey)
			{
				if (!m_bSelecting)
				{
					if (!m_tm.IsSelectingEmpty())
						CancelSelecting();
					if (m_tm.SetStartSelecting())
						m_bSelecting = TRUE;
				}
			}
			else
			{
				if (m_bSelecting || !m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_bSelecting)
					m_bSelecting = FALSE;
			}
			if (!m_tm.IsSelectingEmpty())
				m_tm.GetSelectionUpdateArea(&rcSelectOld);
			m_tm.ScrollParagraphs(0,
				nScroll,
				NULL, &rcChanged, NULL);
			m_tm.MoveCaretNear(ptOldCaretPos);
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			if (!rcChanged.IsRectEmpty())
				InvalidateRect(&rcChanged);
			if (!rcSelectOld.IsRectEmpty())
				InvalidateRect(&rcSelectOld);
			CreateCaret();
			SetCaretPos(m_tm.GetCaretPos());
			ShowCaret();
		}
	}
		break;
	case VK_NEXT:	//VK_NEXT Page_Down�� 0x22 
	{
		int nScroll = m_tm.GetPageHeight(FALSE);
		if (nScroll)
		{
			HideCaret();
			DestroyCaret();
			m_lastCaretSize.cx = m_lastCaretSize.cy = 0;
			CPoint ptOldCaretPos = m_tm.GetCaretPos();
			CRect rcChanged(0, 0, 0, 0);
			if (bShiftKey)
			{
				if (!m_bSelecting)
				{
					if (!m_tm.IsSelectingEmpty())
						CancelSelecting();
					if (m_tm.SetStartSelecting())
						m_bSelecting = TRUE;
				}
			}
			else
			{
				if (m_bSelecting || !m_tm.IsSelectingEmpty())
					CancelSelecting();
				if (m_bSelecting)
					m_bSelecting = FALSE;
			}
			if (!m_tm.IsSelectingEmpty())
				m_tm.GetSelectionUpdateArea(&rcSelectOld);
			m_tm.ScrollParagraphs(0,
				-nScroll,
				NULL, &rcChanged, NULL);
			m_tm.MoveCaretNear(ptOldCaretPos);
			if (m_bSelecting)
			{
				if (m_tm.SetEndSelecting())
					m_tm.GetSelectionUpdateArea(&rcSelect);
			}
			if (!rcSelect.IsRectEmpty())
			{
				if (rcChanged.IsRectEmpty())
					rcChanged = rcSelect;
				else
					rcChanged.UnionRect(&rcChanged, &rcSelect);
			}
			if (!rcChanged.IsRectEmpty())
				InvalidateRect(&rcChanged);
			if (!rcSelectOld.IsRectEmpty())
				InvalidateRect(&rcSelectOld);
			CreateCaret();
			SetCaretPos(m_tm.GetCaretPos());
			ShowCaret();
		}
	}
		//m_tm.PageDown();
		break;
	case VK_DELETE:
		break;
	case VK_BACK:
		break;
	case VK_INSERT:
		break;
	case VK_SPACE:
		break;
	default:
		break;
	}
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CXEditCtrl::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CXTPSmartPtrInternalT<CCmdTarget> ptrThisLock(this, TRUE);
	BOOL bAltKey = (::GetKeyState(VK_MENU) & KF_UP) != 0;
	BOOL bCtrlKey = (::GetKeyState(VK_CONTROL) & KF_UP) != 0;
	BOOL bShiftKey = (::GetKeyState(VK_SHIFT) & KF_UP) != 0;
	//TRACE(L"bCtrlKey=%d bShiftKey=%d bAltKey=%d\n", bCtrlKey, bShiftKey, bAltKey);
	if (!bShiftKey)
	{
		if (m_bSelecting)
		{
			m_bSelecting = FALSE;
			if (!m_tm.IsSelectingEmpty())
			{
				CRect rcSelect(0, 0, 0, 0);
				m_tm.GetSelectionUpdateArea(&rcSelect);
				if (!rcSelect.IsRectEmpty())
					InvalidateRect(&rcSelect);
			}
		}
	}
	if (nChar == VK_INSERT && !bAltKey && !bCtrlKey && !bShiftKey)
	{
		//WCHAR wszText[2] = { L'H', 0 };
		//CClientDC dc(this);
		//CSize size = dc.GetTextExtent(wszText, 1);
		BOOL bOverwrite = m_tm.GetOverwriteMode();	//IsOverwriteMode
		bOverwrite = !bOverwrite;
		m_tm.SetOverwriteMode(bOverwrite);
		//m_bIsOverwriteMode = !m_bIsOverwriteMode;
		//HideCaret();
		CreateCaret();
		m_tm.FixCaretPosition();
		SetCaretPos(m_tm.GetCaretPos());
		//DestroyCaret();
		//CSize sizeCaret = m_tm.GetCaretSize();
		//if (bOverwrite/*m_bIsOverwriteMode*/)
		//{
		//	//m_sizeCaret = size;
		//	//CSize sizeCaret = m_tm.GetCaretSize();
		//	//CreateGrayCaret(size.cx, size.cy);
		//	/*CreateGrayCaret*/CreateSolidCaret(sizeCaret.cx, sizeCaret.cy);
		//	TRACE(L"Change caret to overwrite mode, size cx=%d,cy=%d\n", sizeCaret.cx, sizeCaret.cy);
		//}
		//else
		//{
		//	//m_sizeCaret.cx = 1;
		//	//m_sizeCaret.cy = size.cy;
		//	CreateSolidCaret(sizeCaret.cx, sizeCaret.cy);
		//	TRACE(L"Change caret to insert mode, size cx=%d,cy=%d\n", sizeCaret.cx, sizeCaret.cy);
		//}
		//SetCaretPos(m_tm.GetCaretPos());
		//ShowCaret();
	}
	CWnd::OnKeyUp(nChar, nRepCnt, nFlags);
}

void CXEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	BOOL bAltKey = (::GetKeyState(VK_MENU) & KF_UP) != 0;
	BOOL bCtrlKey = (::GetKeyState(VK_CONTROL) & KF_UP) != 0;
	BOOL bShiftKey = (::GetKeyState(VK_SHIFT) & KF_UP) != 0;
	if (nChar == VK_ESCAPE)
	{
		//Unselect();
	}
	else if (nChar != VK_BACK && !(bCtrlKey && !bAltKey))
	{
		WCHAR szText[3];
		szText[0] = (WCHAR)nChar;
		szText[1] = 0;
		CClientDC dc(this);
		CRect rcChanged(0, 0, 0, 0);
		LONG count = m_tm.InsertText(szText, &dc, &rcChanged);
		if (count)
		{
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
			//SetCaretPos(m_tm.GetCaretPos());
		}
		//ֻ��Ҫˢ�±䶯�������򼴿�
		if (!rcChanged.IsRectEmpty())
		{
			InvalidateRect(&rcChanged);
		}
		else
			InvalidateRect(NULL);
	}
	CWnd::OnChar(nChar, nRepCnt, nFlags);
}

void CXEditCtrl::OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CWnd::OnSysChar(nChar, nRepCnt, nFlags);
}

void CXEditCtrl::OnSetFocus(CWnd* pOldWnd)
{
	CXTPSmartPtrInternalT<CCmdTarget> ptrThisLock(this, TRUE);
	CWnd::OnSetFocus(pOldWnd);
	CreateCaret();
	//SetCaretPos(m_tm.GetCaretPos/*GetCurrentCaretPos*/());
	//ShowCaret();
}


void CXEditCtrl::OnKillFocus(CWnd* pNewWnd)
{
	CXTPSmartPtrInternalT<CCmdTarget> ptrThisLock(this, TRUE);
	CWnd::OnKillFocus(pNewWnd);
	HideCaret();
	DestroyCaret();
	m_lastCaretSize.cx = m_lastCaretSize.cy = 0;
}


void CXEditCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	BOOL bCtrlKey = (::GetKeyState(VK_CONTROL) & KF_UP) != 0;
	BOOL bShiftKey = (::GetKeyState(VK_SHIFT) & KF_UP) != 0;
	if (GetFocus() != this)
		SetFocus();
	CRect rc(0,0,0,0);
	CRect rcSelectOld(0, 0, 0, 0);
	CRect rcSelect(0, 0, 0, 0);
	if (!m_tm.IsSelectingEmpty())
		m_tm.GetSelectionUpdateArea(&rcSelectOld);
#if TEST_CARET_CLICK
	CClientDC dc(this);
	if (m_tm.CaretClick(point, &dc, &rc))
#else
	if (m_tm.CaretClick(point, &rc))
#endif
	{
		CSize sizeNew = m_tm.GetCaretSize();
		if (sizeNew != m_lastCaretSize)
			CreateCaret();
		else
			SetCaretPos(m_tm.GetCaretPos());
		if (bShiftKey)
		{
			if (!m_bSelecting)
				m_bSelecting = TRUE;
			if (m_tm.SetEndSelecting())
				m_tm.GetSelectionUpdateArea(&rcSelect);
		}
		else
		{
			if (m_bSelecting || !m_tm.IsSelectingEmpty())
				CancelSelecting();
			if (m_bSelecting)
				m_bSelecting = FALSE;
			m_tm.SetStartSelecting();//��ÿ�ε���������������
		}
		if (!rcSelect.IsRectEmpty())
		{
			if (rc.IsRectEmpty())
				rc = rcSelect;
			else
				rc.UnionRect(&rc, &rcSelect);
		}
	}
	if (!rcSelectOld.IsRectEmpty())
	{
		if (rc.IsRectEmpty())
			rc = rcSelectOld;
		else
			rc.UnionRect(&rc, &rcSelectOld);
	}
	if (!rc.IsRectEmpty())
		InvalidateRect(&rc);
	CWnd::OnLButtonDown(nFlags, point);
}


void CXEditCtrl::OnLButtonUp(UINT nFlags, CPoint point)
{
	BOOL bCtrlKey = (::GetKeyState(VK_CONTROL) & KF_UP) != 0;
	BOOL bShiftKey = (::GetKeyState(VK_SHIFT) & KF_UP) != 0;

	if (m_bCaptured)
	{
		if (ReleaseCapture())
			m_bCaptured = false;
		if (m_bSelecting)
		{
			m_bSelecting = FALSE;
			if (!m_tm.IsSelectingEmpty())
			{
				CRect rcSelect(0, 0, 0, 0);
				m_tm.GetSelectionUpdateArea(&rcSelect);
				if (!rcSelect.IsRectEmpty())
					InvalidateRect(&rcSelect);
			}
		}
	}

	CWnd::OnLButtonUp(nFlags, point);
}

void CXEditCtrl::OnMouseMove(UINT nFlags, CPoint point)
{
	//TRACE(L"OnMouseMove %d,%d\n", point.x, point.y);
	if (!m_bMouseTracking)
	{
		TRACKMOUSEEVENT ev = { 0 };
		ev.cbSize = sizeof(ev);
		ev.dwFlags = TME_LEAVE;
		ev.dwHoverTime = HOVER_DEFAULT;
		ev.hwndTrack = m_hWnd;
		if (TrackMouseEvent(&ev))
			m_bMouseTracking = true;
		//TRACE(L"OnMouseMove Tracking %d\n", m_bMouseTracking);
	}
	BOOL bCtrlKey = (nFlags & MK_CONTROL) != 0;
	BOOL bShiftKey = (nFlags & MK_SHIFT) != 0;
	BOOL bLButtonDown = (nFlags & MK_LBUTTON) != 0;
	if (bLButtonDown)
	{
		if (GetCapture() != this)
		{
			SetCapture();
			if (!m_bCaptured)
				m_bCaptured = true;
		}
		CRect rcSelectOld(0, 0, 0, 0);
		CRect rcSelect(0, 0, 0, 0);
		//CRect rcChanged(0, 0, 0, 0);
		if (!m_tm.IsSelectingEmpty())
			m_tm.GetSelectionUpdateArea(&rcSelectOld);
		if (m_tm.MoveCaretNear(point,TRUE))
		{
			if (!m_bSelecting)
				m_bSelecting = TRUE;
			if (m_tm.SetEndSelecting())
				m_tm.GetSelectionUpdateArea(&rcSelect);
			CSize sizeNew = m_tm.GetCaretSize();
			if (sizeNew != m_lastCaretSize)
				CreateCaret();
			else
				SetCaretPos(m_tm.GetCaretPos());
			if (!rcSelect.IsRectEmpty() && !rcSelectOld.IsRectEmpty())
			{
				rcSelect.UnionRect(&rcSelect, &rcSelectOld);
				InvalidateRect(&rcSelect);
			}
			else
			{
				if(!rcSelect.IsRectEmpty())
					InvalidateRect(&rcSelect);
				if(!rcSelectOld.IsRectEmpty())
					InvalidateRect(&rcSelectOld);
			}
			//m_tm.EnsureCaretVisible(&rcChanged);
			//if (!rcChanged.IsRectEmpty())
			//	InvalidateRect(&rcChanged);
		}//end if (m_tm.MoveCaretNear(point))
		CRect rcText = m_tm.GetTextRect();
		int zDelta = 0;
		if (point.y <= rcText.top + 10)
			zDelta = 16/*WHEEL_DELTA*/;
		else if (point.y >= rcText.bottom - 10)
			zDelta = -16;	// WHEEL_DELTA;
		if (zDelta)
		{
			int nScroll = m_tm.GetScrollStep(zDelta);
			if (nScroll)
			{
				HideCaret();
				DestroyCaret();
				m_lastCaretSize.cx = m_lastCaretSize.cy = 0;
				CRect rcChanged(0, 0, 0, 0);
				m_tm.ScrollParagraphs(0,
					zDelta>0 ? nScroll : -nScroll,
					NULL, &rcChanged, NULL);
				//if (zDelta < 0)
				//	m_tm.ScrollParagraphs(0, -m_nWheelScroll,NULL,&rcChanged,NULL);
				//else
				//	m_tm.ScrollParagraphs(0, m_nWheelScroll, NULL, &rcChanged, NULL);
				if (!rcChanged.IsRectEmpty())
					InvalidateRect(&rcChanged);
				CreateCaret();
				SetCaretPos(m_tm.GetCaretPos());
				ShowCaret();
			}
		}//end if (zDelta)
	}//end if (bLButtonDown)
	CWnd::OnMouseMove(nFlags, point);
}


void CXEditCtrl::OnMouseLeave()
{
	if (m_bMouseTracking)
	{
		TRACKMOUSEEVENT ev = { 0 };
		ev.cbSize = sizeof(ev);
		ev.dwFlags = TME_LEAVE | TME_CANCEL;
		ev.dwHoverTime = HOVER_DEFAULT;
		ev.hwndTrack = m_hWnd;
		if (TrackMouseEvent(&ev))
			m_bMouseTracking = false;
		//TRACE(L"OnMouseLeave Tracking %d\n", m_bMouseTracking);
	}
	if (m_bSelecting)
	{
		m_bSelecting = FALSE;
		if (!m_tm.IsSelectingEmpty())
		{
			CRect rcSelect(0, 0, 0, 0);
			m_tm.GetSelectionUpdateArea(&rcSelect);
			if (!rcSelect.IsRectEmpty())
				InvalidateRect(&rcSelect);
		}
	}

	CWnd::OnMouseLeave();
}

int CXEditCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	m_bWndCreateInProgress = FALSE;
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	ASSERT(GetSafeHwnd() && ::IsWindow(GetSafeHwnd()));
	if (!Init())
	{
		return -1;
	}
	return 0;
}


void CXEditCtrl::PreSubclassWindow()
{
	//CWnd::PreSubclassWindow();
	if (!m_bWndCreateInProgress)
	{
		m_pParentWnd = GetParent();
		ASSERT(GetSafeHwnd() && ::IsWindow(GetSafeHwnd()));
		if (!Init())
			return;
	}
}


BOOL CXEditCtrl::PreCreateWindow(CREATESTRUCT& cs)
{
	//return CWnd::PreCreateWindow(cs);
	m_bWndCreateInProgress = TRUE;
	return TRUE;
}

BOOL CXEditCtrl::Init()
{
	if (GetSafeHwnd() && ::IsWindow(GetSafeHwnd()))
	{
		LOGFONTW font = { 0 };
		CFont *pFont = GetFont();
		if (pFont)
		{
			pFont->GetLogFont(&font);
		}
		else
		{
			pFont = m_pParentWnd->GetFont();
			if (pFont)
			{
				pFont->GetLogFont(&font);
			}
			else
			{
				NONCLIENTMETRICSW ncm = { 0 };
				ncm.cbSize = sizeof(ncm);
				ATLVERIFY(::SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0));
				//menu font
				//memcpy_s(&m_defFont, sizeof(LOGFONTW), &ncm.lfMenuFont, sizeof(LOGFONTW));
				//message box font
				memcpy_s(&font, sizeof(LOGFONTW), &ncm.lfMessageFont, sizeof(LOGFONTW));
			}
		}

		CClientDC dc(this);
		CFont fo;
		if (!fo.CreateFontIndirectW(&font))
			return FALSE;
		CFont *pxFont=dc.SelectObject(&fo);

		WCHAR wszText[2] = { 0x20, 0 };
		CSize size = dc.GetTextExtent(wszText, 1);
		int linespace = MulDiv(1, GetDeviceCaps(dc.GetSafeHdc(), LOGPIXELSY), 72);
		int letterspace = 0;
		if (!m_tm.Init(linespace, 
			letterspace, 
			size.cx * 4,
			size.cy,
			&font,
			GetSysColor(COLOR_WINDOW),
			GetSysColor(COLOR_WINDOWTEXT),
			FALSE,TRUE))
			return FALSE;
		CRect rcc;
		GetClientRect(&rcc);
		rcc.DeflateRect(m_rcBorders.left, m_rcBorders.top, m_rcBorders.right, m_rcBorders.bottom);
		m_tm.SetTextRect(rcc);

		dc.SelectObject(pxFont);

		//CSize sizeCaret = m_tm.GetCaretSize();
		//if (m_tm.IsOverwriteMode())
		//{
		//	CreateGrayCaret(sizeCaret.cx, sizeCaret.cy);
		//}
		//else
		//{
		//	CreateSolidCaret(sizeCaret.cx, sizeCaret.cy);
		//}
		//SetCaretPos(m_tm.GetCaretPos/*GetCurrentCaretPos*/());
		CreateCaret();
		//if (m_bIsOverwriteMode)
		//{
		//	m_sizeCaret = size;
		//	CreateSolidCaret(size.cx, size.cy);
		//}
		//else
		//{
		//	m_sizeCaret.cx = 1;
		//	m_sizeCaret.cy = size.cy;
		//	CreateSolidCaret(1, size.cy);
		//}

		_UpdateIMEStatus();
	}
	m_bInitOK = TRUE;
	return TRUE;
}
void CXEditCtrl::CreateCaret()
{
	HideCaret();
	DestroyCaret();
	CSize sizeCaret = m_tm.GetCaretSize();
	if (m_tm.IsOverwriteMode())
	{
		CreateSolidCaret(sizeCaret.cx, sizeCaret.cy);
	}
	else
	{
		CreateSolidCaret(sizeCaret.cx, sizeCaret.cy);
	} 
	m_tm.SetCaretHeight(sizeCaret.cy);
	SetCaretPos(m_tm.GetCaretPos());
	ShowCaret();
	m_lastCaretSize = sizeCaret;	// m_tm.GetCaretSize();
}
void CXEditCtrl::OnDestroy()
{
	Uninit();
	CWnd::OnDestroy();
}
void CXEditCtrl::Uninit()
{
	if (GetSafeHwnd() && ::IsWindow(GetSafeHwnd()))
	{
		DestroyCaret();
	}
}

void CXEditCtrl::_UpdateIMEStatus()
{
	m_bIMEsupported = m_ImmWrapper.ImmIsIME();

	if (!m_bIMEsupported || !m_hWnd || !::IsWindow(m_hWnd))
		return;

	// IME Support

	IMM_HIMC hIMC = m_ImmWrapper.ImmGetContext(m_hWnd);
	if (hIMC)
	{
		CETextRange *pRange=m_tm.GetTextRange(m_tm.GetCaret());
		ASSERT(pRange != NULL);
		VERIFY(m_ImmWrapper.ImmSetCompositionFont(hIMC, &pRange->m_font));

		VERIFY(m_ImmWrapper.ImmReleaseContext(m_hWnd, hIMC));
	}
}

void CXEditCtrl::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	if (m_bmpCache.m_hObject)
		m_bmpCache.DeleteObject();
	CRect rcc;
	GetClientRect(&rcc);
	CClientDC dc(this);
	rcc.DeflateRect(m_rcBorders.left, m_rcBorders.top, m_rcBorders.right, m_rcBorders.bottom);
	m_tm.SetTextRect(rcc);
	InvalidateRect(NULL);
	UpdateWindow();
}

void CXEditCtrl::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CRect rcc;
	GetClientRect(&rcc);
	CRect rcClip(0,0,0,0);
	dc.GetClipBox(&rcClip);
	if (rcClip.IsRectEmpty())
		rcClip = rcc;
	CDC memDC;
	memDC.CreateCompatibleDC(&dc);
	CRgn rgnClip;
	rgnClip.CreateRectRgn(rcClip.left, rcClip.top, rcClip.right, rcClip.bottom);
	memDC.SelectClipRgn(&rgnClip);
	//��һ��λͼ��������˸
	if (m_bmpCache.m_hObject == NULL)
		m_bmpCache.CreateCompatibleBitmap(&dc, rcc.Width(), rcc.Height());

	CBitmapDC autoBitmap(&memDC, &m_bmpCache);

#ifdef _DEBUG
	memDC.FillSolidRect(rcc, 0xFF);
#endif

	memDC.IntersectClipRect(&m_tm.GetTextRect());
	m_tm.Draw(&memDC);

	//dc.BitBlt(0, 0, rcc.right, rcc.bottom, &memDC, 0, 0, SRCCOPY);
	dc.BitBlt(rcClip.left, rcClip.top, rcClip.Width(), rcClip.Height(), 
		&memDC, rcClip.left, rcClip.top, SRCCOPY);

	memDC.SelectClipRgn(NULL);

	//// IME Support
	if (m_bIMEsupported)
	{
		IMM_HIMC hIMC = m_ImmWrapper.ImmGetContext(m_hWnd);
		if (hIMC)
		{
			COMPOSITIONFORM compForm;
			::ZeroMemory(&compForm, sizeof(compForm));

			compForm.dwStyle = CFS_POINT; //CFS_FORCE_POSITION
			compForm.ptCurrentPos = m_tm.GetCaretPos/*GetCurrentCaretPos*/();

			VERIFY(m_ImmWrapper.ImmSetCompositionWindow(hIMC, &compForm));

			VERIFY(m_ImmWrapper.ImmReleaseContext(m_hWnd, hIMC));
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////
// CEmlEditCtrl

IMPLEMENT_DYNAMIC(CEmlEditCtrl, CXEditCtrl)

CEmlEditCtrl::CEmlEditCtrl()
{

}

CEmlEditCtrl::~CEmlEditCtrl()
{
}


BEGIN_MESSAGE_MAP(CEmlEditCtrl, CXEditCtrl)
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_WM_CHAR()
	ON_WM_SYSCHAR()
END_MESSAGE_MAP()


void CEmlEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CXEditCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CEmlEditCtrl::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CXEditCtrl::OnKeyUp(nChar, nRepCnt, nFlags);
}


void CEmlEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	//BOOL bAltKey = (::GetKeyState(VK_MENU) & KF_UP) != 0;
	//BOOL bCtrlKey = (::GetKeyState(VK_CONTROL) & KF_UP) != 0;
	//BOOL bShiftKey = (::GetKeyState(VK_SHIFT) & KF_UP) != 0;
	//if (nChar == VK_ESCAPE)
	//{
	//	Unselect();
	//}
	//else if (nChar != VK_BACK && !(bCtrlKey && !bAltKey))
	//{
	//	if (!CanEditDoc())
	//	{
	//		return;
	//	}
	//	OnBeforeEditChanged(m_nCurrentCol);
	//	BOOL bModified = FALSE;
	//	BOOL bRedraw = FALSE;
	//	if (IsSelectionExist() && nChar != VK_RETURN)
	//	{
	//		BOOL bRes = DeleteSelection();
	//		bModified |= bRes;
	//		bRedraw = TRUE;
	//	}
	//	WCHAR szText[3];
	//	szText[0] = (WCHAR)nChar;
	//	szText[1] = 0;
	//	if (nChar == VK_RETURN)
	//	{
	//		wcscpy_s(szText,3,L"\r\n");
	//		szText[2] = 0;
	//	}
	//}
	CXEditCtrl::OnChar(nChar, nRepCnt, nFlags);
}


void CEmlEditCtrl::OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CXEditCtrl::OnSysChar(nChar, nRepCnt, nFlags);
}



//////////////////////////////////////////////////////////////////////
//DWORD dwTime = GetTickCount();
//CEEditObjBuffer buffer;
//PETextCell po;
//PEObjLink plink = NULL, plink2=NULL;
//int i;
//for (i = 0; i < 10000; i++)
//{
//	po = new ETextCell;
//	if (po)
//	{
//		po->o = L'A' + i;
//		po->type = ETYPE_TEXT;
//		po->cx = 32;
//		po->cy = 32;
//		plink=buffer.addtail(po);
//	}
//}
//for (i = 0; i < 10000; i++)
//{
//	po = new ETextCell;
//	if (po)
//	{
//		po->o = L'A' + i;
//		po->type = ETYPE_TEXT;
//		po->cx = 32;
//		po->cy = 32;
//		buffer.addhead(po);
//	}
//}
//for (i = 0; i < 10000; i++)
//{
//	po = new ETextCell;
//	if (po)
//	{
//		po->o = L'A' + i;
//		po->type = ETYPE_TEXT;
//		po->cx = 32;
//		po->cy = 32;
//		ASSERT(plink != NULL);
//		plink2=buffer.insertbefore(plink, po);
//		plink = plink2;
//	}
//}
//for (i = 0; i < 10000; i++)
//{
//	po = new ETextCell;
//	if (po)
//	{
//		po->o = L'A' + i;
//		po->type = ETYPE_TEXT;
//		po->cx = 32;
//		po->cy = 32;
//		ASSERT(plink != NULL);
//		plink2 = buffer.insertafter(plink, po);
//		plink = plink2;
//	}
//}
//LONG nDeleted=buffer.del(plink, 10);
//buffer.empty();
//TRACE(L"Time use :%u tick count, %.2f seconds.\n", 
//	GetTickCount() - dwTime,
//	double(GetTickCount() - dwTime)/1000.f);



void CXEditCtrl::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CXTPSmartPtrInternalT<CCmdTarget> ptrThisLock(this, TRUE);
	if (nChar == 0)
	{
		return;
	}

	CWnd::OnSysKeyDown(nChar, nRepCnt, nFlags);
}
LRESULT CXEditCtrl::OnSetText(WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(wParam);
	CWaitCursor wait;
	LPCWSTR szText = (LPCWSTR)lParam;
	CRect rcChanged(0,0,0,0);
	CClientDC dc(this);
	m_tm.Empty();
	m_tm.InsertText(szText,&dc,&rcChanged);
	if (!rcChanged.IsRectEmpty())
		InvalidateRect(&rcChanged);
	else
		InvalidateRect(NULL);
	return (LRESULT)TRUE;
}


//void CXEditCtrl::OnMouseHWheel(UINT nFlags, short zDelta, CPoint pt)
//{
//	// �˹���Ҫ�� Windows Vista ����߰汾��
//	// _WIN32_WINNT ���ű��� >= 0x0600��
//	// TODO:  �ڴ�������Ϣ������������/�����Ĭ��ֵ
//
//	CWnd::OnMouseHWheel(nFlags, zDelta, pt);
//}


BOOL CXEditCtrl::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	CXTPSmartPtrInternalT<CCmdTarget> ptrThisLock(this, TRUE);
	//TRACE(L"OnMouseWheel zDelta=%d\n", zDelta);
	//zDelta>0 ���¹���<0����
	int nScroll = m_tm.GetScrollStep(zDelta);
	if (nScroll)
	{
		HideCaret();
		DestroyCaret();
		m_lastCaretSize.cx = m_lastCaretSize.cy = 0;
		CRect rcChanged(0, 0, 0, 0);
		m_tm.ScrollParagraphs(0, 
			zDelta>0 ? nScroll : -nScroll, 
			NULL, &rcChanged, NULL);
		//if (zDelta < 0)
		//	m_tm.ScrollParagraphs(0, -m_nWheelScroll,NULL,&rcChanged,NULL);
		//else
		//	m_tm.ScrollParagraphs(0, m_nWheelScroll, NULL, &rcChanged, NULL);
		if (!rcChanged.IsRectEmpty())
			InvalidateRect(&rcChanged);
		CreateCaret();
		SetCaretPos(m_tm.GetCaretPos());
		ShowCaret();
	}
	return CWnd::OnMouseWheel(nFlags, zDelta, pt);
}
