#pragma once

#include "ImmWrap.h"
class CXEditCtrl;

class CXEditCtrlTextManager : public CETextManager
{
public:
	CXEditCtrlTextManager(CXEditCtrl *pCtrl);
	virtual void OnCaretMove(PEObjLink pCaret);
protected:
	CXEditCtrl *m_pCtrl;
};

#define XEDCTRL_CARETMOVE	1
struct NMHDR_XEDCTRL_CARETMOVE
{
	NMHDR nmhdr;    // First param should be NMHDR
	PEObjLink pCaret;
	CETextLine *pLine;
};

class CXEditCtrl
	: public CWnd
{
	DECLARE_DYNAMIC(CXEditCtrl)

public:
	CXEditCtrl();
	virtual ~CXEditCtrl();

protected:
	DECLARE_MESSAGE_MAP()
public:
	BOOL Create(DWORD dwStyle, CWnd *pParent, const RECT& rect, UINT id);
	void SetBorders(LONG left, LONG top, LONG right, LONG bottom);
	void SetDefaultFont(PLOGFONTW pFont, COLORREF crTextColor, COLORREF crBgColor);
	void OnCaretMove(PEObjLink pCaret);
	BOOL InsertBitmap(HBITMAP hBmp);
	BOOL InsertImage(LPCWSTR wszImageFile);
	BOOL SpeelCheck(BOOL bEnDict,BOOL bCnDict);
	void EndSpeelCheck();
protected:
	int m_nWheelScroll;
	BOOL m_bInitOK;
	CRect m_rcBorders;
	//BOOL m_bIsOverwriteMode;
	CImmWrap m_ImmWrapper;
	BOOL m_bIMEsupported;
	//LOGFONTW m_defFont;
	CWnd *m_pParentWnd;
	BOOL m_bWndCreateInProgress;
	//CSize m_sizeCaret;
	CXEditCtrlTextManager m_tm;
	CBitmap m_bmpCache;
	BOOL Init();
	void Uninit();
	void _UpdateIMEStatus();
	void CreateCaret();
	CSize m_lastCaretSize;
	void NotifyCaretMove(PEObjLink pCaret);
	BOOL m_bSelecting;
	void CancelSelecting();
	bool m_bMouseTracking;
	bool m_bCaptured;
public:
	PEObjLink GetCaret(){ return m_tm.GetCaret(); };
	CETextLine *GetLine(PEObjLink pChar){ return m_tm.GetLine(pChar, NULL, NULL, NULL); };
public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual void PreSubclassWindow();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg void OnDestroy();
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg LRESULT OnSetText(WPARAM wParam, LPARAM lParam);
//	afx_msg void OnMouseHWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
};


class CEmlEditCtrl 
	: public CXEditCtrl
{
	DECLARE_DYNAMIC(CEmlEditCtrl)

public:
	CEmlEditCtrl();
	virtual ~CEmlEditCtrl();

protected:
	DECLARE_MESSAGE_MAP()
public:
protected:

public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
};


