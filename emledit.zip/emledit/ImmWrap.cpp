﻿#include "stdafx.h"
#include "ImmWrap.h"
#include <atlfile.h>

LPCWSTR g_SkipChars = L" 　ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺĀÁǍÀŌÓǑÒÊĒÉĚÈĪÍǏÌŪÚǓÙǕǗǙǛÜ" \
	L"ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚāáǎàōóǒòêēéěèīíǐìūúǔùǖǘǚǜü"\
	L"ɑńňɡ"\
	L"１２３４５６７８９０"\
	L"`1234567890-=qwertyuiop[]\\asdfghjkl;'zxcvbnm,./"\
	L"~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:\"ZXCVBNM<>?"\
	L"｀⑴⑵⑶⑷⑸⑹⑺⑻⑼⑽－＝⒈⒉⒊⒋⒌⒍⒎⒏⒐⒑［］、■◆▲●★【】『‘；’＄‰∑§αβγ，。／"\
	L"～㈠㈡㈢㈣㈤㈥㈦㈧㈨㈩＿＋ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ｛｝…□◇△○☆〖〗』“：”￥℃∏※±×÷《》？"\
	L"。，、；：？！…—·ˉˇ¨‘’“”々～‖∶＂＇｀｜〃〔〕〈〉《》「」『』．〖〗【】（）［］｛｝"\
	L"§№☆★○●◎◇◆□■△▲※→←↑↓〓＃＆＠＼＾＿￣"\
	L"┌┍┎┏┐┑┒┓─┄┈├┝┞┟┠┡┢┣│┆┊┬┭┮┯┰┱┲┳┼┽┾┿╀╁╂╃└┕┖┗┘┙┚┛━┅┉┤┥┦┧┨┩┪┫┃┇┋┴┵┶┷┸┹┺┻╄╅╆╇╈╉╊╋"\
	L"ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫ⒈⒉⒊⒋⒌⒍⒎⒏⒐⒑㈠㈡㈢㈣㈤㈥㈦㈧㈨㈩⑴⑵⑶⑷⑸⑹⑺⑻⑼⑽"\
	L"⒒⒓⒔⒕⒖⒗⒘⒙⒚⒛①②③④⑤⑥⑦⑧⑨⑩⑾⑿⒀⒁⒂⒃⒄⒅⒆⒇"\
	L"≈≡≠＝≤≥＜＞≮≯∷±＋－×÷／∫∮∝∞∧∨∑∏∪∩∈∵∴⊥∥∠⌒⊙≌∽√"\
	L"°′″＄￡￥‰％℃¤￠○一二三四五六七八九十百千万亿兆吉太拍艾分厘毫微"\
	L"零壹贰叁肆伍陆柒捌玖拾佰仟"\
	L"ㄅㄉˇˋㄓˊ˙ㄚㄞㄢㄦㄆㄊㄍㄐㄔㄗㄧㄛㄟㄣㄇㄋㄎㄑㄕㄘㄨㄜㄠㄤㄈㄌㄏㄒㄖㄙㄩㄝㄡㄥ"\
	L"ぁぃぅぇぉかきくけこんさしすせそたちつってとゐなにぬねのはひふへほゑまみむめもゃゅょゎを"\
	L"あいうえおがぎぐげござじずぜぞだぢづでどぱぴぷぺぽばびぶべぼらりるれろやゆよわ"\
	L"ァィゥヴェォカヵキクケヶコサシスセソタチツッテトヰンナニヌネノハヒフヘホヱマミムメモャュョヮヲ"\
	L"アイウエオガギグゲゴザジズゼゾダヂヅデドパピプペポバビブベボラリルレロヤユヨワ"\
	L"αβγδεζηθικλμνξοπρστυφχψω"\
	L"ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ"\
	L"абвгдеёжзийклмнопрстуфхцчшщъыьэюя"\
	L"АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
const int g_SkipCharsLen = wcslen(g_SkipChars);
inline bool isSkipChar(const WCHAR c)
{
	return wcschr(g_SkipChars, c) ? true : false;
}

inline bool isEnAlpha(WCHAR c)
{
	return ((c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z')) ? true : false;
}

#ifdef _UNICODE
#define IMM_PROC_NAME_AW(procName) procName "W"
#else
#define IMM_PROC_NAME_AW(procName) procName "A"
#endif

#define IMM_IMM_FNCALL(fnName, errRetVal) \
	if (!m_pfn##fnName) \
		return errRetVal; \
	return m_pfn##fnName

CImmWrap::CImmWrap()
{
	m_hImmDll = ::LoadLibrary(_T("imm32.dll"));
	if (m_hImmDll)
	{
		m_pfnImmIsIME = (PFN_ImmIsIME)GetProcAddress(m_hImmDll, "ImmIsIME");
		m_pfnImmGetContext = (PFN_ImmGetContext)GetProcAddress(m_hImmDll, "ImmGetContext");
		m_pfnImmReleaseContext = (PFN_ImmReleaseContext)GetProcAddress(m_hImmDll, "ImmReleaseContext");
		m_pfnImmSetCompositionFont = (PFN_ImmSetCompositionFont)GetProcAddress(m_hImmDll, IMM_PROC_NAME_AW("ImmSetCompositionFont"));
		m_pfnImmSetCompositionWindow = (PFN_ImmSetCompositionWindow)GetProcAddress(m_hImmDll, "ImmSetCompositionWindow");
	}
	else
	{
		m_pfnImmIsIME = NULL;
		m_pfnImmGetContext = NULL;
		m_pfnImmReleaseContext = NULL;
		m_pfnImmSetCompositionFont = NULL;
		m_pfnImmSetCompositionWindow = NULL;
	}
}

CImmWrap::~CImmWrap()
{
	if (m_hImmDll)
	{
		::FreeLibrary(m_hImmDll);
	}
}

BOOL CImmWrap::ImmIsIME(HKL hKL)
{
	ASSERT(m_pfnImmIsIME);

	if (!m_pfnImmIsIME)
		return FALSE;

	if (hKL == NULL)
		hKL = ::GetKeyboardLayout(0);

	return m_pfnImmIsIME(hKL);
}

IMM_HIMC CImmWrap::ImmGetContext(HWND hWnd)
{
	ASSERT(m_pfnImmGetContext);
	IMM_IMM_FNCALL(ImmGetContext, NULL)(hWnd);
}

BOOL CImmWrap::ImmReleaseContext(HWND hWnd, IMM_HIMC hIMC)
{
	ASSERT(m_pfnImmReleaseContext);
	IMM_IMM_FNCALL(ImmReleaseContext, FALSE)(hWnd, hIMC);
}

BOOL CImmWrap::ImmSetCompositionWindow(IMM_HIMC hIMC, COMPOSITIONFORM* pCompForm)
{
	ASSERT(m_pfnImmReleaseContext);
	IMM_IMM_FNCALL(ImmSetCompositionWindow, FALSE)(hIMC, pCompForm);
}

BOOL CImmWrap::ImmSetCompositionFont(IMM_HIMC hIMC, LOGFONT* plfFont)
{
	ASSERT(m_pfnImmReleaseContext);
	IMM_IMM_FNCALL(ImmSetCompositionFont, FALSE)(hIMC, plfFont);
}
////////////////////////////////////////////////////////////////////////////////////////
CEditObjMem::CEditObjMem(UINT uBlockSize)
	:m_nBlockSize(uBlockSize)
	, m_pBlocks(NULL)
	, m_pFreeNode(NULL)
	, m_nBlocksCount(0)
{
}
CEditObjMem::~CEditObjMem()
{
	if (m_pBlocks)
	{
		ASSERT(m_nBlocksCount);
		PlexFree(m_pBlocks, -1);
		m_pBlocks = NULL;
		m_nBlocksCount = 0;
	}
	m_pFreeNode = NULL;
}

CEditObjPlex* CEditObjMem::PlexAlloc(
	size_t uBlockSize,
	size_t bytesEachBlock)
{
	ATLASSERT(uBlockSize > 0);
	ATLASSERT(bytesEachBlock > 0);
	size_t nBytes = 0;
	if (FAILED(::ATL::AtlMultiply(&nBytes, uBlockSize, bytesEachBlock)) ||
		FAILED(::ATL::AtlAdd(&nBytes, nBytes, sizeof(EObjLink))))
	{
		return NULL;
	}
	return static_cast< CEditObjPlex* >(malloc(nBytes));
}

void CEditObjMem::PlexFree(CEditObjPlex *pStart, INT_PTR count/* = -1*/)
{
	CEditObjPlex* pPlex;
	CEditObjPlex* pNext;
	ATLASSERT(pStart);
	pPlex = pStart;
	while (pPlex != NULL)
	{
		pNext = pPlex->pNext;
		if (pPlex->pPrev)
			pPlex->pPrev->pNext = pPlex->pNext;
		if (pPlex->pNext)
			pPlex->pNext->pPrev = pPlex->pPrev;
		free(pPlex);
		if (count > 0)
		{
			count--;
			if (count == 0)
				break;
		}
		pPlex = pNext;
	}
}

PEObjLink CEditObjMem::NewNode(PEObjLink pPrev, PEObjLink pNext)
{
	if (!CreateFreeNodesIfNeeded())
		return NULL;
	PEObjLink pNewNode = CreateNode();
	pNewNode->pPrev = pPrev;
	if (pPrev)
		pPrev->pNext = pNewNode;
	pNewNode->pNext = pNext;
	if (pNext)
		pNext->pPrev = pNewNode;
	return pNewNode;
}

void CEditObjMem::FreeNode(PEObjLink pNode) throw()
{
	pNode->~EObjLink();
	pNode->pPrev = NULL;
	pNode->pNext = m_pFreeNode;
	if (m_pFreeNode)
		m_pFreeNode->pPrev = pNode;
	m_pFreeNode = pNode;
	//单元回收后，可能会引起归属的内存块释放
	CEditObjPlex* pPlex = m_pBlocks;
	CEditObjPlex* pPlexNext;
	while (pPlex)
	{
		pPlexNext = pPlex->pNext;
		//根据内存地址查找归属
		if (pNode >= pPlex->pStart && pNode <= pPlex->pEnd)
		{
			pPlex->uFreeCount++;	//空闲单元增量
			//如果达到m_nBlockSize，我们看看是否能释放该内存块
			if (pPlex->uFreeCount >= m_nBlockSize)
			{
				//速度优先，至少保留1块内存块不释放
				if (m_nBlocksCount > 1)
				{
					//在释放该内存块之前，需要先从空闲单元列表中移去所有属于本块的链
					PEObjLink pFreeNode = m_pFreeNode;
					PEObjLink pFreeNodeNext;
					while (pFreeNode)
					{
						pFreeNodeNext = pFreeNode->pNext;
						if (pFreeNode >= pPlex->pStart && pFreeNode <= pPlex->pEnd)
						{
							if (m_pFreeNode == pFreeNode)
								m_pFreeNode = pFreeNode->pNext;
							if (pFreeNode->pPrev)
								pFreeNode->pPrev->pNext = pFreeNode->pNext;
							if (pFreeNode->pNext)
								pFreeNode->pNext->pPrev = pFreeNode->pPrev;
							//注意：仅仅移去，不能 free 或者 delete，因为它的空间属于本内存块
						}
						pFreeNode = pFreeNodeNext;
					}//end while
					PlexFree(pPlex, 1);
					m_nBlocksCount--;
					if (pPlex == m_pBlocks)
					{
						m_pBlocks = pPlexNext;
					}
				}//end if agree
			}//end if FreeCount
			break;
		}//end if scope
		pPlex = pPlexNext;
	}//end while
}
bool CEditObjMem::CreateFreeNodesIfNeeded()
{
	if (m_pFreeNode == NULL)
	{
		CEditObjPlex* pPlex;
		PEObjLink pNode;

		pPlex = PlexAlloc(
			m_nBlockSize,
			sizeof(EObjLink));
		if (pPlex == NULL)
		{
			AtlThrow(E_OUTOFMEMORY);
			return false;
		}
		pPlex->pPrev = NULL;
		pPlex->pNext = m_pBlocks;
		if(m_pBlocks)
			m_pBlocks->pPrev = pPlex;
		m_pBlocks = pPlex;
		m_nBlocksCount++;
		pNode = (PEObjLink)(&pPlex[1]);
		pPlex->uFreeCount = m_nBlockSize;
		pPlex->pStart = pNode;
		pNode += m_nBlockSize - 1;
		pPlex->pEnd = pNode;
		//加入空闲链表
		for (int iBlock = m_nBlockSize - 1; iBlock >= 0; iBlock--)
		{
			pNode->pPrev = NULL;
			pNode->pNext = m_pFreeNode;
			if (m_pFreeNode)
				m_pFreeNode->pPrev = pNode;
			m_pFreeNode = pNode;
			pNode--;
		}
	}
	ATLASSUME(m_pFreeNode != NULL);
	return true;
}
PEObjLink CEditObjMem::CreateNode()
{
	ATLASSERT(m_pFreeNode);
	PEObjLink pNewNode = m_pFreeNode;
	PEObjLink pNextFree = m_pFreeNode->pNext;
#pragma push_macro("new")
#undef new
	::new(pNewNode)EObjLink;
#pragma pop_macro("new")
	m_pFreeNode = pNextFree;
	if (m_pFreeNode)
		m_pFreeNode->pPrev = NULL;
	ATLASSERT(m_pBlocks);
	CEditObjPlex* pPlex = m_pBlocks;
	while (pPlex)
	{
		//根据内存地址查找归属
		if (pNewNode >= pPlex->pStart && pNewNode <= pPlex->pEnd)
		{
			ASSERT(pPlex->uFreeCount > 0);
			pPlex->uFreeCount--;	//空闲单元减量
			break;
		}
		pPlex = pPlex->pNext;
	}
	return pNewNode;
}

////////////////////////////////////////////////////////////////////////////////////////
CEditObjBuf::CEditObjBuf(UINT uBlockSize)
	:m_linkCount(0)
	, m_pLinkHead(NULL)
	, m_pLinkTail(NULL)
	, m_mem(uBlockSize)
{

}
CEditObjBuf::~CEditObjBuf()
{
	Empty();
}


PEObjLink CEditObjBuf::AddTail(EditObj& o)
{
	PEObjLink plink = m_mem.NewNode(m_pLinkTail, NULL);
	if (plink == NULL)
		return NULL;
	plink->o = o;
	if (m_pLinkTail == NULL)
	{
		ASSERT(m_pLinkHead == NULL);
		/*m_pLinkTail = */m_pLinkHead = plink;
	}
	m_pLinkTail = plink;
	m_linkCount++;
	return plink;
}
PEObjLink CEditObjBuf::AddHead(EditObj& o)
{
	PEObjLink plink = m_mem.NewNode(NULL, m_pLinkHead);
	if (plink == NULL)
		return NULL;
	plink->o = o;
	if (m_pLinkHead == NULL)
	{
		ASSERT(m_pLinkTail == NULL);
		/*m_pLinkHead = */m_pLinkTail = plink;
	}
	m_pLinkHead = plink;
	m_linkCount++;
	return plink;
}
PEObjLink CEditObjBuf::InsertBefore(PEObjLink pTlink, EditObj& o)
{
	PEObjLink plink = m_mem.NewNode(pTlink->pPrev, pTlink);
	if (plink == NULL)
		return NULL;
	plink->o = o;
	if (/*bIsFirstLink*/pTlink == m_pLinkHead)
		m_pLinkHead = plink;
	m_linkCount++;
	return plink;
}
//insert then return new
PEObjLink CEditObjBuf::InsertAfter(PEObjLink pTlink, EditObj& o)
{
	PEObjLink plink = m_mem.NewNode(pTlink, pTlink->pNext);
	if (plink == NULL)
		return NULL;
	plink->o = o;
	if (/*bIsTailLink*/pTlink == m_pLinkTail)
		m_pLinkTail = plink;
	m_linkCount++;
	return plink;
}
//return how much deleted
INT_PTR CEditObjBuf::Del(PEObjLink plink, INT_PTR count/* = 1*/)
{
	if (plink == NULL || m_linkCount <= 0)
		return 0;
	LONG total = 0;
	PEObjLink pPrev = plink->pPrev, pNext = NULL;
	if (pPrev)
		pPrev->pNext = NULL;
	while (plink && total < count)
	{
		pNext = plink->pNext;
		if (pNext)
			pNext->pPrev = NULL;
		if (plink == m_pLinkHead)
			m_pLinkHead = pNext;
		/*else*/
		if (plink == m_pLinkTail)
			m_pLinkTail = pPrev;
		//if (plink->po)
		//	delete plink->po;
		if (plink->o.pCt)
			delete plink->o.pCt;
		//delete plink;
		m_mem.FreeNode(plink);
		plink = pNext;
		total++;
		m_linkCount--;
	}
	if (plink)
	{
		plink->pPrev = pPrev;
		if (pPrev)
			pPrev->pNext = plink;
	}
	//else
	//{
	//	if (pPrev)
	//		pPrev->pNext = NULL;
	//}
	if (m_linkCount <= 0)
	{
		ASSERT(m_pLinkHead == NULL);
		ASSERT(m_pLinkTail == NULL);
	}
	return total;
}
void CEditObjBuf::Empty(CEPtrList<PEObjLink> * pExcept/* = NULL*/)
{
	if (m_pLinkHead)
	{
		int nExceptFound = 0;
		ASSERT(m_linkCount);
		PEObjLink pLink = m_pLinkHead;
		PEObjLink pNext;
		m_pLinkHead = m_pLinkTail = NULL;
		while (pLink)
		{
			pNext = pLink->pNext;
			if (pExcept && pExcept->Find(pLink))
			{
				nExceptFound++;
				if (m_pLinkHead == NULL)
				{
					m_pLinkHead = m_pLinkTail = pLink;
					pLink->pPrev = pLink->pNext = NULL;
				}
				else
				{
					ASSERT(m_pLinkTail);
					m_pLinkTail->pNext = pLink;
					pLink->pPrev = m_pLinkTail;
					pLink->pNext = NULL;
					m_pLinkTail = pLink;
				}

			}
			else
			{
				if (pLink->o.pCt)
					OnFreeObjectContext(pLink);
				//delete pLink;
				m_mem.FreeNode(pLink);
				m_linkCount--;
			}
			pLink = pNext;
		} //end while (pLink)
		if (nExceptFound)
		{
			ASSERT(m_linkCount == (INT_PTR)nExceptFound);
			ASSERT(m_pLinkHead != NULL);
			ASSERT(m_pLinkTail != NULL);
		}
		else
		{
			ASSERT(m_linkCount == 0);
			m_pLinkHead = NULL;
			m_pLinkTail = NULL;
			m_linkCount = 0;
		}
	}
	else
	{
		ASSERT(m_linkCount == 0);
		ASSERT(m_pLinkTail == NULL);
	}
}
void CEditObjBuf::OnFreeObjectContext(PEObjLink pLink)
{
}
///////////////////////////////////////////////////////////////////////////////////////////
CETextBuffer::CETextBuffer(UINT uBlockSize)
	:CEditObjBuf(uBlockSize)
	, m_bOverwriteMode(0), m_bForceInsertMode(0)
	, m_pCaret(NULL), m_pSelStart(NULL), m_pSelEnd(NULL)
	, m_nMinElements(BUFFER_MIN_ELEMENTS)
{
}
CETextBuffer::~CETextBuffer()
{

}
BOOL CETextBuffer::IsOverwriteMode()
{
	if (m_bOverwriteMode == 0 || m_bForceInsertMode)
		return FALSE;
	return TRUE;
}
BOOL CETextBuffer::GetOverwriteMode()
{
	return m_bOverwriteMode ? TRUE : FALSE;
}
void CETextBuffer::SetOverwriteMode(BOOL bSet)
{
	m_bOverwriteMode = bSet ? 1 : 0;
}
BOOL CETextBuffer::IsForceInsertMode()
{
	return m_bForceInsertMode ? TRUE : FALSE;
}
void CETextBuffer::SetForceInsertMode(BOOL bSet)
{
	m_bForceInsertMode = bSet ? 1 : 0;
}

BOOL CETextBuffer::CreateSelection()
{
	EditObj o;
	init_editobj(o, ETYPE_SELECT);
	o.c = 0x0001;
	PEObjLink pRet;
	pRet = CEditObjBuf::AddTail(o);
	if (pRet == NULL)
		return FALSE;
	ASSERT(m_pSelStart == NULL);
	if (m_pSelStart)
		Del(m_pSelStart);
	m_pSelStart = pRet;
	o.c = 0x0002;
	pRet = CEditObjBuf::AddTail(o);
	if (pRet == NULL)
		return FALSE;
	ASSERT(m_pSelEnd == NULL);
	if (m_pSelEnd)
		Del(m_pSelEnd);
	m_pSelEnd = pRet;
	return TRUE;
}
PEObjLink CETextBuffer::GetSelectionStart()
{
	return m_pSelStart;
}
PEObjLink CETextBuffer::GetSelectionEnd()
{
	return m_pSelEnd;
}
//检测选择标记是否相邻来确定它们之间是否有选择内容。
BOOL CETextBuffer::IsSelectionEmpty()
{
	if (m_pSelStart == NULL || m_pSelEnd == NULL)
		return TRUE;
	if (m_pSelStart->pNext == m_pSelEnd ||
		m_pSelEnd->pNext == m_pSelStart)
		return TRUE;
	return GetSelected(NULL,TRUE) >0 ? FALSE : TRUE;
}
//移动两个选择标记中的一个，使它们相邻。
BOOL CETextBuffer::SetSelectionEmpty()
{
	return Move(m_pSelStart, m_pSelEnd, TRUE);
}

//开始选择。移动 SelectionStart 标记到pTarget的左边还是右边
BOOL CETextBuffer::StartSelect(PEObjLink pTarget, BOOL bBeforeTarget)
{
	if (m_pSelStart == NULL)
		return FALSE;
	if (pTarget == NULL)
		return FALSE;
	if (pTarget == m_pSelStart)
		return TRUE;
	if (!bBeforeTarget)
	{
		if (pTarget->pNext == m_pSelStart)
			return TRUE;
	}
	else
	{
		if (pTarget->pPrev == m_pSelStart)
			return TRUE;
	}
	if (m_pLinkTail == m_pSelStart)
		m_pLinkTail = m_pSelStart->pPrev;
	if (m_pLinkHead == m_pSelStart)
		m_pLinkHead = m_pSelStart->pNext;
	if (m_pSelStart->pPrev)
		m_pSelStart->pPrev->pNext = m_pSelStart->pNext;
	if (m_pSelStart->pNext)
		m_pSelStart->pNext->pPrev = m_pSelStart->pPrev;
	if (!bBeforeTarget)
	{
		m_pSelStart->pNext = pTarget->pNext;
		if (pTarget->pNext)
			pTarget->pNext->pPrev = m_pSelStart;
		m_pSelStart->pPrev = pTarget;
		pTarget->pNext = m_pSelStart;
		if (m_pLinkTail == pTarget)
			m_pLinkTail = m_pSelStart;
		m_pSelStart->o.x = pTarget->o.x + pTarget->o.cx;
	}
	else
	{
		m_pSelStart->pPrev = pTarget->pPrev;
		if (pTarget->pPrev)
			pTarget->pPrev->pNext = m_pSelStart;
		m_pSelStart->pNext = pTarget;
		pTarget->pPrev = m_pSelStart;
		if (m_pLinkHead == pTarget)
			m_pLinkHead = m_pSelStart;
		m_pSelStart->o.x = pTarget->o.x;
	}
	return TRUE;
}

//结束选择。移动 SelectionEnd 标记到pTarget的左边还是右边
BOOL CETextBuffer::EndSelect(PEObjLink pTarget, BOOL bBeforeTarget)
{
	if (m_pSelEnd == NULL)
		return FALSE;
	if (pTarget == NULL)
		return FALSE;
	if (pTarget == m_pSelEnd)
		return TRUE;
	if (!bBeforeTarget)
	{
		if (pTarget->pNext == m_pSelEnd)
			return TRUE;
	}
	else
	{
		if (pTarget->pPrev == m_pSelEnd)
			return TRUE;
	}
	if (m_pLinkTail == m_pSelEnd)
		m_pLinkTail = m_pSelEnd->pPrev;
	if (m_pLinkHead == m_pSelEnd)
		m_pLinkHead = m_pSelEnd->pNext;
	if (m_pSelEnd->pPrev)
		m_pSelEnd->pPrev->pNext = m_pSelEnd->pNext;
	if (m_pSelEnd->pNext)
		m_pSelEnd->pNext->pPrev = m_pSelEnd->pPrev;
	if (!bBeforeTarget)
	{
		m_pSelEnd->pNext = pTarget->pNext;
		if (pTarget->pNext)
			pTarget->pNext->pPrev = m_pSelEnd;
		m_pSelEnd->pPrev = pTarget;
		pTarget->pNext = m_pSelEnd;
		if (m_pLinkTail == pTarget)
			m_pLinkTail = m_pSelEnd;
		m_pSelEnd->o.x = pTarget->o.x + pTarget->o.cx;
	}
	else
	{
		m_pSelEnd->pPrev = pTarget->pPrev;
		if (pTarget->pPrev)
			pTarget->pPrev->pNext = m_pSelEnd;
		m_pSelEnd->pNext = pTarget;
		pTarget->pPrev = m_pSelEnd;
		if (m_pLinkHead == pTarget)
			m_pLinkHead = m_pSelEnd;
		m_pSelEnd->o.x = pTarget->o.x;
	}
	return TRUE;
}

//移动某个对象到另一个的左边或者右边
BOOL CETextBuffer::Move(PEObjLink pSource, PEObjLink pTarget, BOOL bBeforeTarget)
{
	if (pSource == NULL)
		return FALSE;
	if (pTarget == NULL)
		return FALSE;
	if (pTarget == pSource)
		return TRUE;
	if (!bBeforeTarget)
	{
		if (pTarget->pNext == pSource)
			return TRUE;
	}
	else
	{
		if (pTarget->pPrev == pSource)
			return TRUE;
	}
	if (m_pLinkTail == pSource)
		m_pLinkTail = pSource->pPrev;
	if (m_pLinkHead == pSource)
		m_pLinkHead = pSource->pNext;
	if (pSource->pPrev)
		pSource->pPrev->pNext = pSource->pNext;
	if (pSource->pNext)
		pSource->pNext->pPrev = pSource->pPrev;
	if (!bBeforeTarget)
	{
		pSource->pNext = pTarget->pNext;
		if (pTarget->pNext)
			pTarget->pNext->pPrev = pSource;
		pSource->pPrev = pTarget;
		pTarget->pNext = pSource;
		if (m_pLinkTail == pTarget)
			m_pLinkTail = pSource;
		//pSource->o.x = pTarget->o.x + pTarget->o.cx;
	}
	else
	{
		pSource->pPrev = pTarget->pPrev;
		if (pTarget->pPrev)
			pTarget->pPrev->pNext = pSource;
		pSource->pNext = pTarget;
		pTarget->pPrev = pSource;
		if (m_pLinkHead == pTarget)
			m_pLinkHead = pSource;
		//pSource->o.x = pTarget->o.x;
	}
	return TRUE;
}

BOOL CETextBuffer::IsSelected(PEObjLink pObject)
{
	CharList lst(FALSE);
	lst.AddTail(pObject);
	return GetSelected(&lst, FALSE, TRUE) > 0 ? TRUE : FALSE;
}

//取得选中的内容在 pList 中返回。返回选中对象的个数。pList允许为NULL。
//实际上，selectionstart and selectionend 两个标记的顺序是没有固定的，所以我们只取两者之间的内容
//bForDetectEmptyOnly=TRUE时表示是要检测是否选中了什么内容，如此的话，只要检测到1个选中的内容就会返回1。
//bDetectIsSelected用于检测pList中的内容是否被选中了，如果bDetectIsSelected=TRUE,则pList中必须至少有一个内容
INT_PTR CETextBuffer::GetSelected(
	IN OUT CharList *pList, 
	IN OPTIONAL BOOL bForDetectEmptyOnly/* = FALSE*/,
	IN OPTIONAL BOOL bDetectIsSelected/* = FALSE*/)
{
	INT_PTR nCount = 0;
	if (pList)
	{
		if (bDetectIsSelected)
		{
			ASSERT(pList->GetCount());
			if (pList->GetCount() <= 0)
				return 0;
		}
		else
		{
			if (pList->GetCount())
				pList->RemoveAll();
		}
	}
	else
	{
		if (bDetectIsSelected)
		{
			ASSERT(0);
			return 0;
		}
	}
	BOOL bStartFound = FALSE;
	PEObjLink pChar = m_pLinkHead;
	while (pChar)
	{
		if (isSelection(pChar))
		{
			if (!bStartFound)
				bStartFound = TRUE;
			else
				break;
		}
		else 
		{
			if (bStartFound)
			{
				if (!iscaret(pChar) && (istext(pChar) || pChar->o.cx > 0))
				{
					
					if (pList)
					{
						if (bDetectIsSelected)
						{
							if (pList->Find(pChar))
							{
								nCount++;
								if (nCount >= pList->GetCount())
									return nCount;
							}
						}
						else
						{
							if(pList->AddTail(pChar))
								nCount++;
						}
					}
					else
						nCount++;
					//注意这里，为了速度，别的事情就不做了
					if (bForDetectEmptyOnly)
						return nCount;
				}
			}
		}
		pChar = pChar->pNext;
	}
	return nCount/*pList->GetCount()*/;
}

//统计出所有选中内容的区域返回
BOOL CETextBuffer::GetSelectedBoundRect(
	LPRECT pRect, 
	EObjLink **ppFirst/* = NULL*/, 
	EObjLink **ppLast/* = NULL*/)
{
	PEObjLink pFirst = NULL;
	PEObjLink pLast = NULL;
	SetRectEmpty(pRect);
	CRect rect(0, 0, 0, 0),rc;
	BOOL bStartFound = FALSE;
	PEObjLink pChar = m_pLinkHead;
	while (pChar)
	{
		if (isSelection(pChar))
		{
			if (!bStartFound)
				bStartFound = TRUE;
			else
				break;
		}
		else
		{
			if (bStartFound)
			{
				if (!iscaret(pChar) && (istext(pChar) || pChar->o.cx > 0))
				{
					if (pFirst == NULL)
						pFirst = pChar;
					pLast = pChar;
					rc.SetRect(pChar->o.x, pChar->o.y,
						pChar->o.x + pChar->o.cx,
						pChar->o.y + pChar->o.cy);
					if (rect.left == 0 && rect.top == 0 && rect.right == 0 && rect.bottom == 0)
						rect = rc;
					else
						rect.UnionRect(&rect, &rc);
				}
			}
		}
		pChar = pChar->pNext;
	}
	if (ppFirst) *ppFirst = pFirst;
	if (ppLast) *ppLast = pLast;
	if (rect.left == 0 && rect.top == 0 && rect.right == 0 && rect.bottom == 0)
		return FALSE;
	*pRect = rect;
	return TRUE;
}

PEObjLink CETextBuffer::CreateCaret(BYTE overwrite/* = 0*/)
{
	m_bOverwriteMode = overwrite ? 1 : 0;
	EditObj o;
	init_editobj(o, ETYPE_CARET);
	PEObjLink pRet = CEditObjBuf::AddTail(o);
	if (pRet == NULL)
		return NULL;
	ASSERT(m_pCaret == NULL);
	if (m_pCaret)
		Del(m_pCaret);
	m_pCaret = pRet;
	return pRet;
}

PEObjLink CETextBuffer::GetCaret()
{
	return m_pCaret;
}

PEObjLink CETextBuffer::AddTail(WCHAR c, LONG cx, LONG cy)
{
	EditObj o;
	init_editobj(o);
	o.cx = cx;
	o.cy = cy;
	o.c = c;
	return CEditObjBuf::AddTail(o);
}
PEObjLink CETextBuffer::AddHead(WCHAR c, LONG cx, LONG cy)
{
	EditObj o;
	init_editobj(o);
	o.cx = cx;
	o.cy = cy;
	o.c = c;
	return CEditObjBuf::AddHead(o);
}

BOOL CETextBuffer::CaretMoveAfter(PEObjLink pTarget)
{
	if (m_pCaret == NULL)
		return FALSE;
	if (m_linkCount <= m_nMinElements)
		return FALSE;
	if (pTarget == NULL)
		return FALSE;
	if (pTarget == m_pCaret)
		return TRUE;
	if (pTarget->pNext == m_pCaret)
		return TRUE;
	if (m_pLinkTail == m_pCaret)
		m_pLinkTail = m_pCaret->pPrev;
	if (m_pLinkHead == m_pCaret)
		m_pLinkHead = m_pCaret->pNext;
	if (m_pCaret->pPrev)
		m_pCaret->pPrev->pNext = m_pCaret->pNext;
	if (m_pCaret->pNext)
		m_pCaret->pNext->pPrev = m_pCaret->pPrev;
	m_pCaret->pNext = pTarget->pNext;
	if (pTarget->pNext)
		pTarget->pNext->pPrev = m_pCaret;
	m_pCaret->pPrev = pTarget;
	pTarget->pNext = m_pCaret;
	if (m_pLinkTail == pTarget)
		m_pLinkTail = m_pCaret;
	m_pCaret->o.x = pTarget->o.x + pTarget->o.cx;
	return TRUE;
}

BOOL CETextBuffer::CaretMoveBefore(PEObjLink pTarget)
{
	if (m_pCaret == NULL)
		return FALSE;
	if (m_linkCount <= m_nMinElements)
		return FALSE;
	if (pTarget == NULL)
		return FALSE;
	if (pTarget == m_pCaret)
		return TRUE;
	if (pTarget->pPrev == m_pCaret)
		return TRUE;
	if (m_pLinkTail == m_pCaret)
		m_pLinkTail = m_pCaret->pPrev;
	if (m_pLinkHead == m_pCaret)
		m_pLinkHead = m_pCaret->pNext;
	if (m_pCaret->pPrev)
		m_pCaret->pPrev->pNext = m_pCaret->pNext;
	if (m_pCaret->pNext)
		m_pCaret->pNext->pPrev = m_pCaret->pPrev;
	m_pCaret->pPrev = pTarget->pPrev;
	if (pTarget->pPrev)
		pTarget->pPrev->pNext = m_pCaret;
	m_pCaret->pNext = pTarget;
	pTarget->pPrev = m_pCaret;
	if (m_pLinkHead == pTarget)
		m_pLinkHead = m_pCaret;
	m_pCaret->o.x = pTarget->o.x;
	return TRUE;
}
//光标往前移动1个字符，不管字符宽度是否为0。但是选择标记对象会被跳过。
BOOL CETextBuffer::CaretMoveNext()
{
	if (m_pCaret == NULL)
		return FALSE;
	if (m_linkCount <= m_nMinElements)
		return FALSE;
	PEObjLink pNext;
	PEObjLink pNextNext;
	PEObjLink pPrev;
	BOOL bTryAgain;
	do
	{
		bTryAgain = FALSE;
		if (m_pCaret->pNext == NULL)
			return FALSE;
		pNext = m_pCaret->pNext;
		pNextNext = pNext->pNext;
		pPrev = m_pCaret->pPrev;
		if (pPrev)
			pPrev->pNext = pNext;
		pNext->pPrev = pPrev;
		if (pNextNext)
			pNextNext->pPrev = m_pCaret;
		m_pCaret->pNext = pNextNext;
		pNext->pNext = m_pCaret;
		m_pCaret->pPrev = pNext;
		if (m_pLinkTail == pNext)
			m_pLinkTail = m_pCaret;
		if (m_pLinkHead == m_pCaret)
			m_pLinkHead = pNext;
		if (m_pCaret->pNext)
		{
			m_pCaret->o.x = m_pCaret->pNext->o.x;
			m_pCaret->o.y = m_pCaret->pNext->o.y;
		}
		else if (m_pCaret->pPrev)
		{
			m_pCaret->o.x = m_pCaret->pPrev->o.x + m_pCaret->pPrev->o.cx;
			m_pCaret->o.y = m_pCaret->pPrev->o.y;
		}
		//注意这里
		if (m_pCaret->pPrev)
		{
			if (isSelection(m_pCaret->pPrev))
				bTryAgain = TRUE;
		}
	} while (bTryAgain);
	return TRUE;
}
//光标往回移动1个字符，不管字符宽度是否为0。但是选择标记对象会被跳过。
BOOL CETextBuffer::CaretMovePrev()
{
	if (m_pCaret == NULL)
		return FALSE;
	if (m_linkCount <= m_nMinElements)
		return FALSE;
	PEObjLink pPrev;
	PEObjLink pPrevPrev;
	PEObjLink pNext;
	BOOL bTryAgain;
	do
	{
		bTryAgain = FALSE;
		if (m_pCaret->pPrev == NULL)
			return FALSE;
		pPrev = m_pCaret->pPrev;
		pPrevPrev = pPrev->pPrev;
		pNext = m_pCaret->pNext;
		if (pNext)
			pNext->pPrev = pPrev;
		pPrev->pNext = pNext;
		if (pPrevPrev)
			pPrevPrev->pNext = m_pCaret;
		m_pCaret->pPrev = pPrevPrev;
		pPrev->pPrev = m_pCaret;
		m_pCaret->pNext = pPrev;
		if (m_pLinkTail == m_pCaret)
			m_pLinkTail = pPrev;
		if (m_pLinkHead == pPrev)
			m_pLinkHead = m_pCaret;
		if (m_pCaret->pNext)
		{
			m_pCaret->o.x = m_pCaret->pNext->o.x;
			m_pCaret->o.y = m_pCaret->pNext->o.y;
		}
		else if (m_pCaret->pPrev)
		{
			m_pCaret->o.x = m_pCaret->pPrev->o.x + m_pCaret->pPrev->o.cx;
			m_pCaret->o.y = m_pCaret->pPrev->o.y;
		}
		//注意这里
		if (m_pCaret->pNext)
		{
			if (isSelection(m_pCaret->pNext))
				bTryAgain = TRUE;
		}
	} while (bTryAgain);
	return TRUE;
}

//光标往前移动n个字符，直到字符宽度非0
BOOL CETextBuffer::CaretMoveNextNonZeroChar()
{
	if (m_pCaret == NULL)
		return FALSE;
	if (m_linkCount <= m_nMinElements)
		return FALSE;
	PEObjLink pPrev;
	PEObjLink pNext;
	PEObjLink pNextNext;
	while (m_pCaret->pNext != NULL)
	{
		pPrev = m_pCaret->pPrev;
		pNext = m_pCaret->pNext;
		pNextNext = m_pCaret->pNext->pNext;
		
		if (pPrev)
			pPrev->pNext = pNext;
		pNext->pPrev = pPrev;
		if (pNextNext)
			pNextNext->pPrev = m_pCaret;
		m_pCaret->pNext = pNextNext;

		pNext->pNext = m_pCaret;
		//pNext->pPrev = pPrev;
		m_pCaret->pPrev = pNext;
		//m_pCaret->pNext = pNextNext;

		if (m_pLinkTail == pNext)
			m_pLinkTail = m_pCaret;
		if (m_pLinkHead == m_pCaret)
			m_pLinkHead = pNext;
		if (m_pCaret->pNext)
		{
			m_pCaret->o.x = m_pCaret->pNext->o.x;
			m_pCaret->o.y = m_pCaret->pNext->o.y;
		}
		else if (m_pCaret->pPrev)
		{
			m_pCaret->o.x = m_pCaret->pPrev->o.x + m_pCaret->pPrev->o.cx;
			m_pCaret->o.y = m_pCaret->pPrev->o.y;
		}
		if (pNext->o.cx)
			return TRUE;
	}
	return FALSE;
}
BOOL CETextBuffer::IsEmpty()
{
	return (CEditObjBuf::m_linkCount <= m_nMinElements ? TRUE : FALSE);
}
//光标往回移动n个字符，直到字符宽度非0
BOOL CETextBuffer::CaretMovePrevNonZeroChar()
{
	if (m_pCaret == NULL)
		return FALSE;
	if (m_linkCount <= m_nMinElements)
		return FALSE;
	PEObjLink pPrev;
	PEObjLink pPrevPrev;
	PEObjLink pNext;
	while (m_pCaret->pPrev != NULL)
	{
		pPrev = m_pCaret->pPrev;
		pPrevPrev = pPrev->pPrev;
		pNext = m_pCaret->pNext;

		if (pPrevPrev)
			pPrevPrev->pNext = m_pCaret;
		m_pCaret->pPrev = pPrevPrev;
		if (pNext)
			pNext->pPrev = pPrev;
		pPrev->pNext = pNext;

		m_pCaret->pNext = pPrev;
		pPrev->pPrev = m_pCaret;

		if (m_pLinkTail == m_pCaret)
			m_pLinkTail = pPrev;
		if (m_pLinkHead == pPrev)
			m_pLinkHead = m_pCaret;
		if (m_pCaret->pNext)
		{
			m_pCaret->o.x = m_pCaret->pNext->o.x;
			m_pCaret->o.y = m_pCaret->pNext->o.y;
		}
		else if (m_pCaret->pPrev)
		{
			m_pCaret->o.x = m_pCaret->pPrev->o.x + m_pCaret->pPrev->o.cx;
			m_pCaret->o.y = m_pCaret->pPrev->o.y;
		}
		if (pPrev->o.cx)
			return TRUE;
	}
	return FALSE;
}

//从pCur开始，包括pCur，往前搜索，直到字符宽度非0返回。如果wszCharSet非空，遇到wszCharSet中的字符也返回
PEObjLink CETextBuffer::GetNextNonZeroChar(PEObjLink pCur, LPCWSTR wszCharSet/* = NULL*/)
{
	LPCWSTR p;
	while (pCur != NULL)
	{
		if (pCur->o.cx)
			return pCur;
		else if (wszCharSet != NULL)
		{
			p = wszCharSet;
			while (*p)
			{
				if (*p == pCur->o.c)
					return pCur;
				p++;
			}
		}
		pCur = pCur->pNext;
	}
	return NULL;
}

//取得下个字符。过程会过滤掉光标和选择标记。从pCur开始，包括pCur。
PEObjLink CETextBuffer::GetNextChar(PEObjLink pCur)
{
	while (pCur != NULL)
	{
		if (!(iscaret(pCur) || isSelection(pCur)))
			return pCur;
		pCur = pCur->pNext;
	}
	return NULL;
}

//取得前个字符。过程会过滤掉光标和选择标记。从pCur开始，包括pCur。
PEObjLink CETextBuffer::GetPrevChar(PEObjLink pCur)
{
	while (pCur != NULL)
	{
		if (!(iscaret(pCur) || isSelection(pCur)))
			return pCur;
		pCur = pCur->pPrev;
	}
	return NULL;
}

//从pCur开始，包括pCur，往回搜索，直到字符宽度非0返回。如果wszCharSet非空，遇到wszCharSet中的字符也返回
PEObjLink CETextBuffer::GetPrevNonZeroChar(PEObjLink pCur, LPCWSTR wszCharSet/* = NULL*/)
{
	LPCWSTR p;
	while (pCur != NULL)
	{
		if (pCur->o.cx)
			return pCur;
		else if (wszCharSet != NULL)
		{
			p = wszCharSet;
			while (*p)
			{
				if (*p == pCur->o.c)
					return pCur;
				p++;
			}
		}
		pCur = pCur->pPrev;
	}
	return NULL;
}

PEObjLink CETextBuffer::InsertBefore(PEObjLink pTlink, WCHAR c, LONG cx, LONG cy)
{
	EditObj o;
	init_editobj(o);
	o.cx = cx;
	o.cy = cy;
	o.c = c;
	return CEditObjBuf::InsertBefore(pTlink, o);
}
//insert then return new
PEObjLink CETextBuffer::InsertAfter(PEObjLink pTlink, WCHAR c, LONG cx, LONG cy)
{
	EditObj o;
	init_editobj(o);
	o.cx = cx;
	o.cy = cy;
	o.c = c;
	return CEditObjBuf::InsertAfter(pTlink, o);
}

PEObjLink CETextBuffer::Insert(HBITMAP hBmp, LONG cx, LONG cy)
{
	ASSERT(m_pCaret != NULL);
	if (m_pCaret == NULL)
		return NULL;
	EditObj o;
	CBitmapContext *pCtx = new CBitmapContext();
	if (pCtx == NULL)
		return NULL;
	pCtx->m_hBmp = hBmp;
	init_editobj(o);
	o.pCt = pCtx;
	o.type = ETYPE_BITMAP;
	o.cx = cx;
	o.cy = cy;
	o.c = 0xffff;
	return CEditObjBuf::InsertBefore(m_pCaret, o);
}

//在当前光标前面插入字符
PEObjLink CETextBuffer::Insert(WCHAR c, LONG cx, LONG cy)
{
	ASSERT(m_pCaret != NULL);
	if (m_pCaret == NULL)
		return NULL;
	EditObj o;
	init_editobj(o);
	o.cx = cx;
	o.cy = cy;
	o.c = c;
	return CEditObjBuf::InsertBefore(m_pCaret, o);
}

//删除所有字符，除了光标
void CETextBuffer::Empty(CEPtrList<PEObjLink> * pExcept/* = NULL*/)
{
	CEditObjBuf::Empty(pExcept/*m_pCaret*/);
	if (pExcept == NULL)
	{
		if (m_pCaret)
			m_pCaret = NULL;
		if (m_pSelStart)
			m_pSelStart = NULL;
		if (m_pSelEnd)
			m_pSelEnd = NULL;
	}
}

void CETextBuffer::OnFreeObjectContext(PEObjLink pLink)
{
	if (pLink->o.type == ETYPE_BITMAP)
	{
		if (pLink->o.pCt != NULL)
		{
			CBitmapContext *pBmpCtx = static_cast<CBitmapContext *>(pLink->o.pCt);
			delete pBmpCtx;
			pLink->o.pCt = NULL;
		}
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
CBitmapContext::CBitmapContext()
	:m_hBmp(NULL)
{
}

CBitmapContext::~CBitmapContext()
{
	if (m_hBmp)
	{
		::DeleteObject(m_hBmp);
		m_hBmp = NULL;
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
CETextManager::CETextManager()
	: m_parags(TRUE)
	, m_ranges(TRUE), m_buffer(1024)
	, m_errorWords(TRUE)
{
	m_rcText.SetRectEmpty();
	m_sSymbols = L",./?;\'\\[]{}:\" | <>!。，、；：？！…—·ˉˇ¨‘’“”々～‖∶＂＇｀｜〃〔〕〈〉《》「」『』．〖〗【】（）［］｛｝";
	m_baseLineHeight = 16;
	m_bSingleLine = FALSE;
	//m_bOverwriteMode = FALSE;
	m_sizeCaret.cx = 1;
	m_sizeCaret.cy = 16;
	m_bAutoWrapLines = TRUE;
	//默认行尾是 \r\n，但是编辑过程中，所有 \r\n 都被转换成 \n。只有在输出文本或者存盘时才存成预设 \r\n 或者 仅仅 \n。
	m_crlf[0] = L'\r';
	m_crlf[1] = L'\n';
	m_crlf[2] = 0;
}
CETextManager::~CETextManager()
{
	m_parags.RemoveAll();
	m_ranges.RemoveAll();
	m_buffer.Empty();
}

void CETextManager::Empty()
{
	EmptyParagraph();
	EmptyTextRanges();
	EmptyBuffer();
}

void CETextManager::EmptyParagraph()
{
	//删除所有只留下一个空行
	while (m_parags.GetCount() > 1)
		delete m_parags.RemoveTail();
	if (m_parags.GetCount())
	{
		CETextParagraph *pParag = m_parags.GetHead();
		while (pParag->lines.GetCount() > 1)
			delete pParag->lines.RemoveTail();
		if (pParag->lines.GetCount())
		{
			pParag->lines.GetHead()->clst.RemoveAll();
			//只留下个光标
			pParag->lines.GetHead()->clst.AddTail(m_buffer.GetCaret());
		}
	}
}

void CETextManager::EmptyTextRanges()
{
	//删除所有，只留下第一个 空白 的 
	while (m_ranges.GetCount()>1)
		delete m_ranges.RemoveTail();
	if (m_ranges.GetCount())
	{
		CETextRange *pRange = m_ranges.GetHead();
		pRange->m_links.RemoveAll();
	}
}

void CETextManager::EmptyBuffer()
{
	CharList lst(FALSE);
	lst.AddTail(m_buffer.GetCaret());
	lst.AddTail(m_buffer.GetSelectionStart());
	lst.AddTail(m_buffer.GetSelectionEnd());
	m_buffer.Empty(&lst);
}

CPoint CETextManager::GetCaretPos()
{
	//return m_caretPos;
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	CPoint point(pcaret->o.x, pcaret->o.y);
	return point;
}

void CETextManager::SetOverwriteMode(BOOL bSet)
{
	m_buffer.SetOverwriteMode(bSet);
}
BOOL CETextManager::IsOverwriteMode()
{
	return m_buffer.IsOverwriteMode();
}
BOOL CETextManager::GetOverwriteMode()
{
	return m_buffer.GetOverwriteMode();
}
void CETextManager::SetForceInsertMode(BOOL bSet)
{
	m_buffer.SetForceInsertMode(bSet);
}
BOOL CETextManager::IsForceInsertMode()
{
	return m_buffer.IsForceInsertMode();
}

BOOL CETextManager::Init(
	IN LONG lineSpace,
	IN LONG charSpace,
	IN LONG tabWidth,
	IN LONG baseLineHeight,
	IN PLOGFONTW pFont,
	IN COLORREF clrBk,
	IN COLORREF clrText,
	IN BOOL bSingleLine,
	IN BOOL bAutoWrapLines,
	LPCWSTR wszLineTerminated/* = L"\r\n"*/)
{
	ASSERT(wcslen(wszLineTerminated) >= 1 && wcslen(wszLineTerminated) <= 2);
	LPCWSTR p = wszLineTerminated;
	m_crlf[0] = *p++;
	if (*p)
	{
		m_crlf[1] = *p;
		ASSERT(m_crlf[0] == L'\r');
		ASSERT(m_crlf[1] == L'\n');
	}
	else
	{
		ASSERT(m_crlf[0] == L'\n');
		m_crlf[1] = 0;
	}
	if (bSingleLine)
	{
		ASSERT(!bAutoWrapLines);
	}
	m_bAutoWrapLines = m_bAutoWrapLines;
	m_bSingleLine = bSingleLine;
	m_lineSpace = lineSpace;
	//m_charSpace = charSpace;	// MulDiv(charSpace, GetDeviceCaps(pDC->m_hDC, LOGPIXELSX), 72);
	m_tabWidth = tabWidth;	// MulDiv(tabWidth, GetDeviceCaps(pDC->m_hDC, LOGPIXELSX), 72);
	m_baseLineHeight = baseLineHeight;
	CETextRange *pRange = new CETextRange();
	if (pRange == NULL)
		return FALSE;
	m_ranges.AddTail(pRange);
	pRange->m_crBk = clrBk;
	pRange->m_crText = clrText;
	pRange->m_font = *pFont;
	//初始化就添加一个空行
	CETextParagraph *pPrag = new CETextParagraph();
	if (pPrag == NULL)
		return FALSE;
	m_parags.AddTail(pPrag);
	pPrag->cx = 0;
	pPrag->cy = baseLineHeight + m_lineSpace;
	CETextLine *pLine = new CETextLine(pPrag);
	if (pLine == NULL)
		return FALSE;
	pPrag->lines.AddTail(pLine);
	pLine->cx = 0;
	pLine->cy = baseLineHeight + m_lineSpace;
	if (!m_buffer.CreateSelection())
		return FALSE;
	PEObjLink pcaret = m_buffer.CreateCaret();
	if (pcaret == NULL)
		return FALSE;
	pcaret->o.cx = 0;
	pcaret->o.cy = baseLineHeight;
	pLine->clst.AddTail(pcaret);
	pRange->m_links.AddTail(pcaret);
	m_sizeCaret.cx = 1;
	m_sizeCaret.cy = baseLineHeight;
	if (/*m_bOverwriteMode*/m_buffer.IsOverwriteMode())
		m_sizeCaret.cx = 8;
	return TRUE;
}

void CETextManager::SetTextRect(CRect& rcText)
{
	m_rcText = rcText;
	CalcParagraphs();
}
CRect CETextManager::GetTextRect()
{
	return m_rcText;
}
//返回 pChar 所在的 text range,
CETextRange * CETextManager::GetTextRange(PEObjLink pChar)
{
	ASSERT(m_ranges.GetCount() > 0);
	if (m_ranges.GetCount()==0)
		return NULL;
	if (pChar == NULL)
		return m_ranges.GetHead();
	if (iscaret(&pChar->o))
	{
		if (pChar->pPrev)
			pChar = pChar->pPrev;
		else
			pChar = pChar->pNext;
	}
	PRangeNode pNode = m_ranges.GetHeadNode();
	while (pNode)
	{
		if (pNode->pdata->m_links.Find(pChar) != NULL)
			return pNode->pdata;
		pNode = pNode->pNext;
	}
	return m_ranges.GetHead();
}

SIZE CETextManager::GetCaretSize()
{
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PCharNode pCaretNode;
	CETextLine *pLine = GetLine(pcaret, NULL, NULL, &pCaretNode);
	LONG cx = m_sizeCaret.cx;
	LONG cy = m_sizeCaret.cy;
	cx = 1;
	//PCharNode pNext = pCaretNode->pNext;
	//PCharNode pPrev = pCaretNode->pPrev;
	//若光标在\n之前，应以prev优先
	BOOL bIsNextLineFeedChar = FALSE;
	if (pCaretNode->pNext)
	{
		if (islf(pCaretNode->pNext->pdata))
			bIsNextLineFeedChar = TRUE;
	}
	PCharNode pCharNode = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		if (bIsNextLineFeedChar)
		{
			pCharNode = LineFindPrevNZNode(pCaretNode);
			if (pCharNode == NULL)
				pCharNode = LineFindNextNZNode(pCaretNode);
		}
		else
		{
			pCharNode = LineFindNextNZNode(pCaretNode);
			if (pCharNode == NULL)
				pCharNode = LineFindPrevNZNode(pCaretNode);
		}
	}
	else
	{
		pCharNode = LineFindPrevNZNode(pCaretNode);
		if (pCharNode == NULL)
			pCharNode = LineFindNextNZNode(pCaretNode);
	}
	if (pCharNode == NULL)
	{
		if (m_buffer.IsOverwriteMode())
		{
			if (bIsNextLineFeedChar)
			{
				pCharNode = pCaretNode->pPrev;
				if (pCharNode == NULL)
					pCharNode = pCaretNode->pNext;
			}
			else
			{
				pCharNode = pCaretNode->pNext;
				if (pCharNode == NULL)
					pCharNode = pCaretNode->pPrev;
			}
		}
		else
		{
			pCharNode = pCaretNode->pPrev;
			if (pCharNode == NULL)
				pCharNode = pCaretNode->pNext;
		}
	}
	if (pCharNode)
	{
		if (m_buffer.IsOverwriteMode())
		{
			if (pCharNode->pdata->o.cx)
			{
				cx = pCharNode->pdata->o.cx;
			}
		}
		cy = pCharNode->pdata->o.cy;
	}
	else
	{
		if (m_buffer.IsOverwriteMode())
			cx = 8;
	}
	m_sizeCaret.cx = cx;
	m_sizeCaret.cy = cy;
	return m_sizeCaret;
}
//根据光标前后的字符情况和overwritemode来确定光标的位置和高度
void CETextManager::FixCaretPosition()
{
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pLineNode != NULL && pCaretNode != NULL);
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
	}
	//if (pRefTo == NULL)
	//{
	//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
	//	if (pRefTo)
	//	{
	//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
	//		pcaret->o.y = pRefTo->pdata->o.y;
	//		pcaret->o.cy = pRefTo->pdata->o.cy;
	//	}
	//}
}

//重建光标后调用，设置光标的当前高度。光标的高度和旁边的字符高度有关。
void CETextManager::SetCaretHeight(LONG height)
{
	PEObjLink pcaret = m_buffer.GetCaret();
	if (pcaret)
	{
		pcaret->o.cy = height;
	}
}

//确保光标可见。返回 TRUE 表示发生了滚屏。可以返回一个行位置发生改变的行列表。
BOOL CETextManager::EnsureCaretVisible(
	OUT LPRECT pRectChanged/* = NULL*/,
	IN OUT PARAGLIST *pLinesChanged/* = NULL*/)
{
	CSize size = GetCaretSize();
	CPoint point = GetCaretPos();
	LONG lScroll = 0;
	if (m_bSingleLine)
	{
		if (point.x + size.cx > m_rcText.right)
			ScrollParagraphs((lScroll = m_rcText.right - (point.x + size.cx)), 0, NULL, pRectChanged, pLinesChanged);
		else if (point.x < m_rcText.left)
			ScrollParagraphs((lScroll = m_rcText.left - point.x), 0, NULL, pRectChanged, pLinesChanged);
	}
	else
	{
		if (point.y + size.cy > m_rcText.bottom)
			ScrollParagraphs(0, (lScroll = m_rcText.bottom - (point.y + size.cy)), NULL, pRectChanged, pLinesChanged);
		else if (point.y < m_rcText.top)
			ScrollParagraphs(0, (lScroll = m_rcText.top - point.y), NULL, pRectChanged, pLinesChanged);
	}
	return lScroll != 0 ? TRUE : FALSE;
}

//取得所有段合集的第一行
CETextLine *CETextManager::GetTopLine()
{
	PPARAGNODE pParagNode = m_parags.GetHeadNode();
	ASSERT(pParagNode);
	if (pParagNode == NULL)
		return NULL;
	PLineNode pLineNode = pParagNode->pdata->lines.GetHeadNode();
	ASSERT(pLineNode);
	if (pLineNode == NULL)
		return NULL;
	return pLineNode->pdata;
}
//取得所有段合集的最后一行
CETextLine *CETextManager::GetBottomLine()
{
	PPARAGNODE pParagNode = m_parags.GetTailNode();
	ASSERT(pParagNode);
	if (pParagNode == NULL)
		return NULL;
	PLineNode pLineNode = pParagNode->pdata->lines.GetTailNode();
	ASSERT(pLineNode);
	if (pLineNode == NULL)
		return NULL;
	return pLineNode->pdata;
}

//取得所有段合集的前一行
CETextLine *CETextManager::GetPrevLine(CETextLine *pCur)
{
	PPARAGNODE pParagNode = m_parags.Find(pCur->pP);
	ASSERT(pParagNode);
	if (pParagNode == NULL)
		return NULL;
	BOOL bFound = FALSE;
	PLineNode pLineNode;
	while (pParagNode)
	{
		if (!bFound)
		{
			pLineNode = pParagNode->pdata->lines.Find(pCur);
			if (pLineNode)
			{
				bFound = TRUE;
				if (pLineNode->pPrev)
					return pLineNode->pPrev->pdata;
			}
		}
		else
		{
			//如果在目标行所在段中找不到前一行，那么前一个段的最后一行就是要找的行了
			pLineNode = pParagNode->pdata->lines.GetTailNode();
			ASSERT(pLineNode);
			if (pLineNode)
				return pLineNode->pdata;
		}
		pParagNode = pParagNode->pPrev;
	}
	return NULL;
}

//取得所有段合集的下一行
CETextLine *CETextManager::GetNextLine(CETextLine *pCur)
{
	PPARAGNODE pParagNode = m_parags.Find(pCur->pP);
	ASSERT(pParagNode);
	if (pParagNode == NULL)
		return NULL;
	BOOL bFound = FALSE;
	PLineNode pLineNode;
	while (pParagNode)
	{
		if (!bFound)
		{
			pLineNode = pParagNode->pdata->lines.Find(pCur);
			if (pLineNode)
			{
				bFound = TRUE;
				if (pLineNode->pNext)
					return pLineNode->pNext->pdata;
			}
		}
		else
		{
			//如果在目标行所在段中找不到下一行，那么后一个段的第一行就是要找的行了
			pLineNode = pParagNode->pdata->lines.GetHeadNode();
			ASSERT(pLineNode);
			if (pLineNode)
				return pLineNode->pdata;
		}
		pParagNode = pParagNode->pNext;
	}
	return NULL;
}

//移动光标到ptNew指示的位置附件（注意：最终光标出现的位置会根据ptNew下的行段情况调整。)
//本过程会和 CaretClick 几乎一样
BOOL CETextManager::MoveCaretNear(POINT ptNew, BOOL bMouseTracking/* = FALSE*/)
{
	if (!bMouseTracking)
	{
		if (!m_rcText.PtInRect(ptNew))
			return FALSE;
	}
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	CRect rcLine, rcText, rcObj, rcL, rcR;
	int nPos = 0;
	CETextRange *pRange;
	PCharNode pLinkNode;
	PLineNode pLineNode;
	PCharNode pNodeFound = NULL;
	PLineNode pLineFound = NULL;
	BOOL bFound;
	PPARAGNODE pParagNode;
	bFound = FALSE;
	if (m_rcText.PtInRect(ptNew))
	{
		pParagNode = m_parags.GetHeadNode();
		while (pParagNode && !bFound)
		{
			pLineNode = pParagNode->pdata->lines.GetHeadNode();
			while (pLineNode && !bFound)
			{
				rcText.SetRect(
					pLineNode->pdata->x,
					pLineNode->pdata->y,
					pLineNode->pdata->x + pLineNode->pdata->cx,
					pLineNode->pdata->y + pLineNode->pdata->cy - m_lineSpace);
				rcLine.SetRect(
					/*pLineNode->pdata->x*/m_rcText.left,
					pLineNode->pdata->y,
					max(pLineNode->pdata->x + pLineNode->pdata->cx, m_rcText.right),
					pLineNode->pdata->y + pLineNode->pdata->cy/* - m_lineSpace*/);
				if (rcLine.PtInRect(ptNew))
				{
					pLinkNode = pLineNode->pdata->clst.GetHeadNode();
					while (pLinkNode && !bFound)
					{
						if (pLinkNode->pdata->o.cx)
						{
							rcObj.SetRect(
								pLinkNode->pdata->o.x,
								pLinkNode->pdata->o.y,
								pLinkNode->pdata->o.x + pLinkNode->pdata->o.cx,
								pLinkNode->pdata->o.y + pLinkNode->pdata->o.cy
								);
							if (rcObj.top != rcLine.top)
								rcObj.top = rcLine.top;
							if (rcObj.bottom != rcLine.bottom - m_lineSpace)
								rcObj.bottom = rcLine.bottom - m_lineSpace;
							if (rcObj.PtInRect(ptNew))
							{
								pLineFound = pLineNode;
								pNodeFound = pLinkNode;
								bFound = TRUE;
								rcL = rcR = rcObj;
								rcL.right = rcL.left + rcObj.Width() / 2;
								rcR.left = rcL.right;
								nPos = 0;
								if (rcL.PtInRect(ptNew))
									nPos = -1;
								else if (rcR.PtInRect(ptNew))
									nPos = 1;
								break;
							}
							else
							{
								pRange = GetTextRange(pLinkNode->pdata);
								rcL = rcR = rcObj;
								rcL.OffsetRect(-pRange->m_charSpace, 0);
								//space + 1/5 char cx
								rcL.right = rcL.left + pRange->m_charSpace + LONG((double)rcObj.Width() / 5.0f);
								rcR.OffsetRect(rcObj.Width() - LONG((double)rcObj.Width() / 5.0f), 0);
								//1/5 char cx + space
								rcR.right = rcR.left + pRange->m_charSpace;
								if (rcL.PtInRect(ptNew))
								{
									pNodeFound = pLinkNode;
									pLineFound = pLineNode;
									bFound = TRUE;
									nPos = -1;
									break;
								}
								else if (rcR.PtInRect(ptNew))
								{
									pNodeFound = pLinkNode;
									pLineFound = pLineNode;
									bFound = TRUE;
									nPos = 1;
									break;
								}
							}//end if not in rect
						}//end if cx>0
						pLinkNode = pLinkNode->pNext;
					}//end while pLinkNode
					if (pNodeFound == NULL && !bFound)
					{
						//在文本行的右边点击，则移到右边
						if (ptNew.x >= rcText.right)
						{
							pNodeFound = LineFindPrevNZNode(
								pLineNode->pdata->clst.GetTailNode(), L'\n');
							if (pNodeFound == NULL)
							{
								pNodeFound = pLineNode->pdata->clst.GetTailNode();
							}
							bFound = TRUE;
							pLineFound = pLineNode;
							//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
							nPos = 1;
							break;
						}
						else if (ptNew.x <= rcText.left)
						{
							pNodeFound = LineFindNextNZNode(pLineNode->pdata->clst.GetHeadNode(), L'\n');
							if (pNodeFound == NULL)
							{
								pNodeFound = pLineNode->pdata->clst.GetHeadNode();
							}
							bFound = TRUE;
							pLineFound = pLineNode;
							//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
							nPos = -1;
							break;
						}
						else
						{
							//检测鼠标出现在行的左边还是右边，如果是左边，就让光标出现在最左边，右边就出现在最右边
							rcL = rcR = rcLine;
							rcL.right = rcLine.left + rcLine.Width() / 2;
							rcR.left = rcL.right;
							if (rcL.PtInRect(ptNew))
							{
								pNodeFound = LineFindNextNZNode(
									pLineNode->pdata->clst.GetHeadNode(),
									L'\n');
								if (pNodeFound == NULL)
								{
									pNodeFound = pLineNode->pdata->clst.GetHeadNode();
								}
								bFound = TRUE;
								pLineFound = pLineNode;
								//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
								nPos = -1;
								break;
							}
							else if (rcR.PtInRect(ptNew))
							{
								pNodeFound = LineFindPrevNZNode(
									pLineNode->pdata->clst.GetTailNode(),
									L'\n');
								if (pNodeFound == NULL)
								{
									pNodeFound = pLineNode->pdata->clst.GetTailNode();
								}
								bFound = TRUE;
								pLineFound = pLineNode;
								//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
								nPos = 1;
								break;
							}
						}
					}//end if pNodeFound==NULL
				}//end if ptinrect
				pLineNode = pLineNode->pNext;
			}//end while pLineNode
			pParagNode = pParagNode->pNext;
		}//end while (pParagNode && !bFound)
	}//end if (m_rcText.PtInRect(ptNew))
	else
	{
		//如果焦点出现在 m_rcText 之外 （在 mouse tracking 下会出现），我们使用模糊算法
		pParagNode = m_parags.GetHeadNode();
		while (pParagNode && !bFound)
		{
			pLineNode = pParagNode->pdata->lines.GetHeadNode();
			while (pLineNode && !bFound)
			{
				rcText.SetRect(
					pLineNode->pdata->x,
					pLineNode->pdata->y,
					pLineNode->pdata->x + pLineNode->pdata->cx,
					pLineNode->pdata->y + pLineNode->pdata->cy - m_lineSpace);
				rcLine.SetRect(
					m_rcText.left,
					pLineNode->pdata->y,
					max(pLineNode->pdata->x + pLineNode->pdata->cx, m_rcText.right),
					pLineNode->pdata->y + pLineNode->pdata->cy);
				//如果焦点y坐标在行之间 或者 在第一行的上面 或者 在最后一行的下面
				if ((ptNew.y <= rcLine.bottom && ptNew.y >= rcLine.top)||
					(pParagNode->pPrev == NULL && pLineNode->pPrev==NULL && ptNew.y<rcLine.top) ||
					(pParagNode->pNext == NULL && pLineNode->pNext==NULL && ptNew.y<rcLine.bottom))
				{
					pLinkNode = pLineNode->pdata->clst.GetHeadNode();
					while (pLinkNode && !bFound)
					{
						if (pLinkNode->pdata->o.cx)
						{
							rcObj.SetRect(
								pLinkNode->pdata->o.x,
								pLinkNode->pdata->o.y,
								pLinkNode->pdata->o.x + pLinkNode->pdata->o.cx,
								pLinkNode->pdata->o.y + pLinkNode->pdata->o.cy
								);
							if (rcObj.top != rcLine.top)
								rcObj.top = rcLine.top;
							if (rcObj.bottom != rcLine.bottom - m_lineSpace)
								rcObj.bottom = rcLine.bottom - m_lineSpace;
							if (ptNew.x >= rcObj.left && ptNew.x <= rcObj.right)
							{
								pLineFound = pLineNode;
								pNodeFound = pLinkNode;
								bFound = TRUE;
								rcL = rcR = rcObj;
								rcL.right = rcL.left + rcObj.Width() / 2;
								rcR.left = rcL.right;
								nPos = 0;
								if (ptNew.x >= rcL.left && ptNew.x <= rcL.right)
									nPos = -1;
								else if (ptNew.x >= rcR.left && ptNew.x <= rcR.right)
									nPos = 1;
								break;
							}
							else
							{
								pRange = GetTextRange(pLinkNode->pdata);
								rcL = rcR = rcObj;
								rcL.OffsetRect(-pRange->m_charSpace, 0);
								//space + 1/5 char cx
								rcL.right = rcL.left + pRange->m_charSpace + LONG((double)rcObj.Width() / 5.0f);
								rcR.OffsetRect(rcObj.Width() - LONG((double)rcObj.Width() / 5.0f), 0);
								//1/5 char cx + space
								rcR.right = rcR.left + pRange->m_charSpace;
								if (ptNew.x >= rcL.left && ptNew.x <= rcL.right)
								{
									pNodeFound = pLinkNode;
									pLineFound = pLineNode;
									bFound = TRUE;
									nPos = -1;
									break;
								}
								else if (ptNew.x >= rcR.left && ptNew.x <= rcR.right)
								{
									pNodeFound = pLinkNode;
									pLineFound = pLineNode;
									bFound = TRUE;
									nPos = 1;
									break;
								}
							}//end if not in rect
						}//end if cx>0
						pLinkNode = pLinkNode->pNext;
					}//end while pLinkNode
					if (pNodeFound == NULL && !bFound)
					{
						//在文本行的右边点击，则移到右边
						if (ptNew.x >= rcText.right)
						{
							pNodeFound = LineFindPrevNZNode(
								pLineNode->pdata->clst.GetTailNode(), L'\n');
							if (pNodeFound == NULL)
							{
								pNodeFound = pLineNode->pdata->clst.GetTailNode();
							}
							bFound = TRUE;
							pLineFound = pLineNode;
							//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
							nPos = 1;
							break;
						}
						else if (ptNew.x <= rcText.left)
						{
							pNodeFound = LineFindNextNZNode(pLineNode->pdata->clst.GetHeadNode(), L'\n');
							if (pNodeFound == NULL)
							{
								pNodeFound = pLineNode->pdata->clst.GetHeadNode();
							}
							bFound = TRUE;
							pLineFound = pLineNode;
							//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
							nPos = -1;
							break;
						}
						else
						{
							//检测鼠标出现在行的左边还是右边，如果是左边，就让光标出现在最左边，右边就出现在最右边
							rcL = rcR = rcLine;
							rcL.right = rcLine.left + rcLine.Width() / 2;
							rcR.left = rcL.right;
							if (ptNew.x >= rcL.left && ptNew.x <= rcL.right)
							{
								pNodeFound = LineFindNextNZNode(
									pLineNode->pdata->clst.GetHeadNode(),
									L'\n');
								if (pNodeFound == NULL)
								{
									pNodeFound = pLineNode->pdata->clst.GetHeadNode();
								}
								bFound = TRUE;
								pLineFound = pLineNode;
								//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
								nPos = -1;
								break;
							}
							else if (ptNew.x >= rcR.left && ptNew.x <= rcR.right)
							{
								pNodeFound = LineFindPrevNZNode(
									pLineNode->pdata->clst.GetTailNode(),
									L'\n');
								if (pNodeFound == NULL)
								{
									pNodeFound = pLineNode->pdata->clst.GetTailNode();
								}
								bFound = TRUE;
								pLineFound = pLineNode;
								//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
								nPos = 1;
								break;
							}
						}
					}//end if pNodeFound==NULL
				}//end if ptinrect
				pLineNode = pLineNode->pNext;
			}//end while pLineNode
			pParagNode = pParagNode->pNext;
		}//end while (pParagNode && !bFound)
	}//end if (!m_rcText.PtInRect(ptNew))
	if (!bFound)
		return FALSE;
	ASSERT(pLineFound);
	if (pLineFound == NULL)
		return FALSE;
	PEObjLink pcaret = m_buffer.GetCaret();
	PCharNode pCaretNode;
	CETextLine *pCaretLine = GetLine(pcaret, NULL, NULL, &pCaretNode);
	ASSERT(pcaret && pCaretLine);
	if (pCaretNode == pNodeFound)
	{
		return TRUE;
	}
	pCaretLine->clst.RemoveAt(pCaretNode);
	if (pNodeFound)
	{
		if (IsLinefeedNode(pNodeFound))
		{
			m_buffer.CaretMoveBefore(pNodeFound->pdata);
			pCaretNode = pLineFound->pdata->clst.InsertBefore(pNodeFound, pcaret);
			//pcaret->o.x = pNodeFound->pdata->o.x;
			//pcaret->o.y = pNodeFound->pdata->o.y;
		}
		else
		{
			if (nPos <= 0)
			{
				m_buffer.CaretMoveBefore(pNodeFound->pdata);
				pCaretNode = pLineFound->pdata->clst.InsertBefore(pNodeFound, pcaret);
				//pcaret->o.x = pNodeFound->pdata->o.x;
				//pcaret->o.y = pNodeFound->pdata->o.y;
			}
			else
			{
				m_buffer.CaretMoveAfter(pNodeFound->pdata);
				pCaretNode = pLineFound->pdata->clst.InsertAfter(pNodeFound, pcaret);
				//pcaret->o.x = pNodeFound->pdata->o.x + pNodeFound->pdata->o.cx;
				//pcaret->o.y = pNodeFound->pdata->o.y;
			}
		}
	}
	else
	{
		BOOL bCaretFixed = FALSE;
		CETextLine *pLineX = GetPrevLine(pLineFound->pdata);
		if (pLineX)
		{
			ASSERT(pLineX->clst.GetCount() > 0);
			if (pLineX->clst.GetCount())
			{
				if (m_buffer.CaretMoveAfter(pLineX->clst.GetTail()))
					bCaretFixed = TRUE;
			}
		}
		if (!bCaretFixed)
		{
			pLineX = GetNextLine(pLineFound->pdata);
			if (pLineX)
			{
				if (pLineX->clst.GetCount())
				{
					if (m_buffer.CaretMoveBefore(pLineX->clst.GetHead()))
						bCaretFixed = TRUE;
				}
			}
		}
		pCaretNode = pLineFound->pdata->clst.AddHead(pcaret);
		pcaret->o.x = pLineFound->pdata->x;
		pcaret->o.y = pLineFound->pdata->y;
	}
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
	}
	//if (pRefTo == NULL)
	//{
	//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
	//	if (pRefTo)
	//	{
	//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
	//		pcaret->o.y = pRefTo->pdata->o.y;
	//		pcaret->o.cy = pRefTo->pdata->o.cy;
	//	}
	//}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	//EnsureCaretVisible(pRectChanged, NULL);
	OnCaretMove(pcaret);
	return TRUE;
}

//移动光标到最前面
BOOL CETextManager::CaretGoHead(LPRECT pRectChanged/* = NULL*/)
{
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	if (m_buffer.GetPrevNonZeroChar(pcaret->pPrev) == NULL)
		return TRUE;
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pLineNode != NULL && pCaretNode != NULL);
	CETextLine *pLineTop = GetTopLine();
	ASSERT(pLineTop);
	if (pLineTop == NULL)
		return FALSE;
	pLine->clst.RemoveAt(pCaretNode);
	pCaretNode = pLineTop->clst.AddHead(pcaret);
	if (pCaretNode == NULL)
		return FALSE;
	if (!m_buffer.CaretMoveBefore(m_buffer.m_pLinkHead))
		return FALSE;
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			//pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			//if (pRefTo)
			//{
			pcaret->o.x = pLineTop->x;
			pcaret->o.y = pLineTop->y;
			pcaret->o.cy = pLineTop->cy;
			//}
		}
	}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(pcaret);
	return TRUE;
}

//移动光标到最后面
BOOL CETextManager::CaretGoTail(LPRECT pRectChanged/* = NULL*/)
{
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	if (m_buffer.GetNextNonZeroChar(pcaret->pNext) == NULL)
		return TRUE;
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pLineNode != NULL && pCaretNode != NULL);
	CETextLine *pLineBottom = GetBottomLine();
	ASSERT(pLineBottom);
	if (pLineBottom == NULL)
		return FALSE;
	pLine->clst.RemoveAt(pCaretNode);
	pCaretNode = pLineBottom->clst.AddTail(pcaret);
	if (pCaretNode == NULL)
		return FALSE;
	if (!m_buffer.CaretMoveAfter(m_buffer.m_pLinkTail))
		return FALSE;
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev)
		{
			//pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			//pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			//if (pRefTo)
			//{
			pcaret->o.x = pLineBottom->x;
			pcaret->o.y = pLineBottom->y;
			pcaret->o.cy = pLineBottom->cy;
			//}
		}
	}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(pcaret);
	return TRUE;
}

BOOL CETextManager::CaretGoUpLine(LPRECT pRectChanged/* = NULL*/)
{
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pLineNode != NULL && pCaretNode != NULL);
	//如果已经是第一行了，就返回了
	if (GetTopLine() == pLine)
		return FALSE;
	CETextLine *pLinePrev;
	if (pLineNode->pPrev)
		pLinePrev = pLineNode->pPrev->pdata;
	else
		pLinePrev = GetPrevLine(pLine);
	ASSERT(pLinePrev);	//since if (GetTopLine() == pLine)...
	if (pLinePrev == NULL)
		return FALSE;
	enum
	{
		pos_unk = 0,
		pos_right = 1,
		pos_left = -1,
	};
	int nCharPos = pos_unk;	//0-unknown, 1-right side, -1 -left side
	PCharNode pCharNode = NULL;
	//如果光标位置非行头，则根据光标的位置，在前行中搜索一个位置相当的字符
	if (pcaret->o.x > pLine->x)
	{
		PCharNode pCharNode2 = pLinePrev->clst.GetHeadNode();
		while (pCharNode2)
		{
			if ((pcaret->o.x >= pCharNode2->pdata->o.x) &&
				(pcaret->o.x <= pCharNode2->pdata->o.x + pCharNode2->pdata->o.cx))
			{
				pCharNode = pCharNode2;
				if ((pcaret->o.x >= pCharNode2->pdata->o.x) &&
					(pcaret->o.x <= pCharNode2->pdata->o.x + pCharNode2->pdata->o.cx / 2))
					nCharPos = pos_left;
				else
					nCharPos = pos_right;
				break;
			}
			pCharNode2 = pCharNode2->pNext;
		}//end while (pCharNode2)
		//也许当前光标的x坐标大于pLinePrev的行尾或者小于行头，这样的话我们找找行的末尾或者行头字符
		if (pCharNode == NULL)
		{
			if (pLinePrev->clst.GetCount())
			{
				PCharNode pHeadNode = pLinePrev->clst.GetHeadNode();
				PCharNode pTailNode = pLinePrev->clst.GetTailNode();
				if (pTailNode)
				{
					if (pcaret->o.x >= pTailNode->pdata->o.x)
					{
						pCharNode2 = LineFindPrevNZNode(pTailNode);
						if (pCharNode2)
						{
							pCharNode = pCharNode2;
							nCharPos = pos_right;
						}
					}
				}
				if (pHeadNode)
				{
					if (pcaret->o.x <= pHeadNode->pdata->o.x)
					{
						pCharNode2 = LineFindNextNZNode(pHeadNode);
						if (pCharNode2)
						{
							pCharNode = pCharNode2;
							nCharPos = pos_left;
						}
					}
				}
			}//end if (pLinePrev->clst.GetCount())
		}//end if (pCharNode == NULL)
	} //end if (pcaret->o.x > pLine->x)
	pLine->clst.RemoveAt(pCaretNode);
	pCaretNode = NULL;
	if (pCharNode == NULL)
	{
		//如果在前行中没有找到位置相当的字符，就移动到前行的最前面
		pCharNode = pLinePrev->clst.AddHead(pcaret);
		pCaretNode = pCharNode;
		////buffer 中光标
		//if (pCharNode->pPrev)
		//{
		//	m_buffer.CaretMoveAfter(pCharNode->pPrev->pdata);
		//	pcaret->o.x = pCharNode->pPrev->pdata->o.x + pCharNode->pPrev->pdata->o.cx;
		//	pcaret->o.y = pCharNode->pPrev->pdata->o.y;
		//}
		//else 
		if (pCharNode->pNext)
		{
			m_buffer.CaretMoveBefore(pCharNode->pNext->pdata);
			pcaret->o.x = pCharNode->pNext->pdata->o.x;
			pcaret->o.y = pCharNode->pNext->pdata->o.y;
		}
		else
		{
			pCharNode = FindPrevNode(pcaret);
			if (pCharNode)
			{
				m_buffer.CaretMoveAfter(pCharNode->pdata);
			}
			else
			{
				pCharNode = FindNextNode(pcaret);
				if (pCharNode)
					m_buffer.CaretMoveBefore(pCharNode->pdata);
				//else
				//	m_buffer.
				//don't move
			}
			pcaret->o.x = pLinePrev->x;
			pcaret->o.y = pLinePrev->y;
		}
	}
	else
	{
		if (nCharPos == pos_left)
		{
			pCaretNode = pLinePrev->clst.InsertBefore(pCharNode, pcaret);
			m_buffer.CaretMoveBefore(pCharNode->pdata);
		}
		else
		{
			pCaretNode = pLinePrev->clst.InsertAfter(pCharNode, pcaret);
			m_buffer.CaretMoveAfter(pCharNode->pdata);
		}
		//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
		PCharNode pRefTo = NULL;
		if (m_buffer.IsOverwriteMode())
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			if (pCaretNode->pPrev == NULL)
			{
				pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
			if (pRefTo == NULL)
			{
				pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
		}
		//if (pRefTo == NULL)
		//{
		//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev);
		//	if (pRefTo)
		//	{
		//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
		//		pcaret->o.y = pRefTo->pdata->o.y;
		//		pcaret->o.cy = pRefTo->pdata->o.cy;
		//	}
		//}
	}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(pcaret);
	return TRUE;
}

//检测pNode是否一个换行符号 \n。不检测\r，因为它被忽略了。
BOOL CETextManager::IsLinefeedNode(PCharNode pNode)
{
	if (pNode == NULL)
		return FALSE;
	return islf(&pNode->pdata->o) ? TRUE : FALSE;
}

BOOL CETextManager::CaretGoDownLine(LPRECT pRectChanged/* = NULL*/)
{
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pParagNode!=NULL && pLineNode != NULL && pCaretNode != NULL);
	//如果已经是最后一行了，就返回了
	if (GetBottomLine() == pLine)
		return FALSE;
	CETextLine *pLineNext;
	if (pLineNode->pNext)
		pLineNext = pLineNode->pNext->pdata;
	else
		pLineNext = GetNextLine(pLine);
	ASSERT(pLineNext);	//since if (GetBottomLine() == pLine)...
	if (pLineNext == NULL)
		return FALSE;
	//PEObjLink pLink = NULL;
	enum
	{
		pos_unk = 0,
		pos_right = 1,
		pos_left = -1,
	};
	int nCharPos = pos_unk;	//0-unknown, 1-right side, -1 -left side
	PCharNode pCharNode = NULL;
	if (pcaret->o.x > pLine->x)
	{
		PCharNode pCharNode2 = pLineNext->clst.GetHeadNode();
		while (pCharNode2)
		{
			if ((pcaret->o.x >= pCharNode2->pdata->o.x) &&
				(pcaret->o.x <= pCharNode2->pdata->o.x + pCharNode2->pdata->o.cx))
			{
				pCharNode = pCharNode2;
				if ((pcaret->o.x >= pCharNode2->pdata->o.x) &&
					(pcaret->o.x <= pCharNode2->pdata->o.x + pCharNode2->pdata->o.cx / 2))
					nCharPos = pos_left;
				else
					nCharPos = pos_right;
				break;
			}
			pCharNode2 = pCharNode2->pNext;
		}//end while (pCharNode2)
		//也许当前光标的x坐标大于pLinePrev的行尾或者小于行头，这样的话我们找找行的末尾或者行头字符
		//if (pLink == NULL)
		if (pCharNode == NULL)
		{
			if (pLineNext->clst.GetCount())
			{
				PCharNode pHeadNode = pLineNext->clst.GetHeadNode();
				PCharNode pTailNode = pLineNext->clst.GetTailNode();
				if (pTailNode)
				{
					if (pcaret->o.x >= pTailNode->pdata->o.x)
					{
						pCharNode2 = LineFindPrevNZNode(pTailNode);
						if (pCharNode2)
						{
							pCharNode = pCharNode2;
							nCharPos = pos_right;
						}
					}
				}
				if (pHeadNode)
				{
					if (pcaret->o.x <= pHeadNode->pdata->o.x)
					{
						pCharNode2 = LineFindNextNZNode(pHeadNode);
						if (pCharNode2)
						{
							pCharNode = pCharNode2;
							nCharPos = pos_left;
						}
					}
				}
			}//end if (pLinePrev->clst.GetCount())
		}//end if (pCharNode == NULL)
	}
	pLine->clst.RemoveAt(pCaretNode);
	pCaretNode = NULL;
	if (pCharNode == NULL)
	{
		//光标插入到下行的行头
		pCharNode = pLineNext->clst.AddHead(pcaret);
		pCaretNode = pCharNode;
		//为光标在缓冲区的位置寻找参照物。
		if (pCharNode->pNext)
		{
			m_buffer.CaretMoveBefore(pCharNode->pNext->pdata);
			pcaret->o.x = pCharNode->pNext->pdata->o.x;
			pcaret->o.y = pCharNode->pNext->pdata->o.y;
		}
		else
		{
			pCharNode = FindPrevNode(pcaret);
			if (pCharNode)
			{
				m_buffer.CaretMoveAfter(pCharNode->pdata);
			}
			else
			{
				pCharNode = FindNextNode(pcaret);
				if (pCharNode)
					m_buffer.CaretMoveBefore(pCharNode->pdata);
				//else
				//	m_buffer.
				//don't move
			}
			pcaret->o.x = pLineNext->x;
			pcaret->o.y = pLineNext->y;
		}
	}
	else
	{
		if (nCharPos == pos_left)
		{
			pCaretNode = pLineNext->clst.InsertBefore(pCharNode, pcaret);
			m_buffer.CaretMoveBefore(pCharNode->pdata);
		}
		else
		{
			pCaretNode = pLineNext->clst.InsertAfter(pCharNode, pcaret);
			m_buffer.CaretMoveAfter(pCharNode->pdata);
		}
		//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
		PCharNode pRefTo = NULL;
		if (m_buffer.IsOverwriteMode())
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			if (pCaretNode->pPrev == NULL)
			{
				pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
			if (pRefTo == NULL)
			{
				pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
		}
		//if (pRefTo == NULL)
		//{
		//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
		//	if (pRefTo)
		//	{
		//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
		//		pcaret->o.y = pRefTo->pdata->o.y;
		//		pcaret->o.cy = pRefTo->pdata->o.cy;
		//	}
		//}
	}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(pcaret);
	return TRUE;

}
//单行搜索：在一行中，向右搜索一个cx>0的字符。意思是所有0宽度的字符或者对象被跳过。
//从pCur开始，包括pCur。如果指定cInc（非零），就算cInc的宽度是0，也返回。cInc 只能是 ETYPE_TEXT类型
PCharNode CETextManager::LineFindNextNZNode(PCharNode pCur, WCHAR cInc/* = 0*/)
{
	if (pCur == NULL)
		return NULL;
	PCharNode pCharNode = pCur;
	while (pCharNode)
	{
		if (pCharNode->pdata->o.cx > 0)
			return pCharNode;
		else if (cInc != 0)
		{
			if (pCharNode->pdata->o.type == ETYPE_TEXT)
			{
				if (pCharNode->pdata->o.c == cInc)
				{
					return pCharNode;
				}
			}
		}
		pCharNode = pCharNode->pNext;
	}
	return NULL;
}

//单行搜索：在一行中，向左搜索一个cx>0的字符。意思是所有0宽度的字符或者对象被跳过。
//从pCur开始，包括pCur。如果指定cInc（非零），就算cInc的宽度是0，也返回。cInc 只能是 ETYPE_TEXT类型
PCharNode CETextManager::LineFindPrevNZNode(PCharNode pCur, WCHAR cInc/* = 0*/)
{
	if (pCur == NULL)
		return NULL;
	PCharNode pCharNode = pCur;
	while (pCharNode)
	{
		if (pCharNode->pdata->o.cx > 0)
			return pCharNode;
		else if (cInc != 0)
		{
			if (pCharNode->pdata->o.type == ETYPE_TEXT)
			{
				if (pCharNode->pdata->o.c == cInc)
				{
					return pCharNode;
				}
			}
		}
		pCharNode = pCharNode->pPrev;
	}
	return NULL;
}
//多行搜索：往前搜索非0宽度对象。从pCur开始，包括pCur。如果指定cInc（非零），就算cInc的宽度是0，也返回。cInc 只能是 ETYPE_TEXT类型
PCharNode CETextManager::FindNextNZNode(
	IN PCharNode pCur,
	IN WCHAR cInc/* = 0*/,
	OUT PARAGNODE ** ppPragNode/* = NULL*/,
	OUT LineNode **ppLineNode/* = NULL*/)
{
	if (ppPragNode) *ppPragNode = NULL;
	if (ppLineNode) *ppLineNode = NULL;
	BOOL bFoundCur = FALSE;
	PPARAGNODE pXParagNode;
	PLineNode pXLineNode;
	PCharNode pXCharNode;
	pXParagNode = m_parags.GetHeadNode();
	while (pXParagNode)
	{
		pXLineNode = pXParagNode->pdata->lines.GetHeadNode();
		while (pXLineNode)
		{
			pXCharNode = pXLineNode->pdata->clst.GetHeadNode();
			while (pXCharNode)
			{
				if (pCur == pXCharNode)
				{
					if (!bFoundCur)
						bFoundCur = TRUE;
				}
				if (bFoundCur)
				{
					if (pXCharNode->pdata->o.cx > 0)
					{
						if (ppPragNode) *ppPragNode = pXParagNode;
						if (ppLineNode) *ppLineNode = pXLineNode;
						return pXCharNode;
					}
					else if (cInc != 0)
					{
						if (pXCharNode->pdata->o.type == ETYPE_TEXT)
						{
							if (pXCharNode->pdata->o.c == cInc)
							{
								if (ppPragNode) *ppPragNode = pXParagNode;
								if (ppLineNode) *ppLineNode = pXLineNode;
								return pXCharNode;
							}
						}
					}
				}
				pXCharNode = pXCharNode->pNext;
			}
			pXLineNode = pXLineNode->pNext;
		}
		pXParagNode = pXParagNode->pNext;
	}
	return NULL;
}

//多行搜索：往hui搜索非0宽度对象。从pCur开始，包括pCur。如果指定cInc（非零），就算cInc的宽度是0，也返回。cInc 只能是 ETYPE_TEXT类型
PCharNode CETextManager::FindPrevNZNode(
	IN PCharNode pCur,
	IN WCHAR cInc/* = 0*/,
	OUT PARAGNODE ** ppPragNode/* = NULL*/,
	OUT LineNode **ppLineNode/* = NULL*/)
{
	if (ppPragNode) *ppPragNode = NULL;
	if (ppLineNode) *ppLineNode = NULL;
	BOOL bFoundCur = FALSE;
	PPARAGNODE pXParagNode;
	PLineNode pXLineNode;
	PCharNode pXCharNode;
	pXParagNode = m_parags.GetTailNode();
	while (pXParagNode)
	{
		pXLineNode = pXParagNode->pdata->lines.GetTailNode();
		while (pXLineNode)
		{
			pXCharNode = pXLineNode->pdata->clst.GetTailNode();
			while (pXCharNode)
			{
				if (pCur == pXCharNode)
				{
					if (!bFoundCur)
						bFoundCur = TRUE;
				}
				if (bFoundCur)
				{
					if (pXCharNode->pdata->o.cx > 0)
					{
						if (ppPragNode) *ppPragNode = pXParagNode;
						if (ppLineNode) *ppLineNode = pXLineNode;
						return pXCharNode;
					}
					else if (cInc != 0)
					{
						if (pXCharNode->pdata->o.type == ETYPE_TEXT)
						{
							if (pXCharNode->pdata->o.c == cInc)
							{
								if (ppPragNode) *ppPragNode = pXParagNode;
								if (ppLineNode) *ppLineNode = pXLineNode;
								return pXCharNode;
							}
						}
					}
				}
				pXCharNode = pXCharNode->pPrev;
			}
			pXLineNode = pXLineNode->pPrev;
		}
		pXParagNode = pXParagNode->pPrev;
	}
	return NULL;
}

//多行搜索：在各行中往回搜索对象（不限于字符），不包括pCur
PCharNode CETextManager::FindPrevNode(
	IN PEObjLink pCur,
	OUT PARAGNODE ** ppPragNode/* = NULL*/,
	OUT LineNode **ppLineNode/* = NULL*/)
{
	if (ppPragNode) *ppPragNode = NULL;
	if (ppLineNode) *ppLineNode = NULL;
	BOOL bFoundCur = FALSE;
	PPARAGNODE pXParagNode;
	PLineNode pXLineNode;
	PCharNode pXCharNode;
	pXParagNode = m_parags.GetTailNode();
	while (pXParagNode)
	{
		pXLineNode = pXParagNode->pdata->lines.GetTailNode();
		while (pXLineNode)
		{
			pXCharNode = pXLineNode->pdata->clst.GetTailNode();
			while (pXCharNode)
			{
				if (pCur == pXCharNode->pdata)
				{
					if (!bFoundCur)
						bFoundCur = TRUE;
				}
				if (bFoundCur && pXCharNode->pdata != pCur)
				{
					if (ppPragNode) *ppPragNode = pXParagNode;
					if (ppLineNode) *ppLineNode = pXLineNode;
					return pXCharNode;
				}
				pXCharNode = pXCharNode->pPrev;
			}
			pXLineNode = pXLineNode->pPrev;
		}
		pXParagNode = pXParagNode->pPrev;
	}
	return NULL;
}

//多行搜索：在各行中往前搜索对象（不限于字符），不包括pCur
PCharNode CETextManager::FindNextNode(
	IN PEObjLink pCur,
	OUT PARAGNODE ** ppPragNode/* = NULL*/,
	OUT LineNode **ppLineNode/* = NULL*/)
{
	if (ppPragNode) *ppPragNode = NULL;
	if (ppLineNode) *ppLineNode = NULL;
	BOOL bFoundCur = FALSE;
	PPARAGNODE pXParagNode;
	PLineNode pXLineNode;
	PCharNode pXCharNode;
	pXParagNode = m_parags.GetHeadNode();
	while (pXParagNode)
	{
		pXLineNode = pXParagNode->pdata->lines.GetHeadNode();
		while (pXLineNode)
		{
			pXCharNode = pXLineNode->pdata->clst.GetHeadNode();
			while (pXCharNode)
			{
				if (pCur == pXCharNode->pdata)
				{
					if (!bFoundCur)
						bFoundCur = TRUE;
				}
				if (bFoundCur && pXCharNode->pdata != pCur)
				{
					if (ppPragNode) *ppPragNode = pXParagNode;
					if (ppLineNode) *ppLineNode = pXLineNode;
					return pXCharNode;
				}
				pXCharNode = pXCharNode->pNext;
			}
			pXLineNode = pXLineNode->pNext;
		}
		pXParagNode = pXParagNode->pNext;
	}
	return NULL;
}

BOOL CETextManager::CaretGoLeft(LPRECT pRectChanged/* = NULL*/)
{
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	//if (!m_buffer.CaretMovePrevNonZeroChar())
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pParagNode != NULL && pLineNode != NULL && pCaretNode != NULL);
	if (!m_buffer.CaretMovePrev())
		return FALSE;
	//此时光标应该映射到哪行？
	PEObjLink pTarget;
	pTarget = m_buffer.GetNextChar(pcaret->pNext);
	if (pTarget)
	{
		PLineNode pLineNode2 = NULL;
		PCharNode pCharNode2 = NULL;
		PPARAGNODE pParagNode2 = NULL;
		CETextLine *pLine2 = GetLine(pTarget, &pParagNode2, &pLineNode2, &pCharNode2);
		ASSERT(pLine2 != NULL && pParagNode2 != NULL && pLineNode2 != NULL && pCharNode2 != NULL);
		if (pLine2)
		{
			pLine->clst.RemoveAt(pCaretNode);
			pCaretNode = pLine2->clst.InsertBefore(pCharNode2, pcaret);
		}
	}
	else
	{
		pTarget = m_buffer.GetPrevChar(pcaret->pPrev);
		if (pTarget)
		{
			PLineNode pLineNode2 = NULL;
			PCharNode pCharNode2 = NULL;
			PPARAGNODE pParagNode2 = NULL;
			CETextLine *pLine2 = GetLine(pTarget, &pParagNode2, &pLineNode2, &pCharNode2);
			ASSERT(pLine2 != NULL && pParagNode2 != NULL && pLineNode2 != NULL && pCharNode2 != NULL);
			if (pLine2)
			{
				pLine->clst.RemoveAt(pCaretNode);
				pCaretNode = pLine2->clst.InsertAfter(pCharNode2, pcaret);
			}
		}
		else
		{
			ASSERT(0);
			//光标既然能往回移动一个字符，那么这里的情况是不可能存在的，不会执行到这里的。
			return FALSE;
		}
	}
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
	}
	//pLineFound->clst.InsertBefore(pNodeFound, pcaret);
	//注意：光标在 buffer 中的尺寸是0宽度
	//pcaret->o.x = pNodeFound->pdata->o.x;
	//pcaret->o.y = pNodeFound->pdata->o.y;
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(m_buffer.GetCaret());
	return TRUE;
}
BOOL CETextManager::IsLinefeedNode(PEObjLink pLink)
{
	if (pLink == NULL)
		return FALSE;
	return (islf(&pLink->o) ? TRUE : FALSE);
}
BOOL CETextManager::CaretGoRight(LPRECT pRectChanged/* = NULL*/)
{
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pParagNode != NULL && pLineNode != NULL && pCaretNode != NULL);
	if (!m_buffer.CaretMoveNext())
		return FALSE;
	if (pcaret->pPrev && pcaret->pNext == NULL)
	{
		if (islf(pcaret->pPrev))
		{
			//如果光标前是一个换行符，而且换行符后面没有任何内容的话，我们跳到一个空行上
			//CETextLine *pLine = GetLine(pcaret, NULL, NULL, NULL); 此时光标在行的映射位置还没有发生变化，所以不用这行
			CETextLine *pLineNext = GetNextLine(pLine);
			if (pLineNext == NULL)
				return FALSE;
			pLine->clst.RemoveAt(pCaretNode);
			pCaretNode = pLineNext->clst.AddHead(pcaret);
			//PCharNode pRefTo = NULL;
			//if (m_buffer.IsOverwriteMode())
			//{
			//	pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			//	if (pRefTo)
			//	{
			//		pcaret->o.x = pRefTo->pdata->o.x;
			//		pcaret->o.y = pRefTo->pdata->o.y;
			//		pcaret->o.cy = pRefTo->pdata->o.cy;
			//	}
			//}
			//if (pRefTo == NULL)
			//{
			//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			//	if (pRefTo)
			//	{
			//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
			//		pcaret->o.y = pRefTo->pdata->o.y;
			//		pcaret->o.cy = pRefTo->pdata->o.cy;
			//	}
			//}
			pcaret->o.x = pLineNext->x;
			pcaret->o.y = pLineNext->y;
			ASSERT(pCaretNode);
			//如果此时光标的右边没有字符，就切换光标为插入模式
			if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
			{
				if (!m_buffer.IsForceInsertMode())
					m_buffer.SetForceInsertMode(TRUE);
			}
			EnsureCaretVisible(pRectChanged);
			OnCaretMove(m_buffer.GetCaret());
			return TRUE;
		}
	}
	//此时光标应该映射到哪行？
	PEObjLink pTarget;
	pTarget = m_buffer.GetNextChar(pcaret->pNext);
	if (/*pcaret->pNext*/pTarget)
	{
		//PLineNode pLineNode2 = NULL;
		PCharNode pCharNode2 = NULL;
		//PPARAGNODE pParagNode2 = NULL;
		CETextLine *pLine2 = GetLine(/*pcaret->pNext*/pTarget, NULL/*&pParagNode2*/, NULL/*&pLineNode2*/, &pCharNode2);
		ASSERT(pLine2 != NULL/* && pParagNode2 != NULL && pLineNode2 != NULL*/ && pCharNode2 != NULL);
		if (pLine2)
		{
			pLine->clst.RemoveAt(pCaretNode);
			pCaretNode = pLine2->clst.InsertBefore(pCharNode2, pcaret);
		}
	}
	else
	{
		pTarget = m_buffer.GetPrevChar(pcaret->pPrev);
		if (/*pcaret->pPrev*/pTarget)
		{
			//PLineNode pLineNode2 = NULL;
			PCharNode pCharNode2 = NULL;
			//PPARAGNODE pParagNode2 = NULL;
			CETextLine *pLine2 = GetLine(pTarget/*pcaret->pPrev*/, NULL/*&pParagNode2*/, NULL/*&pLineNode2*/, &pCharNode2);
			ASSERT(pLine2 != NULL && /*pParagNode2 != NULL && pLineNode2 != NULL &&*/ pCharNode2 != NULL);
			if (pLine2)
			{
				pLine->clst.RemoveAt(pCaretNode);
				pCaretNode = pLine2->clst.InsertAfter(pCharNode2, pcaret);
			}
		}
		else
		{
			ASSERT(0);
			//光标既然能往回移动一个字符，那么这里的情况是不可能存在的，不会执行到这里的。
			return FALSE;
		}
	}
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
	}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(m_buffer.GetCaret());
	return TRUE;

}
BOOL CETextManager::CaretGoTopLeft(LPRECT pRectChanged/* = NULL*/)
{
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pParagNode != NULL && pLineNode != NULL && pCaretNode != NULL);
	PCharNode pHeadNode = pLine->clst.GetHeadNode();
	if (pHeadNode == pCaretNode)
		return FALSE;
	pHeadNode = LineFindNextNZNode(pHeadNode, L'\n');
	if (pHeadNode == pCaretNode)
		return FALSE;
	pLine->clst.RemoveAt(pCaretNode);
	//注意：光标在 buffer 中的尺寸是0宽度
	if (pHeadNode)
	{
		m_buffer.CaretMoveBefore(pHeadNode->pdata);
		pCaretNode = pLine->clst.InsertBefore(pHeadNode, pcaret);
		//注意：光标在 buffer 中的尺寸是0宽度
		pcaret->o.x = pHeadNode->pdata->o.x/* + pNodeFound->pdata->o.cx*/;
		pcaret->o.y = pHeadNode->pdata->o.y;
		pcaret->o.cy = pHeadNode->pdata->o.cy;
	}
	else
	{
		pHeadNode = pLine->clst.AddHead(pcaret);
		pCaretNode = pHeadNode;
		if (pHeadNode->pNext)
		{
			m_buffer.CaretMoveBefore(pHeadNode->pNext->pdata);
			pcaret->o.x = pHeadNode->pNext->pdata->o.x;
			pcaret->o.y = pHeadNode->pNext->pdata->o.y;
		}
		else
		{
			pcaret->o.x = pLine->x;
			pcaret->o.y = pLine->y;
		}
		//else if (pHeadNode->pPrev)
		//	m_buffer.CaretMoveAfter(pHeadNode->pNext->pdata);
	}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(pcaret);
	return TRUE;
}
BOOL CETextManager::CaretGoTopRight(LPRECT pRectChanged/* = NULL*/)
{
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
	PEObjLink pcaret = m_buffer.GetCaret();
	ASSERT(pcaret);
	PLineNode pLineNode = NULL;
	PCharNode pCaretNode = NULL;
	PPARAGNODE pParagNode = NULL;
	CETextLine *pLine = GetLine(pcaret, &pParagNode, &pLineNode, &pCaretNode);
	ASSERT(pLine != NULL && pParagNode != NULL && pLineNode != NULL && pCaretNode != NULL);
	PCharNode pTailNode = pLine->clst.GetTailNode();
	if (pTailNode == pCaretNode)
		return FALSE;
	pTailNode = LineFindPrevNZNode(pTailNode, L'\n');
	if (pTailNode == pCaretNode)
		return FALSE;
	pLine->clst.RemoveAt(pCaretNode);
	if (pTailNode)
	{
		if (IsLinefeedNode(pTailNode))
		{
			m_buffer.CaretMoveBefore(pTailNode->pdata);
			pCaretNode = pLine->clst.InsertBefore(pTailNode, pcaret);
			//注意：光标在 buffer 中的尺寸是0宽度
			//pcaret->o.x = pTailNode->pdata->o.x/* + pNodeFound->pdata->o.cx*/;
			//pcaret->o.y = pTailNode->pdata->o.y;
		}
		else
		{
			m_buffer.CaretMoveAfter(pTailNode->pdata);
			pCaretNode = pLine->clst.InsertAfter(pTailNode, pcaret);
			//注意：光标在 buffer 中的尺寸是0宽度
			//pcaret->o.x = pTailNode->pdata->o.x + pTailNode->pdata->o.cx;
			//pcaret->o.y = pTailNode->pdata->o.y;
		}
	}
	else
	{
		pTailNode = pLine->clst.AddTail(pcaret);	// AddHead(pcaret);
		pCaretNode = pTailNode;
		//if (pTailNode->pNext)
		//	m_buffer.CaretMoveBefore(pTailNode->pNext->pdata);
		//else 
		if (pTailNode->pPrev)
			m_buffer.CaretMoveAfter(pTailNode->pNext->pdata);
		pcaret->o.x = pLine->x;
		pcaret->o.y = pLine->y;
	}
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
	}
	//if (pRefTo == NULL)
	//{
	//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
	//	if (pRefTo)
	//	{
	//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
	//		pcaret->o.y = pRefTo->pdata->o.y;
	//		pcaret->o.cy = pRefTo->pdata->o.cy;
	//	}
	//}
	//pLine->clst.AddHead(pcaret);
	////注意：光标在 buffer 中的尺寸是0宽度
	//pcaret->o.x = pTailNode->pdata->o.x;
	//pcaret->o.y = pTailNode->pdata->o.y;
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged);
	OnCaretMove(pcaret);
	return TRUE;
}
//BOOL CETextManager::PageUp(LPRECT pRectChanged/* = NULL*/)
//{
//	return TRUE;
//}
//BOOL CETextManager::PageDown(LPRECT pRectChanged/* = NULL*/)
//{
//	return TRUE;
//}

void CETextManager::ScrollLine(
	IN CETextLine *pLine,
	IN LONG cxScroll,
	IN LONG cyScroll)
{
	if (pLine->x != LONG_MAX) pLine->x += cxScroll;
	if (pLine->y != LONG_MAX) pLine->y += cyScroll;
	PCharNode pNode = pLine->clst.GetHeadNode();
	while (pNode)
	{
		if (pNode->pdata->o.x != LONG_MAX) pNode->pdata->o.x += cxScroll;
		if (pNode->pdata->o.y != LONG_MAX) pNode->pdata->o.y += cyScroll;
		pNode = pNode->pNext;
	}//end while
}

void CETextManager::ScrollParagraph(
	IN CETextParagraph *pParag,
	IN LONG cxScroll,
	IN LONG cyScroll)
{
	if (pParag->x != LONG_MAX) pParag->x += cxScroll;
	if (pParag->y != LONG_MAX) pParag->y += cyScroll;
	PLineNode pNode = pParag->lines.GetHeadNode();
	while (pNode)
	{
		//pNode->pdata->scroll(cxScroll, cyScroll);
		ScrollLine(pNode->pdata, cxScroll, cyScroll);
		pNode = pNode->pNext;
	}//end while
}

int CETextManager::GetPageHeight(BOOL bUp)
{
	if (m_bSingleLine)
		return 0;
	int nPageLeng = m_rcText.Height() - m_baseLineHeight * 2;
	if (nPageLeng < 0)
		nPageLeng = m_rcText.Height() - 1;
	if (bUp)//up
	{
		CETextLine *pTop = GetTopLine();
		CRect rcLine(
			pTop->x,
			pTop->y,
			pTop->x + pTop->cx,
			pTop->y + pTop->cy);
		if (rcLine.top >= m_rcText.top)
			return 0;
		return min(m_rcText.top - rcLine.top, nPageLeng);
	}
	else //down
	{
		CETextLine *pBottom = GetBottomLine();
		CRect rcLine(
			pBottom->x,
			pBottom->y,
			pBottom->x + pBottom->cx,
			pBottom->y + pBottom->cy);
		if (rcLine.bottom <= m_rcText.bottom)
			return 0;
		return min(rcLine.bottom - m_rcText.bottom, nPageLeng);
	}
}

//for mouse wheel
int CETextManager::GetScrollStep(short zDelta)
{
	if (m_bSingleLine)
		return 0;
	int nPageLeng = m_rcText.Height();
	int nWheelStep = nPageLeng / 3;
	int nDelta = abs(zDelta);
	if (nDelta < nWheelStep)
		nWheelStep = nDelta;
	if (zDelta < 0)//up
	{
		CETextLine *pBottom = GetBottomLine();
		CRect rcLine(
			pBottom->x,
			pBottom->y,
			pBottom->x + pBottom->cx,
			pBottom->y + pBottom->cy);
		if (rcLine.bottom <= m_rcText.bottom)
			return 0;
		return min(rcLine.bottom - m_rcText.bottom, nWheelStep);
	}
	else //down
	{
		CETextLine *pTop = GetTopLine();
		CRect rcLine(
			pTop->x,
			pTop->y,
			pTop->x + pTop->cx,
			pTop->y + pTop->cy);
		if (rcLine.top >= m_rcText.top)
			return 0;
		return min(m_rcText.top - rcLine.top, nWheelStep);
	}
}

//行在屏幕位置上移动 负数向上向左滚动，正数向右向下滚动
void CETextManager::ScrollParagraphs(
	IN LONG cxScroll, 
	IN LONG cyScroll, 
	IN CETextParagraph *pStart/* = NULL*/,
	OUT LPRECT pRectChanged/* = NULL*/,
	IN OUT PARAGLIST *pLinesChanged/* = NULL*/)
{
	if (m_parags.GetCount() <= 0)
		return;
	CRect rc1,rc2;
	CRect rcUnion,rcInter;
	CRect rcRet(0, 0, 0, 0);
	CETextParagraph *pParag;
	PPARAGNODE pNode = m_parags.GetHeadNode();
	if (pStart)
	{
		pNode = m_parags.Find(pStart);
		ASSERT(pNode);
	}
	while (pNode)
	{
		pParag = pNode->pdata;
		if (pRectChanged)
		{
			rc1.SetRect(pParag->x, 
				pParag->y, 
				pParag->x + pParag->cx, 
				pParag->y + pParag->cy);
		}
		//pParag->scroll(cxScroll, cyScroll);
		ScrollParagraph(pParag, cxScroll, cyScroll);
		if (pLinesChanged)
		{
			if (pLinesChanged->Find(pParag) == NULL)
				pLinesChanged->AddTail(pParag);
		}
		if (pRectChanged)
		{
			rc2.SetRect(
				pParag->x,
				pParag->y,
				pParag->x + pParag->cx,
				pParag->y + pParag->cy);
			//组合
			if (rcUnion.UnionRect(&rc1, &rc2))
			{
				//交集
				if (rcInter.IntersectRect(&rcUnion, &m_rcText))
				{
					//组合
					if (!rcInter.IsRectEmpty())
					{
						if (rcRet.IsRectEmpty())
							rcRet = rcInter;
						else
							rcRet.UnionRect(&rcRet, &rcInter);
					}
				} //end if intersect
			}//end if union
		}//end if pRectChanged
		pNode = pNode->pNext;
	}//end while
	if (pRectChanged)
		*pRectChanged = rcRet;
}

//整理新行，重新计算它的宽度高度和确定字符的位置
//某种意义上说，这样的一行其实是一段的概念，如果自动换行的话
void CETextManager::ArrangeParagraph(CETextParagraph *pPrag, BOOL *pChanged)
{
	if (pChanged)
		*pChanged = FALSE;
	LONG x = pPrag->x;
	LONG y = pPrag->y;
	LONG xOld = pPrag->x;
	LONG yOld = pPrag->y;
	LONG cxOld = pPrag->cx;
	LONG cyOld = pPrag->cy;;
	LONG cx = 0, cy = 0;
	CETextRange *pRange;
	CharList lst(FALSE);
	PLineNode pNode = pPrag->lines.GetHeadNode();
	while (pNode)
	{
		lst.AddTail(&pNode->pdata->clst);
		pNode = pNode->pNext;
	}
	pPrag->lines.RemoveAll();
	CETextLine *pSubLine = new CETextLine(pPrag);
	if (pSubLine == NULL)
		return;
	pPrag->lines.AddTail(pSubLine);
	pSubLine->x = x;
	pSubLine->y = y;
	pSubLine->cx = 0;
	pSubLine->cy = 0;
	LONG tmpCx, tmpCy, charX;
	//第一次扫描，整理出所有的子行和确定位置行高
	PCharNode pCharNode = lst.GetHeadNode();
	while (pCharNode)
	{
		pRange = GetTextRange(pCharNode->pdata);
		tmpCy = max(cy, pCharNode->pdata->o.cy);
		tmpCx = cx;
		charX = pSubLine->x + cx;
		if (pCharNode->pdata->o.cx)
		{
			if (tmpCx)
			{
				tmpCx += pRange->m_charSpace;
				charX += pRange->m_charSpace;
			}
		}
		tmpCx += pCharNode->pdata->o.cx;
		if (tmpCx <= m_rcText.Width() ||
			m_bSingleLine || 
			(!m_bSingleLine && !m_bAutoWrapLines))
		{
			cx = tmpCx;
			cy = tmpCy;
			//pCharNode->pdata->o.x = charX;
			//pCharNode->pdata->o.y = pSubLine->y;
			pSubLine->clst.AddTail(pCharNode->pdata);
		}
		else
		{
			//要加入到新行中，所以先保存当前行数据。
			pSubLine->cx = cx;
			pSubLine->cy = cy + m_lineSpace;

			//纵向坐标下移一行
			y += pSubLine->cy;

			//建立新行
			pSubLine = new CETextLine(pPrag);
			if (pSubLine == NULL)
				break;
			pPrag->lines.AddTail(pSubLine);
			pSubLine->x = x;
			pSubLine->y = y;
			pSubLine->cx = 0;
			pSubLine->cy = 0;

			//pCharNode->pdata->o.x = pSubLine->x;
			//pCharNode->pdata->o.y = pSubLine->y;
			pSubLine->clst.AddTail(pCharNode->pdata);

			cx = pCharNode->pdata->o.cx;
			cy = pCharNode->pdata->o.cy;
		}//end if cx > rcText Width
		pCharNode = pCharNode->pNext;
	}
	if (cx || cy)
	{
		pSubLine->cx = cx;
		pSubLine->cy = cy + m_lineSpace;
	}
	//至此，所有子行都已经建立，行中的基本位置和尺寸都基本确立
	//下面对每个子行，根据设置，重新执行字符对齐操作
	CRect rcObj;	//字符空间
	CRect rcFullLine(0, 0, 0, 0);	//段空间 
	CRect rcLine;	//不含 m_lineSpace 的行空间，是最大行空间，不是紧凑的。
	CRect rcLine2;	//含 m_lineSpace 的行空间，是最大行空间，不是紧凑的。
	CRect rcObjSpace;	//不含 m_lineSpace 的最紧凑的行空间。
	rcObj.SetRectEmpty();
	PLineNode pSubLineNode = pPrag->lines.GetHeadNode();
	while (pSubLineNode)
	{
		rcLine.SetRect(
			pSubLineNode->pdata->x,
			pSubLineNode->pdata->y, 
			max(m_rcText.right, pSubLineNode->pdata->x + pSubLineNode->pdata->cx),
			pSubLineNode->pdata->y + pSubLineNode->pdata->cy - m_lineSpace);
		rcLine2.SetRect(
			pSubLineNode->pdata->x,
			pSubLineNode->pdata->y,
			max(m_rcText.right, pSubLineNode->pdata->x + pSubLineNode->pdata->cx),
			pSubLineNode->pdata->y + pSubLineNode->pdata->cy/* - m_lineSpace*/);
		if (rcFullLine.IsRectEmpty())
			rcFullLine = rcLine2;
		else
			rcFullLine.UnionRect(&rcFullLine, &rcLine2);
		rcObjSpace.SetRect(
			pSubLineNode->pdata->x,
			pSubLineNode->pdata->y,
			pSubLineNode->pdata->x + pSubLineNode->pdata->cx,
			pSubLineNode->pdata->y + pSubLineNode->pdata->cy - m_lineSpace);
		//先对齐紧凑的行空间
		if (pPrag->vA == EOBJ_ALIGN_VBOTTOM)
			rcObjSpace.OffsetRect(0, rcLine.bottom - rcObjSpace.bottom);
		else if (pPrag->vA == EOBJ_ALIGN_VTOP)
			rcObjSpace.OffsetRect(0, rcLine.top - rcObjSpace.top);
		else if (pPrag->vA == EOBJ_ALIGN_VMIDDLE)
			rcObjSpace.OffsetRect(0, rcLine.CenterPoint().y - rcObjSpace.CenterPoint().y);
		if (pPrag->hA == EOBJ_ALIGN_LEFT)
			rcObjSpace.OffsetRect(rcLine.left - rcObjSpace.left, 0);
		else if (pPrag->hA == EOBJ_ALIGN_RIGHT)
			rcObjSpace.OffsetRect(rcLine.right - rcObjSpace.right, 0);
		else if (pPrag->hA == EOBJ_ALIGN_CENTER)
			rcObjSpace.OffsetRect(rcLine.CenterPoint().x - rcObjSpace.CenterPoint().x, 0);

		rcObj.OffsetRect(rcObjSpace.TopLeft() - rcObj.TopLeft());

		cx = 0;
		//再对齐每个对象
		pCharNode = pSubLineNode->pdata->clst.GetHeadNode();
		while (pCharNode)
		{
//#ifdef _DEBUG
//			if (iscaret(pCharNode->pdata))
//			{
//				TRACE(L"Arrange paragraph 0x%08x found caret 1 position %d,%d\n",
//					pPrag,
//					pCharNode->pdata->o.x,
//					pCharNode->pdata->o.y);
//			}
//#endif
			pRange = GetTextRange(pCharNode->pdata);
			ASSERT(pRange);

			rcObj.right = rcObj.left + pCharNode->pdata->o.cx;
			rcObj.bottom = rcObj.top + pCharNode->pdata->o.cy;

			//注意下面：我们的原则是0宽度对象的右边不添加空位
			if (pCharNode->pdata->o.cx)
			{
				if (cx)
					cx += pRange->m_charSpace;
			}
			rcObj.OffsetRect(rcObjSpace.left + cx - rcObj.left, 0);

			//注意下面：因为 textrange 的纵向对齐方式优先于行设定，所以它的目标是rcLine，而不是rcObjSpace
			if (pRange->m_vAlign == EOBJ_ALIGN_VBOTTOM)
				rcObj.OffsetRect(0, rcLine.bottom - rcObj.bottom);
			else if (pRange->m_vAlign == EOBJ_ALIGN_VTOP)
				rcObj.OffsetRect(0, rcLine.top - rcObj.top);
			else if (pRange->m_vAlign == EOBJ_ALIGN_VMIDDLE)
				rcObj.OffsetRect(0, rcLine.CenterPoint().y - rcObj.CenterPoint().y);
			else
				ASSERT(0);
			
			//确定并保存位置
			if (pCharNode->pdata->o.x != rcObj.left)
			{
				pCharNode->pdata->o.x = rcObj.left;
				if (pChanged)
				{
					if (!*pChanged)
						*pChanged = TRUE;
				}
			}
			if (pCharNode->pdata->o.y != rcObj.top)
			{
				pCharNode->pdata->o.y = rcObj.top;
				if (pChanged)
				{
					if (!*pChanged)
						*pChanged = TRUE;
				}
			}
//#ifdef _DEBUG
//			if (iscaret(pCharNode->pdata))
//			{
//				TRACE(L"Arrange paragraph 0x%08x found caret 2 position %d,%d\n",
//					pPrag, 
//					pCharNode->pdata->o.x, 
//					pCharNode->pdata->o.y);
//			}
//#endif
			cx += pCharNode->pdata->o.cx;

			pCharNode = pCharNode->pNext;
		}//end while posChar
		pSubLineNode = pSubLineNode->pNext;
	}
	if (pChanged)
	{
		if (!*pChanged)
		{
			if (cxOld != rcFullLine.Width() ||
				cyOld != rcFullLine.Height() ||
				xOld != rcFullLine.left ||
				yOld != rcFullLine.top)
				*pChanged = TRUE;
		}
	}
	pPrag->x = rcFullLine.left;
	pPrag->y = rcFullLine.top;
	pPrag->cx = rcFullLine.Width();
	pPrag->cy = rcFullLine.Height();
}

void CETextManager::GetLineText(CETextParagraph *pPrag, CStringW& sText, INT_PTR& len)
{
	sText.Empty();
	len = 0;
	CStringW s;
	INT_PTR l;
	PLineNode pNode = pPrag->lines.GetHeadNode();
	while (pNode)
	{
		GetLineText(pNode->pdata, s, l);
		sText += s;
		len += l;
		pNode = pNode->pNext;
	}
}
void CETextManager::GetLineText(CETextLine *pLine, CStringW& sText, INT_PTR& len)
{
	sText.Empty();
	len = 0;
	PCharNode pNode = pLine->clst.GetHeadNode();
	while (pNode)
	{
		if (pNode->pdata->o.type == ETYPE_TEXT)
		{
			//PETextCell pText = static_cast<PETextCell>(pNode->pdata->po);
			switch (/*pText->*/pNode->pdata->o.c)
			{
			case L'\t':
				sText += L"<TAB>";
				break;
			case L'\r':
				sText += L"<CR>";
				break;
			case L'\n':
				sText += L"<LF>";
				break;
			default:
				sText += pNode->pdata->o.c; // pText->o;
			}
		}
		else
		{
			CStringW sObj;
			sObj.Format(L"<obj type=0x%08x>", pNode->pdata->o.type);
			sText += sObj;
		}
		len++;
		pNode = pNode->pNext;
	}
}

BOOL CETextManager::InsertBitmap(IN HBITMAP hBmp, OUT LPRECT pRectChanged/* = NULL*/)
{
	BITMAP bmp = { 0 };
	CBitmap bmpx;
	bmpx.Attach(hBmp);
	bmpx.GetBitmap(&bmp);
	bmpx.Detach();
	CETextRange *pRange = GetTextRange(m_buffer.GetCaret());
	ASSERT(pRange != NULL);
	if (pRange == NULL)
		return FALSE;
	PARAGLIST paragChg(FALSE);
	if (pRectChanged)
		::SetRectEmpty(pRectChanged);
	PEObjLink pInserted;
	CETextParagraph *pCurParag = NULL;
	PEObjLink pcaret;
	PLineNode pCurLineNode;
	PCharNode pCaretNode;
	PCharNode pBitmapNode;
	PPARAGNODE pParagNode;
	CETextLine *pCurLine = NULL;
	CETextParagraph *pParagNew = NULL;
	CETextLine *pLineNew = NULL;
	CharList inserted(FALSE);
	pInserted = m_buffer.Insert(hBmp, bmp.bmWidth, bmp.bmHeight);
	if (pInserted == NULL)
		return FALSE;
	pRange->m_links.AddTail(pInserted);
	inserted.AddTail(pInserted);
	//获取光标所在行
	pcaret = m_buffer.GetCaret();
	pCurLineNode = NULL;
	pCaretNode = NULL;
	pParagNode = NULL;
	pCurLine = GetLine(pcaret, &pParagNode, &pCurLineNode, &pCaretNode);
	//光标行总是存在的
	ASSERT(pCurLine && pParagNode && pCurLineNode && pCaretNode);
	ASSERT(pInserted->pNext == pcaret);
	pCurParag = pParagNode->pdata;
	//在光标前面插入字符到行
	pBitmapNode = pCurLine->clst.InsertBefore(pCaretNode, pInserted);
	if (paragChg.Find(pCurParag) == NULL)
		paragChg.AddTail(pCurParag);
	CRect rcOld(
		pParagNode->pdata->x,
		pParagNode->pdata->y,
		pParagNode->pdata->x + pParagNode->pdata->cx,
		pParagNode->pdata->y + pParagNode->pdata->cy);
	ArrangeParagraph(pParagNode->pdata, NULL);
	CRect rcNew(
		pParagNode->pdata->x,
		pParagNode->pdata->y,
		pParagNode->pdata->x + pParagNode->pdata->cx,
		pParagNode->pdata->y + pParagNode->pdata->cy);
	//如果高度发生改变的话，本段之后的所有段的位置也意味着发生了变化
	if (rcNew.Height() != rcOld.Height())
	{
		PPARAGNODE pNode = pParagNode;
		while (pNode)
		{
			if (paragChg.Find(pNode->pdata) == NULL)
				paragChg.AddTail(pNode->pdata);
			pNode = pNode->pNext;
		}
	}
	if (inserted.GetCount())
	{
		if (m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(FALSE);
		CalcParagraphs(&inserted, &paragChg);
		pCurLine = GetLine(pcaret, &pParagNode, &pCurLineNode, &pCaretNode);
		//光标行总是存在的
		ASSERT(pCurLine && pParagNode && pCurLineNode && pCaretNode);
		//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
		PCharNode pRefTo = NULL;
		if (m_buffer.IsOverwriteMode())
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			if (pCaretNode->pPrev == NULL)
			{
				pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
			if (pRefTo == NULL)
			{
				pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
		}
		//if (pRefTo == NULL)
		//{
		//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
		//	if (pRefTo)
		//	{
		//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
		//		pcaret->o.y = pRefTo->pdata->o.y;
		//		pcaret->o.cy = pRefTo->pdata->o.cy;
		//	}
		//}
		//ASSERT(pCaretNode);
		//如果此时光标的右边没有字符，就切换光标为插入模式
		if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
		{
			if (!m_buffer.IsForceInsertMode())
				m_buffer.SetForceInsertMode(TRUE);
		}
		OnCaretMove(m_buffer.GetCaret());
	}
	CRect rcRet(0, 0, 0, 0);
	EnsureCaretVisible(NULL, &paragChg);
	//OnCaretMove(m_buffer.GetCaret());
	if (paragChg.GetCount())
	{
		CRect rcLine, rcV;
		PPARAGNODE pParagNode = paragChg.GetHeadNode();
		while (pParagNode)
		{
			rcLine.SetRect(pParagNode->pdata->x,
				pParagNode->pdata->y,
				m_rcText.right,
				pParagNode->pdata->y + pParagNode->pdata->cy);
			if (rcV.IntersectRect(&m_rcText, &rcLine))
			{
				if (!rcV.IsRectEmpty())
				{
					if (rcRet.IsRectEmpty())
						rcRet = rcV;
					else
						rcRet.UnionRect(&rcV, &rcRet);
				}
			}
			pParagNode = pParagNode->pNext;
		}
	}
	if (pRectChanged)
		*pRectChanged = rcRet;
	return TRUE;
}

//在当前光标位置插入文字
LONG CETextManager::InsertText(
	IN LPCWSTR wszText,
	IN CDC *pDC,
	OUT LPRECT pRectChanged/* = NULL*/)
{
	CharList inserted(FALSE);
	LONG count = 0;
	CETextRange *pRange = GetTextRange(m_buffer.GetCaret());
	ASSERT(pRange != NULL);
	if (pRange == NULL)
		return 0;
	CSize size;
	WCHAR wszX[2];
	wszX[1] = 0;
	PARAGLIST paragChg(FALSE);
	if (pRectChanged)
	{
		::SetRectEmpty(pRectChanged);
	}
	CFont font;
	if (!font.CreateFontIndirectW(&pRange->m_font))
		return 0;
	CFont *pFont = pDC->SelectObject(&font);
	PEObjLink pInserted;
	CStringW sText = wszText;
	if (sText.Find(L"\r\n") >= 0)
	{
		sText.Replace(L"\r\n", L"\n");
		sText.Replace(L"\r", L"\n");
	}
	CETextParagraph *pCurParag = NULL;
	PEObjLink pcaret;
	PLineNode pCurLineNode;
	PCharNode pCaretNode;
	PPARAGNODE pParagNode;
	//PPARAGNODE pParagNodeX;
	//PLineNode pLineNodeX;
	//PLineNode pLineNodeNew;
	//PCharNode pCharNodeX;
	//PCharNode pNodeInserted;
	CETextLine *pCurLine = NULL;
	CETextParagraph *pParagNew = NULL;
	CETextLine *pLineNew = NULL;
	BOOL bSkip;
	//LONG cx, cx2;
	//CETextRange *pRangeX;
	SIZE bound = { 0 };
	int nLenOrFixed = sText.GetLength();
	const int bufBytes = sizeof(int)*nLenOrFixed;
	int *pa = NULL;
	BOOL bPassed = FALSE;
	do
	{
		pa = (int *)malloc(bufBytes);
		memset(pa, 0, bufBytes);
		if (pa == NULL)
			break;
		if (!GetTextExtentExPointW(
			pDC->GetSafeHdc(),
			(LPCWSTR)sText,
			sText.GetLength(),
			0/*m_rcText.Width()*/,
			NULL/*&nLenOrFixed*/,
			pa,
			&bound))
			break;
		bPassed = TRUE;
	} while (0);
	if (!bPassed)
	{
		if (pa) free(pa);
		pDC->SelectObject(pFont);
		return 0;
	}
	int nDistance = 0;
	int nCharIndex = 0;
	LPCWSTR p = (LPCWSTR)sText;
	while (*p)
	{
		wszX[0] = *p; p++;
		//size = pDC->GetTextExtent(wszX, 1);
		size.cy = bound.cy;
		size.cx = pa[nCharIndex] - nDistance;
		nDistance = pa[nCharIndex];
		nCharIndex++;
		bSkip = FALSE;
		switch (wszX[0])
		{
		case L'\r':
		case L'\n':
			if (wszX[0] != L'\n')
				wszX[0] = L'\n';
			size.cx = 0;
			if (m_bSingleLine)
				bSkip = TRUE;
			break;
		case L'\t':
			size.cx = m_tabWidth;
			break;
		default:
			//if (!iswprint(*p))
			//	size.cx = 0;
			break;
		}
		if (bSkip)
		{
			//p++;
			continue;
		}
		pInserted = m_buffer.Insert(wszX[0], size.cx, size.cy);
		if (pInserted == NULL)
			break;
		pRange->m_links.AddTail(pInserted);
		inserted.AddTail(pInserted);
		//获取光标所在行
		pcaret = m_buffer.GetCaret();
		pCurLineNode = NULL;
		pCaretNode = NULL;
		pParagNode = NULL;
		pCurLine = GetLine(pcaret, &pParagNode, &pCurLineNode, &pCaretNode);
		//光标行总是存在的
		ASSERT(pCurLine && pParagNode && pCurLineNode && pCaretNode);
		ASSERT(pInserted->pNext == pcaret);
		pCurParag = pParagNode->pdata;
		//在光标前面插入字符到行
		pCurLine->clst.InsertBefore(pCaretNode, pInserted);
		if (paragChg.Find(pCurParag) == NULL)
			paragChg.AddTail(pCurParag);
		count++;
		//如果是换行符号，我们加入一个新行
		if (wszX[0] == L'\n' && !m_bSingleLine)
		{
			pParagNew = new CETextParagraph();
			if (pParagNew)
			{
				pParagNew->x = pCurParag->x;
				pParagNew->y = pCurParag->y + pCurParag->cy;
				PPARAGNODE pCurPragNode = m_parags.Find(pCurParag);
				ASSERT(pCurPragNode);
				pLineNew = new CETextLine(pParagNew);
				if (pLineNew)
				{
					paragChg.AddTail(pParagNew);
					PPARAGNODE pNewPragNode = m_parags.InsertAfter(pCurPragNode, pParagNew);
					PLineNode pNewLineNode = pParagNew->lines.AddTail(pLineNew);
					//pPragNew->lines.InsertAfter(pCurLineNode, pLineNew);
					pLineNew->x = pParagNew->x;
					pLineNew->y = pParagNew->y;
					//然后吧光标和它后面的所有(行)内容都移动到新行的开始位置
					pCurLine->clst.MoveTo(pCaretNode, -1, &pLineNew->clst, NULL);
					if (pCurLineNode->pNext)
					{
						PLineNode pNode = pCurLineNode->pNext;
						PLineNode pNodeNext;
						while (pNode)
						{
							pNodeNext = pNode->pNext;
							pLineNew->clst.AddTail(&pNode->pdata->clst);
							pCurParag->lines.RemoveAt(pNode);	//删除空行
							pNode = pNodeNext;
						}
					}
					//pCurLine->clst.MoveTo(pCaretNode, -1, &pLineNew->m_links, NULL);
					//pLineNew->m_cx = 0;
					//pLineNew->m_cy = max(pcaret->o.cy, m_baseLineHeight);
					//整理新行，重新计算它的宽度高度和确定字符的位置
					ArrangeParagraph(pParagNew, NULL);
					//新段后面的所有段向下挪动
					if (pNewPragNode->pNext)
					{
						ScrollParagraphs(0,
							pParagNew->cy,
							pNewPragNode->pNext->pdata,
							NULL,
							&paragChg);
					}
				}
				else
				{
					delete pParagNew;
				}//end if pPragNew=NULL
			}
			else
			{

			}//end if pPragNew==NULL
		}//end if \n
		else
		{
			CRect rcOld(
				pParagNode->pdata->x,
				pParagNode->pdata->y,
				pParagNode->pdata->x + pParagNode->pdata->cx,
				pParagNode->pdata->y + pParagNode->pdata->cy);
			ArrangeParagraph(pParagNode->pdata, NULL);
#ifdef _DEBUG
			ASSERT(CountCaret() == 1);
#endif
			CRect rcNew(
				pParagNode->pdata->x,
				pParagNode->pdata->y,
				pParagNode->pdata->x + pParagNode->pdata->cx,
				pParagNode->pdata->y + pParagNode->pdata->cy);
			//如果高度发生改变的话，本段之后的所有段的位置也意味着发生了变化
			if (rcNew.Height() != rcOld.Height())
			{
				PPARAGNODE pNode = pParagNode;
				while (pNode)
				{
					if (paragChg.Find(pNode->pdata) == NULL)
						paragChg.AddTail(pNode->pdata);
					pNode = pNode->pNext;
				}
			}
		}//wnd if not line feed
		//p++;
	}//end while
	if (pa) free(pa);
	pDC->SelectObject(pFont);

	if (inserted.GetCount())
	{
		if (m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(FALSE);
		CalcParagraphs(&inserted, &paragChg);
		pCurLine = GetLine(pcaret, &pParagNode, &pCurLineNode, &pCaretNode);
		//光标行总是存在的
		ASSERT(pCurLine && pParagNode && pCurLineNode && pCaretNode);
		//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
		PCharNode pRefTo = NULL;
		if (m_buffer.IsOverwriteMode())
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			if (pCaretNode->pPrev == NULL)
			{
				pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
			if (pRefTo == NULL)
			{
				pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
				if (pRefTo)
				{
					pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
					pcaret->o.y = pRefTo->pdata->o.y;
					pcaret->o.cy = pRefTo->pdata->o.cy;
				}
			}
		}
		//if (pRefTo == NULL)
		//{
		//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
		//	if (pRefTo)
		//	{
		//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
		//		pcaret->o.y = pRefTo->pdata->o.y;
		//		pcaret->o.cy = pRefTo->pdata->o.cy;
		//	}
		//}
		//ASSERT(pCaretNode);
		//如果此时光标的右边没有字符，就切换光标为插入模式
		if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
		{
			if (!m_buffer.IsForceInsertMode())
				m_buffer.SetForceInsertMode(TRUE);
		}
		OnCaretMove(m_buffer.GetCaret());
	}
	CRect rcRet(0, 0, 0, 0);
	EnsureCaretVisible(NULL, &paragChg);
	//OnCaretMove(m_buffer.GetCaret());
	if (paragChg.GetCount())
	{
		CRect rcLine, rcV;
		PPARAGNODE pParagNode = paragChg.GetHeadNode();
		while (pParagNode)
		{
			rcLine.SetRect(pParagNode->pdata->x,
				pParagNode->pdata->y,
				m_rcText.right,
				pParagNode->pdata->y + pParagNode->pdata->cy);
			if (rcV.IntersectRect(&m_rcText, &rcLine))
			{
				if (!rcV.IsRectEmpty())
				{
					if (rcRet.IsRectEmpty())
						rcRet = rcV;
					else
						rcRet.UnionRect(&rcV, &rcRet);
				}
			}
			pParagNode = pParagNode->pNext;
		}
	}
	if (pRectChanged)
		*pRectChanged = rcRet;
	return count;
}

//if pList not NULL, 传递一个刚插入的字符串列表。返回曾发生变动的行数。
//if pLinesChanged not NULL, 会返回所有发生变动的行。程序内部不要清理pLinesChanged
INT_PTR CETextManager::CalcParagraphs(
	IN CharList *pList/* = NULL*/,
	IN OUT PARAGLIST *pLinesChanged/* = NULL*/)
{
	if (m_buffer.m_linkCount == 0)
		return 0;
	LONG x, y;
//	PLineNode pLineNode;
	//PCharNode pCharNode;
	PPARAGNODE pParagNode;
	CETextParagraph *pParag;
	CETextParagraph *pParagStart = NULL;
	if (pList)
	{
		pParag = GetParagraph(pList->GetHead(), &pParagNode, NULL, NULL/*&pCharNode*/);
		ASSERT(pParag != NULL && pParagNode != NULL /*&& pCharNode != NULL*/);
		pParagStart = pParag;
		ASSERT(pParagStart != NULL);
	}
	else //if pList==NULL
	{
		pParagNode = m_parags.GetHeadNode();
		ASSERT(pParagNode);
		pParagStart = pParagNode->pdata;
	}//end if pList
	//下面开始整理各行，从 pParagStart 开始
	if (pParagStart == NULL || m_bSingleLine || pParagNode == NULL)
		return 0;
	x = LONG_MAX;
	y = LONG_MAX;
	INT_PTR nLineCount = 0;
	BOOL bChanged;
	while (pParagNode)
	{
		pParag = pParagNode->pdata;
		if (x == LONG_MAX)
		{
			if (pParag->x != LONG_MAX)
				x = pParag->x;
		}
		if (y == LONG_MAX)
		{
			if (pParag->y != LONG_MAX)
				y = pParag->y;
		}
		if (x == LONG_MAX)
			x = m_rcText.left;
		if (y == LONG_MAX)
			y = m_rcText.top;
		pParag->x = x;
		pParag->y = y;
		bChanged = FALSE;
		ArrangeParagraph(pParag, &bChanged);
		if (bChanged)
		{
			nLineCount++;
			if (pLinesChanged)
			{
				if (pLinesChanged->Find(pParag) == NULL)
					pLinesChanged->AddTail(pParag);

			}
		}
		y = pParag->y + pParag->cy;

		pParagNode = pParagNode->pNext;
	}//end while posLine
	return nLineCount/*(LONG)changes.GetCount()*/;
}

//鼠标点击了，开始移动光标，成功则返回TRUE
#if TEST_CARET_CLICK
BOOL CETextManager::CaretClick(POINT ptNew, CDC *pDC, LPRECT pRectChanged/* = NULL*/)
#else
BOOL CETextManager::CaretClick(POINT ptNew, LPRECT pRectChanged/* = NULL*/)
#endif
{
	if(!m_rcText.PtInRect(ptNew))
		return FALSE;
	if (m_buffer.IsForceInsertMode())
		m_buffer.SetForceInsertMode(FALSE);
#if TEST_CARET_CLICK
	DrawFocus(pDC, ptNew, 0xff0000, 1);
#endif
	CRect rcLine, rcText, rcObj, rcL, rcR;
	int nPos = 0;
	CETextRange *pRange;
	PCharNode pLinkNode;
	PLineNode pLineNode;
	PCharNode pNodeFound = NULL;
	PLineNode pLineFound = NULL;
	BOOL bFound = FALSE;
	PPARAGNODE pParagNode = m_parags.GetHeadNode();
	while (pParagNode && !bFound)
	{
		pLineNode = pParagNode->pdata->lines.GetHeadNode();
		while (pLineNode && !bFound)
		{
			rcText.SetRect(
				pLineNode->pdata->x,
				pLineNode->pdata->y,
				pLineNode->pdata->x + pLineNode->pdata->cx,
				pLineNode->pdata->y + pLineNode->pdata->cy - m_lineSpace);
			rcLine.SetRect(
				/*pLineNode->pdata->x*/m_rcText.left,
				pLineNode->pdata->y,
				max(pLineNode->pdata->x + pLineNode->pdata->cx, m_rcText.right),
				pLineNode->pdata->y + pLineNode->pdata->cy/* - m_lineSpace*/);
			if (rcLine.PtInRect(ptNew))
			{
#if TEST_CARET_CLICK
				DrawRectangle(pDC, &rcLine, 0xff00, 1);
#endif
				pLinkNode = pLineNode->pdata->clst.GetHeadNode();
				while (pLinkNode && !bFound)
				{
					if (pLinkNode->pdata->o.cx)
					{
						rcObj.SetRect(
							pLinkNode->pdata->o.x,
							pLinkNode->pdata->o.y,
							pLinkNode->pdata->o.x + pLinkNode->pdata->o.cx,
							pLinkNode->pdata->o.y + pLinkNode->pdata->o.cy
							);
						if (rcObj.top != rcLine.top)
							rcObj.top = rcLine.top;
						if (rcObj.bottom != rcLine.bottom - m_lineSpace)
							rcObj.bottom = rcLine.bottom - m_lineSpace;
						if (rcObj.PtInRect(ptNew))
						{
							pLineFound = pLineNode;
							pNodeFound = pLinkNode;
							bFound = TRUE;
							rcL = rcR = rcObj;
							rcL.right = rcL.left + rcObj.Width() / 2;
							rcR.left = rcL.right;
							nPos = 0;
							if (rcL.PtInRect(ptNew))
								nPos = -1;
							else if (rcR.PtInRect(ptNew))
								nPos = 1;
#if TEST_CARET_CLICK
							DrawRectangle(pDC, &rcObj, 0xff, 1);
#endif
							break;
						}
						else
						{
							pRange = GetTextRange(pLinkNode->pdata);
							rcL = rcR = rcObj;
							rcL.OffsetRect(-pRange->m_charSpace, 0);
							//space + 1/5 char cx
							rcL.right = rcL.left + pRange->m_charSpace + LONG((double)rcObj.Width()/5.0f);
							rcR.OffsetRect(rcObj.Width() - LONG((double)rcObj.Width() / 5.0f), 0);
							//1/5 char cx + space
							rcR.right = rcR.left + pRange->m_charSpace;
							if (rcL.PtInRect(ptNew))
							{
								pNodeFound = pLinkNode;
								pLineFound = pLineNode;
								bFound = TRUE;
								nPos = -1;
#if TEST_CARET_CLICK
								DrawRectangle(pDC, &rcL, 0xff, 1);
#endif
								break;
							}
							else if (rcR.PtInRect(ptNew))
							{
								pNodeFound = pLinkNode;
								pLineFound = pLineNode;
								bFound = TRUE;
								nPos = 1;
#if TEST_CARET_CLICK
								DrawRectangle(pDC, &rcR, 0xff, 1);
#endif
								break;
							}
						}//end if not in rect
					}//end if cx>0
					pLinkNode = pLinkNode->pNext;
				}//end while pLinkNode
				if (pNodeFound == NULL && !bFound)
				{
					//在文本行的右边点击，则移到右边
					if (ptNew.x >= rcText.right)
					{
						pNodeFound = LineFindPrevNZNode(
							pLineNode->pdata->clst.GetTailNode(), L'\n');
						if (pNodeFound == NULL)
						{
							pNodeFound = pLineNode->pdata->clst.GetTailNode();
						}
						bFound = TRUE;
						pLineFound = pLineNode;
						//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
						nPos = 1;
#if TEST_CARET_CLICK
						DrawRectangle(pDC, &rcR, 0xff, 1);
#endif
						break;
					}
					else if (ptNew.x <= rcText.left)
					{
						pNodeFound = LineFindNextNZNode(pLineNode->pdata->clst.GetHeadNode(),L'\n');
						if (pNodeFound == NULL)
						{
							pNodeFound = pLineNode->pdata->clst.GetHeadNode();
						}
						bFound = TRUE;
						pLineFound = pLineNode;
						//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
						nPos = -1;
#if TEST_CARET_CLICK
						DrawRectangle(pDC, &rcL, 0xff, 1);
#endif
						break;
					}
					else
					{
						//检测鼠标出现在行的左边还是右边，如果是左边，就让光标出现在最左边，右边就出现在最右边
						rcL = rcR = rcLine;
						rcL.right = rcLine.left + rcLine.Width() / 2;
						rcR.left = rcL.right;
						if (rcL.PtInRect(ptNew))
						{
							pNodeFound = LineFindNextNZNode(
								pLineNode->pdata->clst.GetHeadNode(),
								L'\n');
							if (pNodeFound == NULL)
							{
								pNodeFound = pLineNode->pdata->clst.GetHeadNode();
							}
							bFound = TRUE;
							pLineFound = pLineNode;
							//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
							nPos = -1;
#if TEST_CARET_CLICK
							DrawRectangle(pDC, &rcL, 0xff, 1);
#endif
							break;
						}
						else if (rcR.PtInRect(ptNew))
						{
							pNodeFound = LineFindPrevNZNode(
								pLineNode->pdata->clst.GetTailNode(),
								L'\n');
							if (pNodeFound == NULL)
							{
								pNodeFound = pLineNode->pdata->clst.GetTailNode();
							}
							bFound = TRUE;
							pLineFound = pLineNode;
							//请注意：此时的 pNodeFound 可能是 NULL，表示行是空的
							nPos = 1;
#if TEST_CARET_CLICK
							DrawRectangle(pDC, &rcR, 0xff, 1);
#endif
							break;
						}
					}
				}//end if pNodeFound==NULL
			}//end if ptinrect
			pLineNode = pLineNode->pNext;
		}//end while pLineNode
		pParagNode = pParagNode->pNext;
	}//end while pParagNode
	if (!bFound)
		return FALSE;
	ASSERT(pLineFound);
	if (pLineFound == NULL)
		return FALSE;
	PEObjLink pcaret = m_buffer.GetCaret();
	PCharNode pCaretNode;
	CETextLine *pCaretLine = GetLine(pcaret, NULL, NULL, &pCaretNode);
	ASSERT(pcaret && pCaretLine);
	if (pCaretNode == pNodeFound)
	{
		return TRUE;
	}
	pCaretLine->clst.RemoveAt(pCaretNode);
	if (pNodeFound)
	{
		if (IsLinefeedNode(pNodeFound))
		{
			m_buffer.CaretMoveBefore(pNodeFound->pdata);
			pCaretNode = pLineFound->pdata->clst.InsertBefore(pNodeFound, pcaret);
			//pcaret->o.x = pNodeFound->pdata->o.x;
			//pcaret->o.y = pNodeFound->pdata->o.y;
		}
		else
		{
			if (nPos <= 0)
			{
				m_buffer.CaretMoveBefore(pNodeFound->pdata);
				pCaretNode = pLineFound->pdata->clst.InsertBefore(pNodeFound, pcaret);
				//pcaret->o.x = pNodeFound->pdata->o.x;
				//pcaret->o.y = pNodeFound->pdata->o.y;
			}
			else
			{
				m_buffer.CaretMoveAfter(pNodeFound->pdata);
				pCaretNode = pLineFound->pdata->clst.InsertAfter(pNodeFound, pcaret);
				//pcaret->o.x = pNodeFound->pdata->o.x + pNodeFound->pdata->o.cx;
				//pcaret->o.y = pNodeFound->pdata->o.y;
			}
		}
	}
	else
	{
		BOOL bCaretFixed = FALSE;
		CETextLine *pLineX = GetPrevLine(pLineFound->pdata);
		if (pLineX)
		{
			ASSERT(pLineX->clst.GetCount() > 0);
			if (pLineX->clst.GetCount())
			{
				if (m_buffer.CaretMoveAfter(pLineX->clst.GetTail()))
					bCaretFixed = TRUE;
			}
		}
		if (!bCaretFixed)
		{
			pLineX = GetNextLine(pLineFound->pdata);
			if (pLineX)
			{
				if (pLineX->clst.GetCount())
				{
					if (m_buffer.CaretMoveBefore(pLineX->clst.GetHead()))
						bCaretFixed = TRUE;
				}
			}
		}
		pCaretNode = pLineFound->pdata->clst.AddHead(pcaret);
		pcaret->o.x = pLineFound->pdata->x;
		pcaret->o.y = pLineFound->pdata->y;
	}
	//光标的y位置和高度参考物根据插入模式调整，插入模式下参考左边字符，覆盖模式下参考右边字符
	PCharNode pRefTo = NULL;
	if (m_buffer.IsOverwriteMode())
	{
		pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
		if (pRefTo)
		{
			pcaret->o.x = pRefTo->pdata->o.x;
			pcaret->o.y = pRefTo->pdata->o.y;
			pcaret->o.cy = pRefTo->pdata->o.cy;
		}
	}
	if (pRefTo == NULL)
	{
		if (pCaretNode->pPrev == NULL)
		{
			pRefTo = LineFindNextNZNode(pCaretNode->pNext, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
		if (pRefTo == NULL)
		{
			pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
			if (pRefTo)
			{
				pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
				pcaret->o.y = pRefTo->pdata->o.y;
				pcaret->o.cy = pRefTo->pdata->o.cy;
			}
		}
	}
	//if (pRefTo == NULL)
	//{
	//	pRefTo = LineFindPrevNZNode(pCaretNode->pPrev, 0);
	//	if (pRefTo)
	//	{
	//		pcaret->o.x = pRefTo->pdata->o.x + pRefTo->pdata->o.cx;
	//		pcaret->o.y = pRefTo->pdata->o.y;
	//		pcaret->o.cy = pRefTo->pdata->o.cy;
	//	}
	//}
	ASSERT(pCaretNode);
	//如果此时光标的右边没有字符，就切换光标为插入模式
	if (LineFindNextNZNode(pCaretNode->pNext, 0) == NULL)
	{
		if (!m_buffer.IsForceInsertMode())
			m_buffer.SetForceInsertMode(TRUE);
	}
	EnsureCaretVisible(pRectChanged, NULL);
	OnCaretMove(pcaret);
	return TRUE;
}

void CETextManager::OnCaretMove(PEObjLink pcaret)
{

}

PEObjLink CETextManager::GetCaret()
{
	return m_buffer.GetCaret();
}

//根据字符查找行
CETextLine *CETextManager::GetLine(
	IN PEObjLink pChar,
	OUT PARAGNODE ** ppPrag/* = NULL*/,
	OUT LineNode  **ppLineNode/* = NULL*/,
	OUT CharNode **ppCharNode/* = NULL*/
	)
{
	if (ppPrag)
		*ppPrag = NULL;
	if (ppLineNode)
		*ppLineNode = NULL;
	if (ppCharNode)
		*ppCharNode = NULL;
	PCharNode pNodeLink;
	PLineNode pLineNode;
	PPARAGNODE ppraNode = m_parags.GetHeadNode();
	while (ppraNode)
	{
		pLineNode = ppraNode->pdata->lines.GetHeadNode();
		while (pLineNode)
		{
			pNodeLink = pLineNode->pdata->clst.Find(pChar);
			if (pNodeLink)
			{
				if (ppPrag)
					*ppPrag = ppraNode;
				if (ppLineNode)
					*ppLineNode = pLineNode;
				if (ppCharNode)
					*ppCharNode = pNodeLink;
				return pLineNode->pdata;
			}
			pLineNode = pLineNode->pNext;
		}
		ppraNode = ppraNode->pNext;
	}
	return NULL;
}
#ifdef _DEBUG
int CETextManager::CountCaret()
{
	int nCount = 0;
	PEObjLink pcaret=GetCaret();
	PLineNode pLineNode;
	PPARAGNODE ppraNode = m_parags.GetHeadNode();
	while (ppraNode)
	{
		pLineNode = ppraNode->pdata->lines.GetHeadNode();
		while (pLineNode)
		{
			if (pLineNode->pdata->clst.Find(pcaret))
				nCount++;
			pLineNode = pLineNode->pNext;
		}
		ppraNode = ppraNode->pNext;
	}
	return nCount;

}
#endif
CETextParagraph *CETextManager::GetParagraph(
	IN PEObjLink pChar,
	OUT PARAGNODE **ppPrag/* = NULL*/,
	OUT LineNode **ppLineNode/* = NULL*/,
	OUT CharNode **ppCharNode/* = NULL*/
	)
{
	if (ppPrag)
		*ppPrag = NULL;
	if (ppLineNode)
		*ppLineNode = NULL;
	if (ppCharNode)
		*ppCharNode = NULL;
	PCharNode pNodeLink;
	PLineNode pLineNode;
	PPARAGNODE ppraNode = m_parags.GetHeadNode();
	while (ppraNode)
	{
		pLineNode = ppraNode->pdata->lines.GetHeadNode();
		while (pLineNode)
		{
			pNodeLink = pLineNode->pdata->clst.Find(pChar);
			if (pNodeLink)
			{
				if (ppPrag)
					*ppPrag = ppraNode;
				if (ppLineNode)
					*ppLineNode = pLineNode;
				if (ppCharNode)
					*ppCharNode = pNodeLink;
				return ppraNode->pdata;
			}
			pLineNode = pLineNode->pNext;
		}
		ppraNode = ppraNode->pNext;
	}
	return NULL;
}

BOOL CETextManager::IsPartOfErrorWord(PEObjLink pObj)
{
	CEPtrNode<CharList*> *pNode = m_errorWords.GetHeadNode();
	while (pNode)
	{
		if (pNode->pdata->Find(pObj))
			return TRUE;
		pNode = pNode->pNext;
	}
	return FALSE;
}

using namespace Gdiplus;
struct callbackdata
{
	CETextManager *pthis;
	CDC *pDC;
	COLORREF crLine;
	float lineWidth;
	int x;
	int y;
};

//static 
void CALLBACK CETextManager::DrawWaveLineProc(int X, int Y, LPARAM lpData)
{
	callbackdata *pdata = (callbackdata *)lpData;
	CDC* pDC = (CDC*)pdata->pDC;
	int y = int(Y + sin((double)X));
	Graphics g(pDC->GetSafeHdc());
	g.SetSmoothingMode(SmoothingModeHighQuality);
	//g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
	g.SetInterpolationMode(InterpolationModeBicubic/*InterpolationModeHighQuality*/);
	//g.SetCompositingQuality(CompositingQualityHighQuality);
	Color crPen;
	crPen.SetFromCOLORREF(pdata->crLine);
	Pen pen(crPen, pdata->lineWidth);
	g.DrawLine(&pen, pdata->x, pdata->y, X, y);
	pdata->x = X;
	pdata->y = y;
	//pDC->LineTo(X, y);
}
void CETextManager::DrawWaveLine(CDC *pDC, LONG x1, LONG x2, LONG y, COLORREF crColor)
{
	//pDC->MoveTo(x1, y);
	//CPen pen(PS_SOLID, 1, crColor);
	//CPen *pOldPen = pDC->SelectObject(&pen);
	callbackdata data;
	data.pthis = this;
	data.pDC = pDC;
	data.lineWidth = 0.5f;
	data.crLine = 0xff;
	data.x = x1;
	data.y = y;
	::LineDDA(x1, y, x2, y, CETextManager::DrawWaveLineProc, (LPARAM)&data);
	//pDC->SelectObject(pOldPen);
}

void CETextManager::OnDrawText(
	PPARAGNODE pParagNode,
	PLineNode pLineNode,
	PCharNode pLinkNode,
	PEObjLink pChar,
	CDC *pDC, 
	LPRECT pRcObject, 
	LPRECT pRcClip,
	CFont *pLastFont,
	BOOL bIsSelected)
{
	CETextRange *pRange = GetTextRange(pChar);
	if (pRange == NULL)
		return;
	int nBkMode = pDC->GetBkMode();
	COLORREF crBk = pDC->GetBkColor();
	COLORREF crText = pDC->GetTextColor();

	WCHAR text[2] = { 0, 0, };
	//CFont font;
	//CFont *pOldFont = NULL;
	pDC->SetBkMode(TRANSPARENT);
	CRect rcObj = *pRcObject;
	if (bIsSelected)
	{
		rcObj.top = min(rcObj.top,pLineNode->pdata->y);
		rcObj.bottom = max(rcObj.bottom,pLineNode->pdata->y + pLineNode->pdata->cy);
		COLORREF crBkg = GetSysColor(COLOR_HIGHLIGHT);
		CBrush br(crBkg);
		//pDC->FillSolidRect(&rcObj, crBkg);
		pDC->FillRect(&rcObj, &br);
		//TRACE(L"1 Draw selected char %c \n\trect=%d,%d,%d,%d width=%d,height=%d\n\tclip=%d,%d,%d,%d width=%d,height=%d\n",
		//	pChar->o.c, rcObj.left, rcObj.right, rcObj.top, rcObj.bottom,
		//	rcObj.Width(), rcObj.Height(),
		//	pRcClip->left, pRcClip->right, pRcClip->top, pRcClip->bottom,
		//	pRcClip->right - pRcClip->left, pRcClip->bottom - pRcClip->top);
	}
	else
	{
		if (pRange->m_crBk != BADCOLOR)
		{
			//pDC->SetBkColor(pRange->m_crBk);
			//pDC->SetBkMode(OPAQUE);
			rcObj.top = min(rcObj.top,pLineNode->pdata->y);
			rcObj.bottom = max(rcObj.bottom,pLineNode->pdata->y + pLineNode->pdata->cy);
			CBrush br(pRange->m_crBk);
			//pDC->FillSolidRect(&rcObj, pRange->m_crBk);
			pDC->FillRect(&rcObj, &br);
			//TRACE(L"2 Draw normal char %c \n\trect=%d,%d,%d,%d width=%d,height=%d\n\tclip=%d,%d,%d,%d width=%d,height=%d\n",
			//	pChar->o.c, rcObj.left, rcObj.right, rcObj.top, rcObj.bottom, 
			//	rcObj.Width(), rcObj.Height(),
			//	pRcClip->left, pRcClip->right, pRcClip->top, pRcClip->bottom,
			//	pRcClip->right - pRcClip->left, pRcClip->bottom - pRcClip->top);
		}
		else
		{
			//pDC->SetBkMode(TRANSPARENT);
		}
	}
	if (bIsSelected)
	{
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHTTEXT));
	}
	else
	{
		if (pRange->m_crText != BADCOLOR)
		{
			pDC->SetTextColor(pRange->m_crText);
		}
	}
	ASSERT(sizeof(pRange->m_font) == sizeof(LOGFONTW));
	LOGFONTW lf = { 0 };
	pLastFont->GetLogFont(&lf);
	if (memcmp(&lf, &pRange->m_font, sizeof(LOGFONTW)))
	{
		pLastFont->DeleteObject();
		pLastFont->CreateFontIndirectW(&pRange->m_font);
		/*pOldFont = */pDC->SelectObject(pLastFont);
		//*pLastFont = pRange->m_font;
	}
	text[0] = pChar->o.c;
	if (iswprint(pChar->o.c))
	{
		pDC->DrawTextW(text, 1, pRcObject,
			DT_SINGLELINE | DT_NOPREFIX | DT_BOTTOM | DT_LEFT);
	}
	else
	{
	}
	//if (pOldFont)
	//	pDC->SelectObject(pOldFont);
	if (IsPartOfErrorWord(pChar))
	{
		DrawWaveLine(pDC,
			pRcObject->left,
			pRcObject->right,
			pRcObject->bottom,
			0xff);
	}

	pDC->SetBkColor(crBk);
	pDC->SetTextColor(crText);
	pDC->SetBkMode(nBkMode);
}
void CETextManager::OnDrawBitmap(
	PPARAGNODE pParagNode,
	PLineNode pLineNode,
	PCharNode pLinkNode,
	PEObjLink pBmp,
	CDC *pDC, 
	LPRECT pRcObject, 
	LPRECT pRcClip,
	BOOL bIsSelected)
{
	CETextRange *pRange = GetTextRange(pBmp);
	if (pRange == NULL)
		return;

	CRect rcTo;
	if (!rcTo.IntersectRect(pRcObject, pRcClip))
		return;
	CDC dc;
	if (!dc.CreateCompatibleDC(pDC))
		return;

	int nBkMode = pDC->GetBkMode();
	COLORREF crBk = pDC->GetBkColor();
	COLORREF crText = pDC->GetTextColor();
	pDC->SetBkMode(TRANSPARENT);
	CRect rcObj = *pRcObject;
	if (bIsSelected)
	{
		rcObj.top = min(rcObj.top,pLineNode->pdata->y);
		rcObj.bottom = max(rcObj.bottom, pLineNode->pdata->y + pLineNode->pdata->cy);
		COLORREF crBkg = GetSysColor(COLOR_HIGHLIGHT);
		CBrush br(crBkg);
		//pDC->FillSolidRect(&rcObj, crBkg);
		pDC->FillRect(&rcObj, &br);
	}
	else
	{
		if (pRange->m_crBk != BADCOLOR)
		{
			//pDC->SetBkColor(pRange->m_crBk);
			//pDC->SetBkMode(OPAQUE);
			rcObj.top = min(rcObj.top,pLineNode->pdata->y);
			rcObj.bottom = max(rcObj.bottom,pLineNode->pdata->y + pLineNode->pdata->cy);
			CBrush br(pRange->m_crBk);
			//pDC->FillSolidRect(&rcObj, pRange->m_crBk);
			pDC->FillRect(&rcObj, &br);
		}
		else
		{
			//pDC->SetBkMode(TRANSPARENT);
		}
	}
	if (bIsSelected)
	{
		pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHTTEXT));
	}
	else
	{
		if (pRange->m_crText != BADCOLOR)
		{
			pDC->SetTextColor(pRange->m_crText);
		}
	}

	CBitmapContext *pCtx = static_cast<CBitmapContext *>(pBmp->o.pCt);
	HGDIOBJ hBmp=dc.SelectObject((HGDIOBJ)pCtx->m_hBmp);
	CRect rcBmp(pRcObject);
	rcBmp.OffsetRect(-rcBmp.TopLeft());
	rcBmp.left += rcTo.left - pRcObject->left;
	rcBmp.top += rcTo.top - pRcObject->top;
	rcBmp.right = rcBmp.left + rcTo.Width();
	rcBmp.bottom = rcBmp.top + rcTo.Height();
	pDC->BitBlt(rcTo.left, rcTo.top, rcTo.Width(), rcTo.Height(),
		&dc, rcBmp.left, rcBmp.top, SRCCOPY);
	dc.SelectObject(hBmp);

	pDC->SetBkColor(crBk);
	pDC->SetTextColor(crText);
	pDC->SetBkMode(nBkMode);
}
void CETextManager::OnDrawObject(
	PPARAGNODE pParagNode,
	PLineNode pLineNode,
	PCharNode pLinkNode,
	PEObjLink pObject,
	CDC *pDC, 
	LPRECT pRcObject, 
	LPRECT pRcClip,
	CFont *pLastFont)
{
	BOOL bIsSelected = IsSelected(pObject);
	if (pObject->o.type == ETYPE_TEXT)
	{
		OnDrawText(pParagNode, pLineNode, pLinkNode, 
			pObject, pDC, pRcObject, pRcClip, pLastFont, bIsSelected);
	}
	else if (pObject->o.type == ETYPE_BITMAP)
	{
		OnDrawBitmap(pParagNode, pLineNode, pLinkNode, 
			pObject, pDC, pRcObject, pRcClip, bIsSelected);
	}
}

void CETextManager::Draw(CDC *pDC)
{
	ASSERT(pDC);
	ASSERT(pDC->GetSafeHdc());
	if (pDC == NULL)
		return;
	if (pDC->GetSafeHdc() == NULL)
		return;
	CRect rcClip(0, 0, 0, 0);
	pDC->GetClipBox(&rcClip);
	if (rcClip.IsRectEmpty())
		return;
	CRect rcDrawTo;
	if (!rcDrawTo.IntersectRect(&rcClip, &m_rcText))
		return;
	pDC->FillSolidRect(&rcDrawTo, GetSysColor(COLOR_WINDOW));
	if (m_parags.GetCount() <= 0)
		return;
	CRect rcTest;
	CETextLine *pLine;
	PEObjLink plink;
	CRect rcObj;
	WCHAR text[2] = { 0, 0, };
	ASSERT(m_ranges.GetCount());
	CETextRange *pNormal = m_ranges.GetHead();
	ASSERT(pNormal);
	COLORREF crBk = pNormal->m_crBk;
	COLORREF crText = pNormal->m_crText;
	LOGFONTW lf = pNormal->m_font;
	CFont font;
	font.CreateFontIndirectW(&lf);

	int nBkMode = pDC->SetBkMode(OPAQUE);
	COLORREF crOldBk = pDC->SetBkColor(crBk);
	COLORREF crOldFr = pDC->SetTextColor(crText);
	CFont *pOldFont = pDC->SelectObject(&font);

	PCharNode pLinkNode;
	PLineNode pLineNode;
	PPARAGNODE pParagNode = m_parags.GetHeadNode();
	while (pParagNode)
	{
		pLineNode = pParagNode->pdata->lines.GetHeadNode();
		while (pLineNode)
		{
			pLine = pLineNode->pdata;
			pLinkNode = pLineNode->pdata->clst.GetHeadNode();
			while (pLinkNode)
			{
				plink = pLinkNode->pdata;
				rcObj.SetRect(
					plink->o.x, 
					plink->o.y, 
					plink->o.x + plink->o.cx, 
					plink->o.y + plink->o.cy);
				if (rcTest.IntersectRect(&rcObj, &rcDrawTo))
				{
					OnDrawObject(pParagNode, pLineNode, pLinkNode, plink, pDC, &rcObj, &rcDrawTo, &font);
				}//end if (rcTest.IntersectRect(&rcChar, &rcDrawTo))
				pLinkNode = pLinkNode->pNext;
			}
			pLineNode = pLineNode->pNext;
		}
		pParagNode = pParagNode->pNext;
	}
	pDC->SetBkColor(crOldBk);
	pDC->SetTextColor(crOldFr);
	pDC->SelectObject(pOldFont);
	pDC->SetBkMode(nBkMode);
}

//开始选择。移动选择开始和结束标记到光标位置(左边)
BOOL CETextManager::SetStartSelecting()
{
	if (m_buffer.StartSelect(m_buffer.GetCaret(), TRUE))
	{
		return m_buffer.EndSelect(m_buffer.GetCaret(), TRUE);
	}
	return FALSE;
}
//结束选择。移动选择结束标记到光标位置
BOOL CETextManager::SetEndSelecting()
{
	return m_buffer.EndSelect(m_buffer.GetCaret(), TRUE);
}
//取消选择。移动开始和结束标记到一起
BOOL CETextManager::CancelSelecting()
{
	//return m_buffer.StartSelect(m_buffer.GetSelectionEnd(), TRUE);
	return m_buffer.SetSelectionEmpty();
}

//检测是否选择了一些什么
BOOL CETextManager::IsSelectingEmpty()
{
	return m_buffer.IsSelectionEmpty();
}
//取得选择的内容
INT_PTR CETextManager::GetSelected(OUT CharList *pList/* = NULL*/)
{
	return m_buffer.GetSelected(pList);
}
//检测是否被选中
BOOL CETextManager::IsSelected(PEObjLink pObj)
{
	return m_buffer.IsSelected(pObj);
}

//计算选中的内容的区域并计算出屏幕刷新区
BOOL CETextManager::GetSelectionUpdateArea(LPRECT pRect)
{
	SetRectEmpty(pRect);
	CRect rc;
	PEObjLink pFirst = NULL;
	PEObjLink pLast = NULL;
	if (!m_buffer.GetSelectedBoundRect(&rc, &pFirst, &pLast))
		return FALSE;
	if (pFirst)
	{
		CETextLine *pLine = GetLine(pFirst, NULL, NULL, NULL);
		if (pLine)
		{
			if (rc.top > pLine->y)
				rc.top = pLine->y;
			if (rc.bottom < pLine->y + pLine->cy)
				rc.bottom = pLine->y + pLine->cy;
		}
	}
	if (pLast)
	{
		CETextLine *pLine = GetLine(pLast, NULL, NULL, NULL);
		if (pLine)
		{
			if (rc.top > pLine->y)
				rc.top = pLine->y;
			if (rc.bottom < pLine->y + pLine->cy)
				rc.bottom = pLine->y + pLine->cy;
		}
	}
	CRect rcTest;
	if (!rcTest.IntersectRect(&rc, &m_rcText))
		return FALSE;
	*pRect = rcTest;
	return TRUE;
}

class CEnDict
{
public:
#pragma pack(push)
#pragma pack(1)
	struct enword
	{
		LPWSTR wszWord;
		enword *pNext;
	};

	struct enchar
	{
		WCHAR c;
		enword *pWords;
		DWORD dwWordCount;
		DWORD pos;
		DWORD len;
	};
	struct enindex
	{
		WCHAR c;
		DWORD wordCount;
		DWORD pos;
		DWORD len;
	};
#pragma pack(pop)
public:
	CEnDict()
	{

	}
	~CEnDict()
	{
	}
	/* 文件结构
	--------索引开始-------------
	DWORD 数据部分的字节数
	WCHAR c1 字母 + DWORD 词数 + DWORD 位置->p1 + DWORD 长度
	WCHAR c2 字母 + DWORD 词数 + DWORD 位置->p2 + DWORD 长度
	....
	WCHAR cN 字母 + DWORD 词数 + DWORD 位置->pN + DWORD 长度
	--------索引结束-------------
	--------数据开始-------------
	->p1
	+ 词1的长度BYTE（WCHAR 个数）+词1串(UNICODE)
	+ 词2的长度BYTE（WCHAR 个数）+词2串(UNICODE)
	...
	+ 词N的长度BYTE（WCHAR 个数）+词N串(UNICODE)
	->p2
	+ 词1的长度BYTE（WCHAR 个数）+词1串(UNICODE)
	+ 词2的长度BYTE（WCHAR 个数）+词2串(UNICODE)
	...
	+ 词N的长度BYTE（WCHAR 个数）+词N串(UNICODE)
	...
	->pN
	+ 词1的长度BYTE（WCHAR 个数）+词1串(UNICODE)
	+ 词2的长度BYTE（WCHAR 个数）+词2串(UNICODE)
	...
	+ 词N的长度BYTE（WCHAR 个数）+词N串(UNICODE)
	--------数据结束-------------
	*/
	bool ReadIndex(CAtlFile *pFile,
		CByteArray& aRet,
		DWORD& dwDataSize)
	{
		HRESULT hr;
		aRet.SetSize(0);
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		DWORD dwHeaderSize;
		const DWORD dwIndexSize = sizeof(enindex) * 26;
		do
		{
			if ((hr = pFile->Seek(0, FILE_BEGIN)) != S_OK)
				break;
			if ((hr = pFile->GetSize(ullFileSize)) != S_OK)
				break;
			if (ullFileSize < sizeof(dwDataSize))
			{
				hr = E_FAIL;
				break;
			}
			if ((hr = pFile->Read(&dwDataSize, sizeof(dwDataSize), dwRead)) != S_OK)
				break;
			if (dwRead != sizeof(dwDataSize))
			{
				hr = E_FAIL;
				break;
			}
			dwHeaderSize = sizeof(dwDataSize) + dwIndexSize;
			ASSERT(ullFileSize >= dwHeaderSize + dwDataSize);
			if (ullFileSize < dwHeaderSize + dwDataSize)
			{
				hr = E_UNEXPECTED;
				break;
			}
			aRet.SetSize(dwIndexSize);
			if (aRet.GetSize() != dwIndexSize)
			{
				hr = E_OUTOFMEMORY;
				break;
			}
			if ((hr = pFile->Read(aRet.GetData(), dwIndexSize, dwRead)) != S_OK)
				break;
			if (dwRead != dwIndexSize)
			{
				hr = E_FAIL;
				break;
			}
		} while (0);
		return hr == S_OK ? true : false;
	}

	//根据索引检索数据块返回。数据块中含有所有以c开头的词汇信息。
	bool ReadData(CAtlFile *pFile,
		CByteArray *pIndexData,
		WCHAR c,
		CByteArray& aDataRet)
	{
		HRESULT hr;
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		enindex *pIndex;
		DWORD i;
		DWORD dwLimitedSize;
		do
		{
			if ((hr = pFile->GetSize(ullFileSize)) != S_OK)
				break;
			pIndex = (enindex *)pIndexData->GetData();
			for (i = 0; i < 26; i++)
			{
				if (pIndex[i].c == c)
				{
					dwLimitedSize = DWORD(ullFileSize - pIndex[i].pos);
					if (pIndex[i].len>dwLimitedSize)
					{
						hr = E_UNEXPECTED;
						break;
					}
					if ((hr = pFile->Seek(pIndex[i].pos, FILE_BEGIN)) != S_OK)
						break;
					//分配内存
					if (aDataRet.GetSize() <= (INT_PTR)pIndex[i].len)
					{
						aDataRet.SetSize(pIndex[i].len);
						if (aDataRet.GetSize() != pIndex[i].len)
						{
							hr = E_OUTOFMEMORY;
							break;
						}
					}
					else
					{
						aDataRet.SetSize(pIndex[i].len);
					}
					if ((hr = pFile->Read(aDataRet.GetData(), pIndex[i].len, dwRead)) != S_OK)
						break;
					if (dwRead != pIndex[i].len)
					{
						hr = E_FAIL;
						break;
					}
					break;
				}//end if ==c
			}//end for
			if (hr != S_OK)
				break;
		} while (0);
		return hr == S_OK ? true : false;
	}
	//从文件指定位置读取数据块返回。数据块中含有所有以c开头的词汇信息。
	bool ReadData(CAtlFile *pFile,
		DWORD dwPos,
		DWORD dwLen,
		WCHAR c,
		CByteArray& aDataRet)
	{
		HRESULT hr;
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		DWORD dwLimitedSize;
		do
		{
			if ((hr = pFile->GetSize(ullFileSize)) != S_OK)
				break;
			dwLimitedSize = DWORD(ullFileSize - dwPos);
			if (dwLen>dwLimitedSize)
			{
				hr = E_UNEXPECTED;
				break;
			}
			if ((hr = pFile->Seek(dwPos, FILE_BEGIN)) != S_OK)
				break;
			//分配内存
			if (aDataRet.GetSize() <= (INT_PTR)dwLen)
			{
				aDataRet.SetSize(dwLen);
				if (aDataRet.GetSize() != dwLen)
				{
					hr = E_OUTOFMEMORY;
					break;
				}
			}
			else
			{
				aDataRet.SetSize(dwLen);
			}
			if ((hr = pFile->Read(aDataRet.GetData(), dwLen, dwRead)) != S_OK)
				break;
			if (dwRead != dwLen)
			{
				hr = E_FAIL;
				break;
			}
		} while (0);
		return hr == S_OK ? true : false;
	}

	//对 pData 分解成 CStringList 返回
	bool ParseData(/*WCHAR c,*/
		CByteArray *pData,
		DWORD dwWordCount,
		CStringList& ret)
	{
		HRESULT hr = S_OK;
		LPCWSTR p;
		LPBYTE pdata;
		DWORD iWord;
		BYTE byteWordLen;
		CStringW sWord;
		do
		{
			pdata = (LPBYTE)pData->GetData();
			for (iWord = 0; iWord < dwWordCount; iWord++)
			{
				sWord.Empty();
				byteWordLen = *pdata; pdata++;
				if (byteWordLen)
				{
					p = (LPCWSTR)pdata;
					sWord.Append(p, byteWordLen);
					pdata += byteWordLen*sizeof(WCHAR);
				}
				if (ret.AddTail(sWord) == NULL)
				{
					hr = E_FAIL;
					break;
				}
			}//end for
		} while (0);
		return hr == S_OK ? true : false;
	}
	//对 pData 分解成 过程中比较单词，如果找到则返回 true，否则false，如果出错也返回 false
	bool ParseDataFind(/*WCHAR c,*/
		CByteArray *pData,
		DWORD dwWordCount,
		LPCWSTR wszWord)
	{
		HRESULT hr = S_OK;
		LPCWSTR p;
		LPBYTE pdata;
		DWORD iWord;
		BYTE byteWordLen;
		CStringW sWord;
		do
		{
			pdata = (LPBYTE)pData->GetData();
			for (iWord = 0; iWord < dwWordCount; iWord++)
			{
				sWord.Empty();
				byteWordLen = *pdata; pdata++;
				if (byteWordLen)
				{
					p = (LPCWSTR)pdata;
					sWord.Append(p, byteWordLen);
					pdata += byteWordLen*sizeof(WCHAR);
				}
				if (sWord.CompareNoCase(wszWord) == 0)
					return true;
				//if (ret.AddTail(sWord) == NULL)
				//{
				//	hr = E_FAIL;
				//	break;
				//}
			}//end for
		} while (0);
		return /*hr == S_OK ? true : */false;
	}
	//拼写检查，全匹配返回 true，否则 返回 false
	bool SpellCheck(LPCWSTR wszWord,
		CAtlFile *pFile,
		CByteArray *pIndexData)
	{
		WCHAR c[2] = { 0 };
		c[0] = wszWord[0];
		if (!(c[0] >= L'a' && c[0] <= L'z'))
			_wcslwr_s(c, 2);
		enindex *pIdx;
		enindex *pIdxSel;
		//int i;
		CByteArray aData;
		pIdx = (enindex *)pIndexData->GetData();
		pIdxSel = &pIdx[c[0] - L'a'];;
		if (ReadData(pFile, pIdxSel->pos, pIdxSel->len, c[0], aData))
		{
			if (ParseDataFind(&aData, pIdxSel->wordCount, wszWord))
				return true;
		} //end if (ReadData(pFile, pIdxSel->pos, pIdxSel->len, *p, aData))
		return false;
	}
};

class CParseResult
{
public:
#pragma pack(push)
#pragma pack(1)
	struct WordPair
	{
		BYTE wordLen;
		BYTE pinyinLen;
		LPWSTR wszWord;
		LPWSTR wszPinyin;	//英语拼音
	};
#pragma pack(pop)
	WCHAR m_char;	//字
	CStringList m_enPinyins;	//英文格式的拼音列表
	CStringList m_cnPinyins;	//中文格式的拼音列表
	CTypedPtrList<CPtrList, WordPair*> m_pairs;	//单词和拼音对列表
public:
	CParseResult()
		: m_enPinyins(1)
		, m_cnPinyins(1)
		, m_char(0)
	{
	}
	~CParseResult()
	{
		if (m_pairs.GetCount())
		{
			WordPair *pPair;
			POSITION pos = m_pairs.GetHeadPosition();
			while (pos)
			{
				pPair = m_pairs.GetNext(pos);
				if (pPair->wszPinyin)
					free(pPair->wszPinyin);
				if (pPair->wszWord)
					free(pPair->wszWord);
				delete pPair;
			}
			m_pairs.RemoveAll();
		}
	}
public:
	POSITION Add(LPCWSTR wszWord, 
		LPCWSTR wszPinyin)
	{
		ASSERT(wszWord);
		WordPair *pPair = new WordPair;
		if (pPair == NULL)
			return NULL;
		pPair->wszWord = _wcsdup(wszWord);
		if (pPair->wszWord == NULL)
		{
			delete pPair;
			return NULL;
		}
		pPair->wordLen = wcslen(wszWord);
		pPair->pinyinLen = 0;
		pPair->wszPinyin = NULL;
		if (wszPinyin)
		{
			pPair->wszPinyin = _wcsdup(wszPinyin);
			if (pPair->wszPinyin == NULL)
			{
				free(pPair->wszWord);
				delete pPair;
				return NULL;
			}
			pPair->pinyinLen = wcslen(wszPinyin);
		}
		//按词组长度做倒序排序插入
		POSITION pos, pos1,posIns=NULL;
		WordPair *pPairX;
		pos = m_pairs.GetHeadPosition();
		while (pos)
		{
			pos1 = pos;
			pPairX = m_pairs.GetNext(pos);
			if (pPairX->wordLen <= pPair->wordLen)
			{
				posIns = m_pairs.InsertBefore(pos1, pPair);
				break;
			}
		}
		if (posIns == NULL)
			posIns = m_pairs.AddTail(pPair);
		if (posIns == NULL)
		{
			free(pPair->wszWord);
			if (pPair->wszPinyin) free(pPair->wszPinyin);
			delete pPair;
			return false;
		}
		return posIns;
	}

};

class CWords
{
public:
#pragma pack(push)
#pragma pack(1)
	struct WordsItem
	{
		BYTE wordLen;
		BYTE pinyinLen;
		LPWSTR wszWord;
		LPWSTR wszPinyin;	//en
	};
#pragma pack(pop)
	WCHAR c;
	CTypedPtrList<CPtrList, WordsItem *> m_list;
public:
	CWords()
	{
		c = 0;
	}
	~CWords()
	{
		if (m_list.GetCount())
		{
			WordsItem *pPair;
			POSITION pos = m_list.GetHeadPosition();
			while (pos)
			{
				pPair = m_list.GetNext(pos);
				free(pPair->wszWord);
				if (pPair->wszPinyin) free(pPair->wszPinyin);
				delete pPair;
			}
			m_list.RemoveAll();
		}
	}
};
class CMultiMap
{
public:
	CTypedPtrList<CPtrList, CWords *> m_list;
public:
	CMultiMap()
	{
	}
	~CMultiMap()
	{
		if (m_list.GetCount())
		{
			POSITION pos = m_list.GetHeadPosition();
			while (pos)
			{
				delete(m_list.GetNext(pos));
			}
			m_list.RemoveAll();
		}
	}
	CWords * Lookup(WCHAR c)
	{
		CWords *pWords;
		POSITION pos = m_list.GetHeadPosition();
		while (pos)
		{
			pWords = m_list.GetNext(pos);
			if (pWords->c == c)
				return pWords;
		}
		return NULL;
	}
	CWords * CreateWord(WCHAR c, 
		LPCWSTR wszText, 
		LPCWSTR wszEnPinyin)
	{
		CWords *pWords = new CWords();
		if (pWords == NULL)
			return NULL;
		POSITION pos;
		if ((pos = m_list.AddTail(pWords)) == NULL)
		{
			delete pWords;
			return NULL;
		}
		pWords->c = c;
		if (!Add(pWords, wszText, wszEnPinyin, FALSE))
		{
			m_list.RemoveAt(pos);
			delete pWords;
			return NULL;
		}
		return pWords;
	}
	//添加新项，并按单词长度倒序排序
	bool Add(CWords *pWords, 
		LPCWSTR wszText, 
		LPCWSTR wszEnPinyin,
		BOOL bCheck = TRUE)
	{
		BOOL bFound = FALSE;
		CWords::WordsItem *pPair;
		POSITION pos,posSave,posInserted=NULL;
		if (bCheck)
		{
			pos = pWords->m_list.GetHeadPosition();
			while (pos)
			{
				pPair = pWords->m_list.GetNext(pos);
				if (_wcsicmp(pPair->wszWord, wszText) == 0)
				{
					bFound = TRUE;
					break;
				}
			}
		}
		if (!bFound)
		{
			LPWSTR pT = _wcsdup(wszText);
			if (pT == NULL)
				return false;
			LPWSTR pP = _wcsdup(wszEnPinyin);
			if (pP == NULL)
			{
				free(pT);
				return false;
			}
			CWords::WordsItem *pNewPair = new CWords::WordsItem;
			if (pNewPair == NULL)
			{
				free(pT);
				free(pP);
				return false;
			}
			pNewPair->wordLen = wcslen(wszText);
			pNewPair->pinyinLen = wcslen(wszEnPinyin);
			pNewPair->wszPinyin = pP;
			pNewPair->wszWord = pT;
			//按长度做倒序排列
			pos = pWords->m_list.GetHeadPosition();
			while (pos)
			{
				posSave = pos;
				pPair = pWords->m_list.GetNext(pos);
				if (pPair->wordLen <= pNewPair->wordLen)
				{
					posInserted = pWords->m_list.InsertBefore(posSave, pNewPair);
					break;
				}
			}
			if (posInserted==NULL)
				posInserted = pWords->m_list.AddTail(pNewPair);
			if (posInserted == NULL)
			{
				free(pT);
				free(pP);
				delete pNewPair;
			}
			return posInserted != NULL ? true : false;
		}//end if (!bFound)
		return true;
	}
};

class CCnDict
{
public:
#pragma pack(push)
#pragma pack(1)
	struct Pinyin
	{
		LPWSTR pwszPinyin;
		Pinyin *pNext;
	};
	struct Word
	{
		LPWSTR pwszWord;
		LPWSTR pwszPinyin;
		Word *pNext;
	};
	struct Letter2
	{
		WCHAR c;			//字符
		char * szPinyin;	//拼音
		char * szWubi;		//五笔编码
		Pinyin *pPinyins;	//这里的拼音格式是 英文格式拼音+(+中文拼音+)
		WORD wPinyinCount;	//拼音个数
		Word *pWords;		//词指针
		WORD wWordCount;	//词的个数
		DWORD dwCounts;		//当前字出现在所有词中的次数，以此作为排序的依据之一。优先级最高，其次是拼音
		DWORD dwDataPos;	//数据段在文件中的位置
		DWORD dwDataLen;	//数据段长度
	};
	struct WordPair
	{
		LPWSTR pwszWord;
		LPWSTR pwszPinyin;
	};
	struct index2
	{
		WCHAR c;			// 字 + 
		DWORD counts;		// 词频 + 
		DWORD words;		// 词数 + 
		DWORD pos;			// 位置->p1 + 
		DWORD len;			// 长度
		char pinyin[8];		//拼音最大长度是7字节
		char wubi[8];		//五笔最大长度是6字节
	};
	struct header
	{
		WORD bytes;			//cN的信息长度，字节 + 
		WCHAR c;			// cN 字 + 
		WORD len;			// 拼音长度（WCHAR 个数) + 拼音串，以半角逗号分隔
	};
#pragma pack(pop)

	CCnDict()
	{
	}
	~CCnDict()
	{
	}
public:
	//取得第一个拼音，要求返回英文格式的拼音sEnPinyin
	bool GetEnPinyin(Letter2 * pLetter, CStringW& sEnPinyin)
	{
		sEnPinyin.Empty();
		if (pLetter->wPinyinCount <= 0)
			return false;
		sEnPinyin = pLetter->pPinyins->pwszPinyin;
		int nPos = sEnPinyin.Find(L'(');
		ASSERT(nPos >= 0);
		sEnPinyin.Delete(nPos, sEnPinyin.GetLength() - nPos);
		return true;
	}
	//增加拼音串。一个字会有多种发音。如果该拼音早已经存在的话，就放弃添加。比较的是英文格式的拼音。也就是说即使中文拼音不同，也是可能被放弃的。
	bool AddPinyin(Letter2 * pLetter, LPCWSTR wszPinyin, LPCWSTR wszCnPinyin)
	{
		CStringW sPinyin;
		BOOL bFound = FALSE;
		Pinyin *pTail = NULL;
		Pinyin *p = pLetter->pPinyins;
		while (p)
		{
			if (!bFound)
			{
				sPinyin = p->pwszPinyin;
				int nPos = sPinyin.Find(L'(');
				ASSERT(nPos >= 0);
				sPinyin.Delete(nPos, sPinyin.GetLength() - nPos);
				if (sPinyin.CompareNoCase(wszPinyin) == 0)
				{
					bFound = TRUE;
				}
				//if (_wcsicmp(p->pPinyin, wszPinyin) == 0)
				//{
				//	bFound = TRUE;
				//}
			}
			if (pTail == NULL)
			{
				if (p->pNext == NULL)
					pTail = p;
			}
			p = p->pNext;
		}
		if (bFound)
			return true;
		Pinyin *pPin = new Pinyin;
		if (pPin == NULL)
			return false;
		/*pPin->pPrev = */pPin->pNext = NULL;
		sPinyin = wszPinyin;
		sPinyin += L'(';
		sPinyin += wszCnPinyin;
		sPinyin += L')';
		pPin->pwszPinyin = _wcsdup(sPinyin/*wszPinyin*/);
		if (pPin->pwszPinyin == NULL)
		{
			delete pPin;
			return false;
		}
		if (pLetter->wPinyinCount == 0)
		{
			pLetter->pPinyins = pPin;
			pLetter->wPinyinCount++;
			return true;
		}
		ASSERT(pTail);
		if (pTail == NULL)
		{
			delete pPin;
			return false;
		}
		pTail->pNext = pPin;
		pLetter->wPinyinCount++;
		return true;
	}
	//增加词串。词的拼音只有 英文格式的，没有中文格式的
	bool AddWord(Letter2 * pLetter, LPCWSTR wszWord, LPCWSTR wszPinyin)
	{
		BOOL bFound = FALSE;
		Word *pTail = NULL;
		Word *p = pLetter->pWords;
		while (p)
		{
			if (!bFound)
			{
				if (_wcsicmp(p->pwszWord, wszWord) == 0)
				{
					bFound = TRUE;
				}
			}
			if (pTail == NULL)
			{
				if (p->pNext == NULL)
					pTail = p;
			}
			p = p->pNext;
		}
		if (bFound)
			return true;
		Word *pWord = new Word;
		if (pWord == NULL)
			return false;
		pWord->pNext = NULL;
		pWord->pwszPinyin = NULL;
		pWord->pwszWord = _wcsdup(wszWord);
		if (pWord->pwszWord == NULL)
		{
			delete pWord;
			return false;
		}
		if (wszPinyin)
		{
			if (wcslen(wszPinyin))
			{
				pWord->pwszPinyin = _wcsdup(wszPinyin);
				if (pWord->pwszPinyin == NULL)
				{
					free(pWord->pwszWord);
					delete pWord;
					return false;
				}
			}
		}
		if (pLetter->wWordCount == 0)
		{
			pLetter->pWords = pWord;
			pLetter->wWordCount++;
			return true;
		}
		ASSERT(pTail);
		if (pTail == NULL)
		{
			free(pWord->pwszWord);
			if (pWord->pwszPinyin)
				free(pWord->pwszPinyin);
			delete pWord;
			return false;
		}
		pTail->pNext = pWord;
		pLetter->wWordCount++;
		return true;
	}
	//也许addWord的时候的拼音是不准确的，这里再度矫正
	bool SetWordPinyin(Letter2 * pLetter, LPCWSTR wszWord, LPCWSTR wszPinyin)
	{
		Word *p = pLetter->pWords;
		while (p)
		{
			if (_wcsicmp(p->pwszWord, wszWord) == 0)
			{
				if (p->pwszPinyin)
				{
					free(p->pwszPinyin);
					p->pwszPinyin = NULL;
				}
				p->pwszPinyin = _wcsdup(wszPinyin);
				if (p->pwszPinyin != NULL)
					return true;
				break;
			}
			p = p->pNext;
		}
		return false;
	}
	//测试读取字库文件
	bool TryRead(LPCWSTR wszFile)
	{
		CAtlFile f;
		HRESULT hr;
		if ((hr = f.Create(wszFile,
			GENERIC_READ,
			FILE_SHARE_READ,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,
			NULL, NULL)) != S_OK)
			return false;
		DWORD dwLetters = 0;
		DWORD dwDataSize = 0;
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		DWORD dwIndexSize;
		void *pbuffer = NULL;
		index2 *pIndex;
		DWORD i;
		void *pbuffer2 = NULL;
		void *px;
		DWORD dwCurMemSize = 0;
		DWORD dwLimitedSize;
		header *phdr;
		LPCWSTR p;
		CStringW sValue;
		LPBYTE pdata;
		DWORD iWord;
		BYTE byteWordLen, bytePinyinLen;
		CStringW sWord, sPinyin;
		do
		{
			if ((hr = f.GetSize(ullFileSize)) != S_OK)
				break;
			if (ullFileSize < sizeof(dwLetters) + sizeof(dwDataSize))
			{
				hr = E_FAIL;
				break;
			}
			if ((hr = f.Read(&dwLetters, sizeof(dwLetters), dwRead)) != S_OK)
				break;
			if (dwRead != sizeof(dwLetters))
			{
				hr = E_FAIL;
				break;
			}
			if ((hr = f.Read(&dwDataSize, sizeof(dwDataSize), dwRead)) != S_OK)
				break;
			if (dwRead != sizeof(dwDataSize))
			{
				hr = E_FAIL;
				break;
			}
			dwIndexSize = sizeof(dwLetters) + sizeof(dwDataSize) +
				dwLetters*sizeof(index2);
			ASSERT(ullFileSize >= dwIndexSize + dwDataSize);
			if (ullFileSize < dwIndexSize + dwDataSize)
			{
				hr = E_UNEXPECTED;
				break;
			}
			pbuffer = malloc(dwLetters*sizeof(index2));
			if (pbuffer == NULL)
			{
				hr = E_OUTOFMEMORY;
				break;
			}
			if ((hr = f.Read(pbuffer, dwLetters*sizeof(index2), dwRead)) != S_OK)
				break;
			if (dwRead != dwLetters*sizeof(index2))
			{
				hr = E_FAIL;
				break;
			}
			pIndex = (index2 *)pbuffer;
			for (i = 0; i < dwLetters; i++)
			{
				TRACE(L"索引%d-字符'%c',词汇量%d个,词频%d,文件位置%u,长度%u\n",
					i + 1,
					pIndex[i].c,
					pIndex[i].words,
					pIndex[i].counts,
					pIndex[i].pos,
					pIndex[i].len);
				dwLimitedSize = DWORD(ullFileSize - pIndex[i].pos);
				if (pIndex[i].len>dwLimitedSize)
				{
					hr = E_UNEXPECTED;
					break;
				}
				if ((hr = f.Seek(pIndex[i].pos, FILE_BEGIN)) != S_OK)
					break;
				//分配内存
				if (pbuffer2 == NULL)
				{
					pbuffer2 = malloc(pIndex[i].len);
					if (pbuffer2 == NULL)
					{
						hr = E_OUTOFMEMORY;
						break;
					}
					dwCurMemSize = pIndex[i].len;
				}
				else
				{
					if (dwCurMemSize < pIndex[i].len)
					{
						px = realloc(pbuffer2, pIndex[i].len);
						if (px == NULL)
						{
							hr = E_OUTOFMEMORY;
							break;
						}
						pbuffer2 = px;
						dwCurMemSize = pIndex[i].len;
					}
				}
				if ((hr = f.Read(pbuffer2, pIndex[i].len, dwRead)) != S_OK)
					break;
				if (dwRead != pIndex[i].len)
				{
					hr = E_FAIL;
					break;
				}
				phdr = (header *)pbuffer2;
				ASSERT(phdr->c == pIndex[i].c);
				if (phdr->c != pIndex[i].c)
				{
					hr = E_UNEXPECTED;
					break;
				}
				sValue.Empty();
				if (phdr->len)
				{
					p = (LPCWSTR)&phdr[1];
					sValue.Append(p, phdr->len);
				}
				else
				{
				}
				TRACE(L"\t[数据段头信息 %u 字节，字符'%c'，拼音长%u个字符：%s]\n",
					phdr->bytes, phdr->c, phdr->len, sValue);
				pdata = (LPBYTE)pbuffer2;
				pdata += phdr->bytes;
				for (iWord = 0; iWord < pIndex[i].words; iWord++)
				{
					sWord.Empty();
					sPinyin.Empty();
					byteWordLen = *pdata; pdata++;
					if (byteWordLen)
					{
						p = (LPCWSTR)pdata;
						sWord.Append(p, byteWordLen);
						pdata += byteWordLen*sizeof(WCHAR);
					}
					bytePinyinLen = *pdata; pdata++;
					if (bytePinyinLen)
					{
						p = (LPCWSTR)pdata;
						sPinyin.Append(p, bytePinyinLen);
						pdata += bytePinyinLen*sizeof(WCHAR);
					}
					TRACE(L"\t词 %s (%d字符), 拼音 %s (%d字符)\n",
						sWord, byteWordLen, sPinyin, bytePinyinLen);
				}//end for
			}//end for
			if (hr != S_OK)
				break;
		} while (0);
		f.Close();
		if (pbuffer)
			free(pbuffer);
		if (pbuffer2)
			free(pbuffer2);
		return hr == S_OK ? true : false;
	}
	bool ReadIndex(CAtlFile *pFile,
		CByteArray& aRet,
		DWORD& dwLetters,
		DWORD& dwDataSize)
	{
		HRESULT hr;
		aRet.SetSize(0);
		dwLetters = 0;
		dwDataSize = 0;
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		DWORD dwIndexSize;
		do
		{
			if ((hr = pFile->Seek(0, FILE_BEGIN)) != S_OK)
				break;
			if ((hr = pFile->GetSize(ullFileSize)) != S_OK)
				break;
			if (ullFileSize < sizeof(dwLetters) + sizeof(dwDataSize))
			{
				hr = E_FAIL;
				break;
			}
			if ((hr = pFile->Read(&dwLetters, sizeof(dwLetters), dwRead)) != S_OK)
				break;
			if (dwRead != sizeof(dwLetters))
			{
				hr = E_FAIL;
				break;
			}
			if ((hr = pFile->Read(&dwDataSize, sizeof(dwDataSize), dwRead)) != S_OK)
				break;
			if (dwRead != sizeof(dwDataSize))
			{
				hr = E_FAIL;
				break;
			}
			dwIndexSize = sizeof(dwLetters) + sizeof(dwDataSize) +
				dwLetters*sizeof(index2);
			ASSERT(ullFileSize >= dwIndexSize + dwDataSize);
			if (ullFileSize < dwIndexSize + dwDataSize)
			{
				hr = E_UNEXPECTED;
				break;
			}
			aRet.SetSize(dwLetters*sizeof(index2));
			if (aRet.GetSize() != dwLetters*sizeof(index2))
			{
				hr = E_OUTOFMEMORY;
				break;
			}
			if ((hr = pFile->Read(aRet.GetData(), dwLetters*sizeof(index2), dwRead)) != S_OK)
				break;
			if (dwRead != dwLetters*sizeof(index2))
			{
				hr = E_FAIL;
				break;
			}
		} while (0);
		return hr == S_OK ? true : false;
	}

	//根据索引检索数据块返回。数据块中含有所有以c开头的词汇信息。
	bool ReadData(CAtlFile *pFile,
		CByteArray *pIndexData,
		DWORD dwLetters,
		WCHAR c,
		CByteArray& aDataRet)
	{
		HRESULT hr;
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		index2 *pIndex;
		DWORD i;
		DWORD dwLimitedSize;
		do
		{
			if ((hr = pFile->GetSize(ullFileSize)) != S_OK)
				break;
			pIndex = (index2 *)pIndexData->GetData();
			for (i = 0; i < dwLetters; i++)
			{
				if (pIndex[i].c == c)
				{
					dwLimitedSize = DWORD(ullFileSize - pIndex[i].pos);
					if (pIndex[i].len>dwLimitedSize)
					{
						hr = E_UNEXPECTED;
						break;
					}
					if ((hr = pFile->Seek(pIndex[i].pos, FILE_BEGIN)) != S_OK)
						break;
					//分配内存
					if (aDataRet.GetSize() <= (INT_PTR)pIndex[i].len)
					{
						aDataRet.SetSize(pIndex[i].len);
						if (aDataRet.GetSize() != pIndex[i].len)
						{
							hr = E_OUTOFMEMORY;
							break;
						}
					}
					else
					{
						aDataRet.SetSize(pIndex[i].len);
					}
					if ((hr = pFile->Read(aDataRet.GetData(), pIndex[i].len, dwRead)) != S_OK)
						break;
					if (dwRead != pIndex[i].len)
					{
						hr = E_FAIL;
						break;
					}
					break;
				}//end if ==c
			}//end for
			if (hr != S_OK)
				break;
		} while (0);
		return hr == S_OK ? true : false;
	}
	//从文件指定位置读取数据块返回。数据块中含有所有以c开头的词汇信息。
	bool ReadData(CAtlFile *pFile,
		DWORD dwPos,
		DWORD dwLen,
		WCHAR c,
		CByteArray& aDataRet)
	{
		HRESULT hr;
		ULONGLONG ullFileSize = 0;
		DWORD dwRead;
		DWORD dwLimitedSize;
		do
		{
			if ((hr = pFile->GetSize(ullFileSize)) != S_OK)
				break;
			dwLimitedSize = DWORD(ullFileSize - dwPos);
			if (dwLen>dwLimitedSize)
			{
				hr = E_UNEXPECTED;
				break;
			}
			if ((hr = pFile->Seek(dwPos, FILE_BEGIN)) != S_OK)
				break;
			//分配内存
			if (aDataRet.GetSize() <= (INT_PTR)dwLen)
			{
				aDataRet.SetSize(dwLen);
				if (aDataRet.GetSize() != dwLen)
				{
					hr = E_OUTOFMEMORY;
					break;
				}
			}
			else
			{
				aDataRet.SetSize(dwLen);
			}
			if ((hr = pFile->Read(aDataRet.GetData(), dwLen, dwRead)) != S_OK)
				break;
			if (dwRead != dwLen)
			{
				hr = E_FAIL;
				break;
			}
		} while (0);
		return hr == S_OK ? true : false;
	}

	//对 pData 分解成 CParseResult 返回
	bool ParseData(WCHAR c,
		CByteArray *pData,
		DWORD dwWordCount,
		CParseResult& ret)
	{
		HRESULT hr = S_OK;
		header *phdr;
		LPCWSTR p;
		CStringW sValue;
		LPBYTE pdata;
		DWORD iWord;
		BYTE byteWordLen, bytePinyinLen;
		CStringW sWord, sPinyin;
		do
		{
			phdr = (header *)pData->GetData();
			ASSERT(phdr->c == c);
			if (phdr->c != c)
			{
				hr = E_UNEXPECTED;
				break;
			}
			ret.m_char = c;
			sValue.Empty();
			//读取拼音串  en拼音+(cn拼音)+,+en拼音+(cn拼音)+,+...
			if (phdr->len)
			{
				p = (LPCWSTR)&phdr[1];
				sValue.Append(p, phdr->len);
			}
			if (sValue.GetLength())
			{
				CStringW sPinYin, sCnPinYin;
				CStringW sTok;
				int nStart = 0;
				int nPos;
				LPCWSTR wszSeps = L",;\\|/";
				sTok = sValue.Tokenize(wszSeps, nStart);
				while (!sTok.IsEmpty())
				{
					sTok.Trim();
					sPinYin = sTok;
					nPos = sPinYin.Find(L'(');
					ASSERT(nPos >= 0);
					if (nPos >= 0)
					{
						sPinYin.Delete(nPos, sPinYin.GetLength() - nPos);
					}
					sCnPinYin = sTok;
					nPos = sCnPinYin.Find(L'(');
					ASSERT(nPos >= 0);
					if (nPos >= 0)
					{
						sCnPinYin.Delete(0, nPos + 1);
						sCnPinYin.TrimRight(L')');
					}
					sPinYin.Trim();
					if (sPinYin.GetLength())
					{
						if (ret.m_enPinyins.AddTail(sPinYin) == NULL)
						{
							hr = E_FAIL;
							break;
						}
					}
					sCnPinYin.Trim();
					if (sCnPinYin.GetLength())
					{
						if (ret.m_cnPinyins.AddTail(sCnPinYin) == NULL)
						{
							hr = E_FAIL;
							break;
						}
					}
					sTok = sValue.Tokenize(wszSeps, nStart);
				}//end while sTok not empty
				if (hr != S_OK)
					break;
			}//end if sValue not emty
			pdata = (LPBYTE)pData->GetData();
			pdata += phdr->bytes;
			for (iWord = 0; iWord < dwWordCount; iWord++)
			{
				sWord.Empty();
				sPinyin.Empty();
				byteWordLen = *pdata; pdata++;
				if (byteWordLen)
				{
					p = (LPCWSTR)pdata;
					sWord.Append(p, byteWordLen);
					pdata += byteWordLen*sizeof(WCHAR);
				}
				bytePinyinLen = *pdata; pdata++;
				if (bytePinyinLen)
				{
					p = (LPCWSTR)pdata;
					sPinyin.Append(p, bytePinyinLen);
					pdata += bytePinyinLen*sizeof(WCHAR);
				}
				if (!ret.Add(sWord, sPinyin))
				{
					hr = E_FAIL;
					break;
				}
			}//end for
		} while (0);
		return hr == S_OK ? true : false;
	}

	//对 pData 分解成 CParseResult 返回
	//在分解过程中搜索 wszWord，如果找到则停止继续分解，立刻返回。
	bool ParseDataFind(WCHAR c,
		CByteArray *pData,
		DWORD dwWordCount,
		CParseResult& ret,
		LPCWSTR wszWord,
		BYTE lenWord,
		POSITION& posFound)
	{
		posFound = NULL;
		HRESULT hr = S_OK;
		header *phdr;
		LPCWSTR p;
		CStringW sValue;
		LPBYTE pdata;
		DWORD iWord;
		BYTE byteWordLen, bytePinyinLen;
		CStringW sWord, sPinyin;
		POSITION pos;
		do
		{
			phdr = (header *)pData->GetData();
			ASSERT(phdr->c == c);
			if (phdr->c != c)
			{
				hr = E_UNEXPECTED;
				break;
			}
			ret.m_char = c;
			sValue.Empty();
			//读取拼音串  en拼音+(cn拼音)+,+en拼音+(cn拼音)+,+...
			if (phdr->len)
			{
				p = (LPCWSTR)&phdr[1];
				sValue.Append(p, phdr->len);
			}
			if (sValue.GetLength())
			{
				CStringW sPinYin, sCnPinYin;
				CStringW sTok;
				int nStart = 0;
				int nPos;
				LPCWSTR wszSeps = L",;\\|/";
				sTok = sValue.Tokenize(wszSeps, nStart);
				while (!sTok.IsEmpty())
				{
					sTok.Trim();
					sPinYin = sTok;
					nPos = sPinYin.Find(L'(');
					ASSERT(nPos >= 0);
					if (nPos >= 0)
					{
						sPinYin.Delete(nPos, sPinYin.GetLength() - nPos);
					}
					sCnPinYin = sTok;
					nPos = sCnPinYin.Find(L'(');
					ASSERT(nPos >= 0);
					if (nPos >= 0)
					{
						sCnPinYin.Delete(0, nPos + 1);
						sCnPinYin.TrimRight(L')');
					}
					sPinYin.Trim();
					if (sPinYin.GetLength())
					{
						if (ret.m_enPinyins.AddTail(sPinYin) == NULL)
						{
							hr = E_FAIL;
							break;
						}
					}
					sCnPinYin.Trim();
					if (sCnPinYin.GetLength())
					{
						if (ret.m_cnPinyins.AddTail(sCnPinYin) == NULL)
						{
							hr = E_FAIL;
							break;
						}
					}
					sTok = sValue.Tokenize(wszSeps, nStart);
				}//end while sTok not empty
				if (hr != S_OK)
					break;
			}//end if sValue not emty
			pdata = (LPBYTE)pData->GetData();
			pdata += phdr->bytes;
			for (iWord = 0; iWord < dwWordCount; iWord++)
			{
				sWord.Empty();
				sPinyin.Empty();
				byteWordLen = *pdata; pdata++;
				if (byteWordLen)
				{
					p = (LPCWSTR)pdata;
					sWord.Append(p, byteWordLen);
					pdata += byteWordLen*sizeof(WCHAR);
				}
				bytePinyinLen = *pdata; pdata++;
				if (bytePinyinLen)
				{
					p = (LPCWSTR)pdata;
					sPinyin.Append(p, bytePinyinLen);
					pdata += bytePinyinLen*sizeof(WCHAR);
				}
				pos = ret.Add(sWord, sPinyin);
				if (pos==NULL)
				{
					hr = E_FAIL;
					break;
				}
				if (lenWord == byteWordLen)
				{
					if (_wcsicmp(sWord, wszWord) == 0)
					{
						posFound = pos;
						break;	//在插入之后立刻跳出，确保列表中最后一个是要找的。
					}
				}
			}//end for
		} while (0);
		return hr == S_OK ? true : false;
	}

	//保存到字词库
	/* 文件结构
	--------索引开始-------------
	DWORD 字库里的字符数量 - 4 bytes
	DWORD 数据部分的字节数
	WCHAR c1 字 + DWORD 词频 + DWORD 词数 + DWORD 位置->p1 + DWORD 长度
	WCHAR c2 字 + DWORD 词频 + DWORD 词数 + DWORD 位置->p2 + DWORD 长度
	....
	WCHAR cN 字 + DWORD 词频 + DWORD 词数 + DWORD 位置->pN + DWORD 长度
	--------索引结束-------------
	--------数据开始-------------
	->p1
	WORD c1的信息长度，字节 + WCHAR c1 字+WORD拼音长度（WCHAR 个数)+拼音串(英文格式拼音+括住的中文拼音)，以半角逗号分隔
	+ 词1的长度BYTE（WCHAR 个数）+词1串(UNICODE)+ 词1拼音的长度BYTE（WCHAR 个数）+词1拼音串(UNICODE)
	+ 词2的长度BYTE（WCHAR 个数）+词2串(UNICODE)+ 词2拼音的长度BYTE（WCHAR 个数）+词2拼音串(UNICODE)
	...
	+ 词N的长度BYTE（WCHAR 个数）+词N串(UNICODE)+ 词N拼音的长度BYTE（WCHAR 个数）+词N拼音串(UNICODE)
	->p2
	WORD c2的信息长度，字节 + WCHAR c2 字+WORD拼音长度（WCHAR 个数)+拼音串，以半角逗号分隔
	+ 词1的长度BYTE（WCHAR 个数）+词1串(UNICODE)+ 词1拼音的长度BYTE（WCHAR 个数）+词1拼音串(UNICODE)
	+ 词2的长度BYTE（WCHAR 个数）+词2串(UNICODE)+ 词2拼音的长度BYTE（WCHAR 个数）+词2拼音串(UNICODE)
	...
	+ 词N的长度BYTE（WCHAR 个数）+词N串(UNICODE)+ 词N拼音的长度BYTE（WCHAR 个数）+词N拼音串(UNICODE)
	...
	->pN
	WORD cN的信息长度，字节 + WCHAR cN 字+WORD拼音长度（WCHAR 个数)+拼音串，以半角逗号分隔
	+ 词1的长度BYTE（WCHAR 个数）+词1串(UNICODE)+ 词1拼音的长度BYTE（WCHAR 个数）+词1拼音串(UNICODE)
	+ 词2的长度BYTE（WCHAR 个数）+词2串(UNICODE)+ 词2拼音的长度BYTE（WCHAR 个数）+词2拼音串(UNICODE)
	...
	+ 词N的长度BYTE（WCHAR 个数）+词N串(UNICODE)+ 词N拼音的长度BYTE（WCHAR 个数）+词N拼音串(UNICODE)
	--------数据结束-------------
	*/
	//在字库中搜索组合成五笔数组和拼音数组，如果传递的指针非空的话。pnMissed可以返回缺失的字符数。
	bool GetWubiPinyin(CByteArray *pIndexData,
		DWORD dwLetters, 
		LPCWSTR wszText, 
		CStringArray *paWubi,
		CStringArray *paPinyin,
		int *pnMissed)
	{
		index2 *pIndex;
		DWORD i;
		if (paWubi) paWubi->RemoveAll();
		if (paPinyin) paPinyin->RemoveAll();
		if (pnMissed) *pnMissed = 0;
		LPCWSTR p = wszText;
		BOOL bFound;
		while (*p)
		{
			bFound = FALSE;
			pIndex = (index2 *)pIndexData->GetData();
			for (i = 0; i < dwLetters; i++)
			{
				if (pIndex[i].c == *p)
				{
					if (paWubi) paWubi->Add(CA2W(pIndex[i].wubi));
					if (paPinyin) paPinyin->Add(CA2W(pIndex[i].pinyin));
					bFound = TRUE;
					break;
				}//end if ==c
			}//end for
			if (!bFound)
			{
				if (paWubi) paWubi->Add(L"");
				if (paPinyin) paPinyin->Add(L"");
				if (pnMissed) (*pnMissed)++;
			}
			p++;
		}
		return true;
	}
};

//从 pStart 开始，检索一个中文串返回，长度要求是 nLen。
//检索的结果长度可能小于nLen或者没有检索到，返回FALSE。
//如果检索到，ppStarting返回第一个字的指针， ppEnding可以返回最后一个字符的指针。
//中文串由中文字组成，还不知道是否是词组或成语，有待于再切分。
//检索过程会跳过最前面的所有非中文符号（英语字母，标点符号，和其他符号），检索文字，直到遇上非中文文字时停止。
BOOL CETextManager::GetNextCnPhrase(
	PEObjLink pStart, 
	int& nLen,
	EObjLink **ppStarting,
	EObjLink **ppEnding,
	CStringW& sText)
{
	sText.Empty();
	int nLenSave = nLen;
	ASSERT(nLen);
	if (nLen == 0)
		return FALSE;
	PEObjLink pX;
	//跳过前面的所有非中文文字
	pX = pStart;
	while (pX)
	{
		if (pX->o.type == ETYPE_TEXT)
		{
			if (pX->o.cx)
			{
				if (!isSkipChar(pX->o.c))
					break;
			}
		}
		pX = pX->pNext;
	}
	if (pX == NULL)
		return FALSE;
	pStart = pX;
	PEObjLink pEnd = pStart;
	//开始检索
	while (pX)
	{
		if (pX->o.type == ETYPE_TEXT)
		{
			if (pX->o.cx)

			{
				if (isSkipChar(pX->o.c))
				{
					break;
				}
				else
				{
					pEnd = pX;
					nLen--;
					if (nLen == 0)
						break;
				}
			}
			else if (IsLinefeedNode(pX))
				break;
		}
		else
		{
			if (pX->o.cx)
				break;
		}
		pX = pX->pNext;
	}
	if (ppStarting) *ppStarting = pStart;
	if (ppEnding) *ppEnding = pEnd;
	nLen = nLenSave - nLen;
	pX = pStart;
	while (pX)
	{
		ASSERT(pX->o.type == ETYPE_TEXT);
		sText += pX->o.c;
		if (pX == pEnd)
			break;
		pX = pX->pNext;
	}
	return TRUE;
}

void CETextManager::EndSpellCheck()
{
	while (m_errorWords.GetCount())
		delete m_errorWords.RemoveTail();
}
BOOL CETextManager::SpellCheck(CDC *pDC, DWORD dwDictFlags/* = SPELLCHECK_ALL_DICT*/)
{
	if (dwDictFlags == 0)
		return TRUE;
	CTempBuffer<WCHAR> path(MAX_PATH);
	if (!GetModuleFileNameW(AfxGetInstanceHandle(), path, MAX_PATH))
		return FALSE;
	PathRemoveFileSpecW(path);
	CStringW sPath = path;
	while (m_errorWords.GetCount())
		delete m_errorWords.RemoveTail();
	if (dwDictFlags & SPELLCHECK_EN_DICT)
	{
		wcscpy_s(path, MAX_PATH, sPath);
		PathAppendW(path, L"dicts\\en\\enlib.dic");
		if (!PathFileExistsW(path))
			return FALSE;
		CAtlFile f;
		if (f.Create(path,
			GENERIC_READ,
			FILE_SHARE_READ,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,
			NULL, NULL) != S_OK)
			return FALSE;
		CByteArray aIndex;
		DWORD dwDataSize = 0;
		CEnDict dict;
		if (!dict.ReadIndex(&f, aIndex, dwDataSize))
			return FALSE;
		ULONGLONG ullFileSize = 0;
		f.GetSize(ullFileSize);
		ASSERT(ullFileSize == dwDataSize + aIndex.GetSize() + sizeof(dwDataSize));
		if (ullFileSize != dwDataSize + aIndex.GetSize() + sizeof(dwDataSize))
			return FALSE;
		CByteArray aData;
		//CEnDict::enindex *pIdxFound;
		//CEnDict::enindex *pIdx;
		//DWORD i;
		CStringW sValue;
		DWORD dwWordCount = 0, dwWordFiltered = 0;
		POSITION pos;
		CStringList verified;
		BOOL bChecked;
		CharList wordBoundle(FALSE);
		BOOL bPassed;
		CStringW sWord = L"";
		PEObjLink pChar = m_buffer.m_pLinkHead;
		while (pChar)
		{
			if (pChar->o.type == ETYPE_TEXT)
			{
				if (isEnAlpha(pChar->o.c))
				{
					sWord += pChar->o.c;
					wordBoundle.AddTail(pChar);
				}
				else
				{
					sWord.Trim();
					if (sWord.GetLength())
					{
						//我们只检索长度大于1的单词
						if (sWord.GetLength() > 1)
						{
							bChecked = FALSE;
							bPassed = FALSE;
							pos = verified.GetHeadPosition();
							while (pos)
							{
								if (verified.GetNext(pos).CompareNoCase(sWord) == 0)
								{
									bChecked = TRUE;
									bPassed = TRUE;
									break;
								}
							}//end while (pos)
							if (!bChecked)
							{
								bChecked = TRUE;
								if (dict.SpellCheck(sWord,
									&f,
									&aIndex))
								{
									bPassed = TRUE;
									verified.AddTail(sWord);
								}
								else
								{
//									TRACE(L"\"%s\" not found\n", sWord);
								}
							}//end if (!bChecked)
							if (!bPassed)
							{
								CharList *pBoundle = new CharList(FALSE);
								if (pBoundle)
								{
									pBoundle->AddTail(&wordBoundle);
									m_errorWords.AddTail(pBoundle);
								}
							}
						}//end if (sWord.GetLength() > 1)
					}//end if (sWord.GetLength() > 0)
					sWord.Empty();
					wordBoundle.RemoveAll();
				}//end else if (!isEnAlpha(pChar->o.c))
			}//end if (pChar->o.type == ETYPE_TEXT)
			else
			{
				if (pChar->o.cx)
				{
					sWord.Trim();
					if (sWord.GetLength())
					{
						//我们只检索长度大于1的单词
						if (sWord.GetLength() > 1)
						{
							bChecked = FALSE;
							bPassed = FALSE;
							pos = verified.GetHeadPosition();
							while (pos)
							{
								if (verified.GetNext(pos).CompareNoCase(sWord) == 0)
								{
									bChecked = TRUE;
									bPassed = TRUE;
									break;
								}
							}//end while (pos)
							if (!bChecked)
							{
								bChecked = TRUE;
								if (dict.SpellCheck(sWord,
									&f,
									&aIndex))
								{
									bPassed = TRUE;
									verified.AddTail(sWord);
								}
								else
								{
									TRACE(L"\"%s\" not found\n", sWord);
								}
							}//end if (!bChecked)
							if (!bPassed)
							{
								CharList *pBoundle = new CharList(FALSE);
								if (pBoundle)
								{
									pBoundle->AddTail(&wordBoundle);
									m_errorWords.AddTail(pBoundle);
								}
							}
						}//end if (sWord.GetLength() > 1)
					}//end if (sWord.GetLength() > 0)
					sWord.Empty();
					wordBoundle.RemoveAll();
				}//end if (pChar->o.cx)
			}//end else if (pChar->o.type != ETYPE_TEXT)
			pChar = pChar->pNext;
		}//end while (pChar)
		sWord.Trim();
		if (sWord.GetLength())
		{
			//我们只检索长度大于1的单词
			if (sWord.GetLength() > 1)
			{
				bChecked = FALSE;
				bPassed = FALSE;
				pos = verified.GetHeadPosition();
				while (pos)
				{
					if (verified.GetNext(pos).CompareNoCase(sWord) == 0)
					{
						bChecked = TRUE;
						bPassed = TRUE;
						break;
					}
				}//end while (pos)
				if (!bChecked)
				{
					bChecked = TRUE;
					if (dict.SpellCheck(sWord,
						&f,
						&aIndex))
					{
						bPassed = TRUE;
						verified.AddTail(sWord);
					}
					else
					{
						TRACE(L"\"%s\" not found\n", sWord);
					}
				}//end if (!bChecked)
				if (!bPassed)
				{
					CharList *pBoundle = new CharList(FALSE);
					if (pBoundle)
					{
						pBoundle->AddTail(&wordBoundle);
						m_errorWords.AddTail(pBoundle);
					}
				}
			}//end if (sWord.GetLength() > 1)
		}//end if (sWord.GetLength() > 0)
		sWord.Empty();
		wordBoundle.RemoveAll();
		f.Close();
	}//end if (dwDictFlags & SPELLCHECK_EN_DICT)
	if (dwDictFlags & SPELLCHECK_CN_DICT)
	{
		wcscpy_s(path, MAX_PATH, sPath);
		PathAppendW(path, L"dicts\\cn\\cnlib3.dic");
		if (!PathFileExistsW(path))
			return FALSE;
		CAtlFile f;
		if (f.Create(path,
			GENERIC_READ,
			FILE_SHARE_READ,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,
			NULL, NULL) != S_OK)
			return FALSE;
		CByteArray aIndex;
		DWORD dwLetters = 0;
		DWORD dwDataSize = 0;
		CCnDict dict;
		if (!dict.ReadIndex(&f, aIndex, dwLetters, dwDataSize))
			return FALSE;
		DWORD i;
		CCnDict::index2 *pIdxFound;
		CCnDict::index2 *pIdx;
#ifdef _DEBUG
		pIdx = (CCnDict::index2 *)aIndex.GetData();
		for (i = 0; i < dwLetters; i++)
		{
			if (pIdx[i].pinyin[0] == 0 || pIdx[i].wubi[0] == 0)
				AtlTrace(L"字符 '%c'", pIdx[i].c);
			if (pIdx[i].pinyin[0]==0)
			{
				AtlTrace(L" 没有拼音信息。");
			}
			if (pIdx[i].wubi[0] == 0)
			{
				AtlTrace(L" 没有五笔编码信息。");
			}
			if (pIdx[i].pinyin[0] == 0 || pIdx[i].wubi[0] == 0)
				AtlTrace(L"\n");
		}
#endif
		ULONGLONG ullFileSize = 0;
		if (f.GetSize(ullFileSize) != S_OK)
			return FALSE;
		ASSERT(ullFileSize == dwDataSize + aIndex.GetSize() + sizeof(dwLetters) + sizeof(dwDataSize));
		if (ullFileSize != dwDataSize + aIndex.GetSize() + sizeof(dwLetters) + sizeof(dwDataSize))
			return FALSE;
		CByteArray aData;
		POSITION pos;
		CWords::WordsItem *pPair;
		CMultiMap used;
		CStringW sValue;
		CStringW sWord;
		PEObjLink pStartChar = m_buffer.m_pLinkHead;
		PEObjLink pEndChar;
		PEObjLink pX;
		int nLen = 2;
		WCHAR c;
		BOOL bFound;
		CWords *pWords;
		LPCWSTR wszWord;
		while (GetNextCnPhrase(pStartChar, nLen, &pStartChar, &pEndChar, sWord))
		{
			if (nLen > 1)
			{
				//sWord.Empty();
				//pX = pStartChar;
				//while (pX)
				//{
				//	ASSERT(pX->o.type == ETYPE_TEXT);
				//	sWord += pX->o.c;
				//	if (pX == pEndChar)
				//		break;
				//	pX = pX->pNext;
				//}
				c = *((LPCWSTR)sWord);
				pIdxFound = NULL;
				pIdx = (CCnDict::index2 *)aIndex.GetData();
				for (i = 0; i < dwLetters; i++)
				{
					if (pIdx[i].c == c)
					{
						pIdxFound = &pIdx[i];
						break;
					}
				}
				//发现第一个字在索引中不存在？
				if (pIdxFound == NULL)
				{
					pStartChar = pStartChar->pNext;
					nLen = 2;
					continue;
				}
				//只有以此字开始的词汇量大于0而且词频大于0的文字才需要检索
				if (pIdxFound->counts && pIdxFound->words)
				{
					//先从过往数据中查找。人类习惯地喜欢重复用词。
					bFound = FALSE;
					pWords = used.Lookup(c);
					if (pWords)
					{
						pos = pWords->m_list.GetHeadPosition();
						while (pos)
						{
							pPair = pWords->m_list.GetNext(pos);
							if (pPair->wordLen == nLen)
							{
								if (sWord.CompareNoCase(pPair->wszWord) == 0)
								{
									//if (bOutputDebugText)
									//	TRACE(L"* %c -> %s\n", *pS, wszWord);
									bFound = TRUE;
								}
							}
						}
					}//end if (pWords)
					//找不到的话再从词库中读取
					if (!bFound)
					{
						if (dict.ReadData(&f, pIdxFound->pos, pIdxFound->len, c, aData))
						{
							CParseResult ret;
							POSITION posFound = NULL;
							CParseResult::WordPair *pRPair;
							if (dict.ParseDataFind(c, &aData, 
								pIdxFound->words, ret, 
								sWord, nLen, posFound))
							{
								if (posFound)
								{
									bFound = TRUE;
									pRPair = ret.m_pairs.GetAt(posFound);
									if (pWords == NULL)
									{
										used.CreateWord(c, pRPair->wszWord, pRPair->wszPinyin);
									}
									else
									{
										used.Add(pWords, pRPair->wszWord, pRPair->wszPinyin, TRUE);
									}
								}
								else
								{
									//如果都没有100%匹配的，那么怎么确定哪个词是错误的呢？
									//我们提供两种方法，一是字符形相近，二是字符发音相近
									//用五笔字形编码来解决形相近，用拼音来解决音相近
									pos = ret.m_pairs.GetHeadPosition();
									while (pos)
									{
										pRPair = ret.m_pairs.GetNext(pos);
										if (nLen != pRPair->wordLen)
										{
											//尝试截取 nLen 长度的串
											nLen = pRPair->wordLen;
											GetNextCnPhrase(pStartChar, nLen, &pStartChar, &pEndChar, sWord);
										}
										//只比较长度一样的串
										if (nLen == pRPair->wordLen)
										{
											CStringArray aWubi, aPinyin;
											int nMissed=0;
											dict.GetWubiPinyin(&aIndex, dwLetters, sWord, &aWubi, &aPinyin, &nMissed);
											ASSERT(aWubi.GetCount() == nLen);
											ASSERT(aPinyin.GetCount() == nLen);
											CStringArray aWubi2, aPinyin2;
											int nMissed2 = 0;
											//pRPair中已经包含了拼音信息，但是因为我们还没有认真审查过最开始提供的词组拼音和后来五笔拼音映射的拼音是否都一致，所以目前以后者为准
											dict.GetWubiPinyin(&aIndex, dwLetters, pRPair->wszWord, &aWubi2, &aPinyin2, &nMissed2);
											ASSERT(aWubi2.GetCount() == nLen);
											ASSERT(aPinyin2.GetCount() == nLen);
											//如果有些字在字库中没有找到的话，我们放弃比较
											if (nMissed == nMissed2 && nMissed2 == 0)
											{
												//先比较形相近
												int i;
												int nWubiSame = 0;
												int nWubiTotal = 0;
												for (i = 0; i < nLen; i++)
												{
													if (aWubi[i] == aWubi2[i])
													{
														nWubiSame += aWubi[i].GetLength();
														nWubiTotal += aWubi[i].GetLength();
													}
													else
													{

													}
												}
											}
										}
									}//end while (pos)
								}//end if (posFound)
							}//end if (dict.ParseDataFind
						}//end if (dict.ReadData
					}//end if (!bFound)
				}//end if (pIdxFound->counts && pIdxFound->words)
			}//end if (nLen > 1)
			pStartChar = pEndChar->pNext;
			nLen = 2;
		}//end while (GetNextCnPhrase
		f.Close();
	}//end if (dwDictFlags & SPELLCHECK_CN_DICT)
	return TRUE;
}

//LPCWSTR wszXx = L"OK\t1\r2\n3好的！!.";
//int nFix;
//CTempBuffer<int> aDx(wcslen(wszXx)+1);
//SIZE sizeXx;
//VERIFY(GetTextExtentExPointW(
//	pDC->GetSafeHdc(), 
//	wszXx,
//	wcslen(wszXx),
//	m_rcText.Width()/*wcslen(wszXx)*/,
//	&nFix,
//	aDx, 
//	&sizeXx));
//LPCWSTR px = wszXx;
//TRACE(L"string [%s] fixed %d chars, size cx=%d cy=%d\n",
//	wszXx, nFix, sizeXx.cx, sizeXx.cy);
//for (int i = 0; i < nFix; i++, px++)
//{
//	wszX[0] = *px;
//	size = pDC->GetTextExtent(wszX, 1);
//	TRACE(L"char 0x%04x (%c) distance=%d size cx=%d,cy=%d\n",
//		*px, *px,
//		aDx[i], size.cx, size.cy);
//}
